(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"240x400_atlas_P_", frames: [[0,76,149,146],[151,76,83,91],[151,169,56,81],[0,0,402,74]]},
		{name:"240x400_atlas_NP_", frames: [[772,959,131,99],[478,802,480,155],[0,802,476,679],[0,0,480,800],[478,1175,284,215],[482,0,480,800],[478,959,292,214]]}
];


// symbols:



(lib._1 = function() {
	this.initialize(ss["240x400_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["240x400_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._3 = function() {
	this.initialize(ss["240x400_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._4 = function() {
	this.initialize(ss["240x400_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib._5 = function() {
	this.initialize(ss["240x400_atlas_NP_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.c1 = function() {
	this.initialize(ss["240x400_atlas_NP_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение15 = function() {
	this.initialize(ss["240x400_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение16 = function() {
	this.initialize(ss["240x400_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение17 = function() {
	this.initialize(ss["240x400_atlas_P_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение26 = function() {
	this.initialize(ss["240x400_atlas_P_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение221 = function() {
	this.initialize(ss["240x400_atlas_NP_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Символ50 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._4();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ50, new cjs.Rectangle(0,0,240,400), null);


(lib.Символ49 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#118A9A","rgba(17,138,154,0)"],[0.008,1],0,-56.6,0,56.3).s().p("AyxI1IAAxpMAljAAAIAARpg");
	this.shape.setTransform(120.225,56.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ49, new cjs.Rectangle(0,0,240.5,113), null);


(lib.Символ48 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAPA/IAAg2IgJAAQgSAAAAATIAAATQAAALgCAFIgOAAQACgFAAgKIAAgTQAAgWAQgFQgQgEAAgVIAAgKQAAgdAbAAIAcAAIAAB9gAgMggIAAAMQAAAKAFAEQAEAEAIgBIAKAAIAAguIgNAAQgOAAAAARg");
	this.shape.setTransform(79.075,9.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AARA/IAAhjIgNAoIgSA7IgPAAIAAh9IANAAIAABdIANgnIARg2IAQAAIAAB9g");
	this.shape_1.setTransform(71.375,9.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAPA/IAAg5IgdAAIAAA5IgPAAIAAh9IAPAAIAAA5IAdAAIAAg5IAPAAIAAB9g");
	this.shape_2.setTransform(63.475,9.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgZA/IAAh9IAzAAIAAANIglAAIAAArIAeAAIAAALIgeAAIAAAtIAlAAIAAANg");
	this.shape_3.setTransform(56.05,9.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAPA/IAAg5IgdAAIAAA5IgPAAIAAh9IAPAAIAAA5IAdAAIAAg5IAPAAIAAB9g");
	this.shape_4.setTransform(48.525,9.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAmA/IgZg8IgHAMIAAAwIgMAAIAAgwIgHgMIgYA8IgOAAIAdhHIgcg2IANAAIAfA6IAAg6IAMAAIAAA6IAfg6IAOAAIgcA1IAdBIg");
	this.shape_5.setTransform(38.8,9.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgUA4QgIgIAAgPIAAhAQAAgPAIgIQAHgJANAAQAOAAAIAJQAHAIAAAPIAABAQAAAPgHAIQgIAIgOAAQgNAAgHgIgAgOggIAABCQAAASAOAAQAPAAAAgSIAAhCQAAgSgPAAQgOAAAAASg");
	this.shape_6.setTransform(29.15,9.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAUA/IAAhwIgXAAIgDBQQAAAQgFAIQgGAIgOAAIgCAAIAAgNQAIABADgFQACgDABgLIADheIAyAAIAAB9g");
	this.shape_7.setTransform(20.875,9.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgVA4QgGgIgBgPIAAhAQABgPAGgIQAIgJANAAQAOAAAIAJQAHAIAAAPIAAALIgOAAIAAgMQAAgSgPAAQgNAAgBASIAABCQABASANAAQAPAAAAgSIAAgRIAOAAIAAAQQAAAPgHAIQgIAIgOAAQgNAAgIgIg");
	this.shape_8.setTransform(13.15,9.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgVA4QgHgIAAgPIAAhAQAAgPAHgIQAIgJANAAQAOAAAHAJQAIAIAAAPIAABAQAAAPgIAIQgHAIgOAAQgNAAgIgIgAgOggIAABCQAAASAOAAQAPAAAAgSIAAhCQAAgSgPAAQgOAAAAASg");
	this.shape_9.setTransform(5.6,9.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ48, new cjs.Rectangle(0,0,85.4,22), null);


(lib.Символ47 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AARA/IAAhjIgNAoIgSA7IgPAAIAAh9IANAAIAABdIANgnIARg2IAQAAIAAB9g");
	this.shape.setTransform(57.025,9.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AARA/IAAhjIgNAoIgSA7IgPAAIAAh9IANAAIAABdIANgnIARg2IAQAAIAAB9g");
	this.shape_1.setTransform(49.375,9.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgbA/IAAh9IAbAAQAcAAAAAfIAAAPQAAAegcgBIgNAAIAAAygAgNABIANAAQAOAAAAgQIAAgRQAAgRgOAAIgNAAg");
	this.shape_2.setTransform(42.25,9.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgZA/IAAh9IAzAAIAAANIglAAIAAArIAeAAIAAALIgeAAIAAAtIAlAAIAAANg");
	this.shape_3.setTransform(35.3,9.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgGA/IAAhwIgXAAIAAgNIA7AAIAAANIgXAAIAABwg");
	this.shape_4.setTransform(28.4,9.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AARA/Igag3IgHANIAAAqIgPAAIAAh9IAPAAIAAA9IAgg9IAOAAIgfA5IAgBEg");
	this.shape_5.setTransform(21.25,9.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAUA/IgEgZIgfAAIgFAZIgNAAIAYh9IATAAIAYB9gAAOAaIgOhIIgOBIIAcAAg");
	this.shape_6.setTransform(13.325,9.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgcA/IAAh9IA0AAIAAANIgmAAIAAAnIAOAAQAdAAAAAdIAAANQAAAfgdAAgAgOAyIAOAAQAPABAAgSIAAgPQAAgJgEgEQgEgDgHAAIgOAAg");
	this.shape_7.setTransform(5.7,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ47, new cjs.Rectangle(0,0,63.1,22), null);


(lib.Символ46 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAUA/IgEgaIgfAAIgFAaIgNAAIAYh9IATAAIAYB9gAAOAZIgOhHIgOBHIAcAAg");
	this.shape.setTransform(60.725,9.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAaBIIAAgSIgzAAIAAASIgNAAIAAgeIAIAAQAFgGAAgNIAFheIAyAAIAABxIAJAAIAAAegAgLAXQgBAOgFAFIAgAAIAAhkIgWAAg");
	this.shape_1.setTransform(51.925,10.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgZA/IAAgNQAIABAEgDQAEgDACgHIADgIIgdhcIAOAAIAMArIAIAfIAHgfIAMgrIAOAAIgbBhQgDAPgGAHQgGAGgNAAIgEAAg");
	this.shape_2.setTransform(43.225,9.1563);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGA/IAAhwIgXAAIAAgNIA7AAIAAANIgXAAIAABwg");
	this.shape_3.setTransform(35.55,9.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUA4QgIgIAAgPIAAhAQAAgPAIgIQAHgJANAAQAOAAAIAJQAGAIABAPIAAALIgOAAIAAgMQAAgSgPAAQgNAAAAASIAABCQAAASANAAQAPAAAAgSIAAgRIAOAAIAAAQQgBAPgGAIQgIAIgOAAQgNAAgHgIg");
	this.shape_4.setTransform(28.25,9.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgVA4QgHgIAAgPIAAhAQAAgPAHgIQAIgJANAAQAOAAAIAJQAHAIAAAPIAABAQAAAPgHAIQgIAIgOAAQgNAAgIgIgAgOggIAABCQAAASAOAAQAPAAAAgSIAAhCQAAgSgPAAQgOAAAAASg");
	this.shape_5.setTransform(20.7,9.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgbA/IAAh9IAbAAQAcAAAAAfIAAAPQAAAegcAAIgNAAIAAAxgAgNAAIANAAQAOAAAAgPIAAgRQAAgRgOAAIgNAAg");
	this.shape_6.setTransform(13.45,9.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAPA/IAAhwIgdAAIAABwIgPAAIAAh9IA7AAIAAB9g");
	this.shape_7.setTransform(5.725,9.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ46, new cjs.Rectangle(0,0,67.2,22), null);


(lib.Символ45 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAbA/IAAh9IAOAAIAAB9gAgoA/IAAh9IAPAAIAAAyIAMAAQAcgBAAAeIAAAPQAAAfgbAAgAgZAzIANAAQANAAAAgSIAAgRQAAgQgOAAIgMAAg");
	this.shape.setTransform(46.725,9.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgVA4QgHgIAAgPIAAhAQAAgPAHgIQAIgJANAAQAOAAAIAJQAGAIABAPIAAALIgOAAIAAgMQAAgSgPAAQgNAAAAASIAABCQAAASANAAQAPAAAAgSIAAgRIAOAAIAAAQQgBAPgGAIQgIAIgOAAQgNAAgIgIg");
	this.shape_1.setTransform(37.7,9.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgZA/IAAgNQAIABAEgDQAEgDACgHIADgIIgdhcIAOAAIAMArIAIAfIAHgfIAMgrIAOAAIgbBhQgDAPgGAHQgGAGgNAAIgEAAg");
	this.shape_2.setTransform(29.625,9.1563);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgbA/IAAh9IAbAAQAcAAAAAfIAAAPQAAAegcAAIgNAAIAAAxgAgNAAIANAAQAOAAAAgPIAAgRQAAgRgOAAIgNAAg");
	this.shape_3.setTransform(21.8,9.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AARA/IAAhjIgNApIgSA6IgPAAIAAh9IANAAIAABdIANgnIARg2IAQAAIAAB9g");
	this.shape_4.setTransform(13.725,9.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgcA/IAAh9IAcAAQAOAAAGAHQAHAHAAAOIAAAGQAAAVgPAEQARAEAAAWIAAALQAAAdgdAAgAgOAzIAOAAQAPAAAAgSIAAgLQAAgLgEgEQgFgEgHAAIgNAAgAgOgJIALAAQAIAAAEgDQAEgEAAgKIAAgHQAAgQgNAAIgOAAg");
	this.shape_5.setTransform(5.7,9.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ45, new cjs.Rectangle(0,0,54.5,22), null);


(lib.Символ42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4CDAEC").s().p("AlVEGIAAoLIKrAAIAAILg");
	this.shape.setTransform(34.225,26.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ42, new cjs.Rectangle(0,0,68.5,52.4), null);


(lib.Символ40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// blueBottom___копия
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#023863","rgba(2,56,99,0)"],[0,1],4.8,19.6,4.8,-33.6).s().p("Az/GWIAAstMAn/AAAIAAMvg");
	this.shape.setTransform(120.6,381.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// blueBottom
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#023863","rgba(2,56,99,0)"],[0,1],4.8,13.1,4.8,-22.5).s().p("Az/EQIAAogMAn/AAAIAAIhg");
	this.shape_1.setTransform(120.6,377.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Слой_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0066FF").s().p("AifBuIAAjbIE/AAIAADbg");
	this.shape_2.setTransform(24,-114);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ40, new cjs.Rectangle(-7.4,-125,256,547.2), null);


(lib.Символ39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение26();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ39, new cjs.Rectangle(0,0,201,37), null);


(lib.Символ38копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AqdASIAAgkIU7AAIAAAkg");
	this.shape.setTransform(67,1.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ38копия, new cjs.Rectangle(0,0,134,3.7), null);


(lib.Символ38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AqdASIAAgkIU7AAIAAAkg");
	this.shape.setTransform(67,1.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ38, new cjs.Rectangle(0,0,134,3.7), null);


(lib.Символ37копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AsRAYQAAgDBdgwIBcgwQLDAaKnA5Ik6BEg");
	this.shape.setTransform(78.5875,7.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ37копия, new cjs.Rectangle(0,0,157.2,15.2), null);


(lib.Символ37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AHYBQIzpg/QAAgDBdgwIBcgwQLDAbKnA5QkHBRgrAAQgHAAgBgDg");
	this.shape.setTransform(78.5875,8.2514);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ37, new cjs.Rectangle(0,0,157.2,16.5), null);


(lib.Символ34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00426F").s().p("AACAgIAAg3IgKAGIgCgHIANgHIAIAAIAAA/g");
	this.shape.setTransform(152.075,5.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00426F").s().p("AgPAZQgGgJAAgQQAAgOAGgJQAHgJAJAAQAKAAAFAIQAGAKAAAOQAAAPgGAKQgGAIgKAAQgJAAgGgIgAgIgSQgEAHAAALQAAANADAGQAEAIAFgBQAGABAEgIQADgGAAgNQAAgMgDgGQgDgHgHAAQgFAAgDAHg");
	this.shape_1.setTransform(147.475,5.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00426F").s().p("AgQAkIAahGIAHAAIgbBGg");
	this.shape_2.setTransform(143.2,5.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00426F").s().p("AgTAcIACgGQAHAEAIAAQAGAAADgDQAEgEAAgFQAAgGgFgDQgFgEgFAAIgGAAIAAgFIAGAAQAEAAAFgDQADgDAAgFQABgEgDgDQgDgDgFAAQgGAAgGAFIgDgHQAIgFAJAAQAIAAAFAEQAEAFAAAGQAAAGgCADQgEAFgFACQAGABAEADQAEAEAAAHQAAAIgGAFQgHAGgJAAQgLAAgGgFg");
	this.shape_3.setTransform(138.85,5.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00426F").s().p("AgTAcIACgGQAHAEAIAAQAGAAAEgDQADgEAAgFQAAgGgFgDQgFgEgFAAIgGAAIAAgFIAGAAQAEAAAFgDQADgDAAgFQABgEgDgDQgDgDgEAAQgIAAgFAFIgDgHQAIgFAJAAQAIAAAFAEQAEAFAAAGQAAAGgCADQgDAFgGACQAGABAEADQAEAEAAAHQAAAIgGAFQgGAGgKAAQgKAAgHgFg");
	this.shape_4.setTransform(133.8,5.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00426F").s().p("AgPAZQgGgHAAgMQAAgRALgLQAIgIALgBIAHgBIAAAHIgHABQgJABgFAGQgGAHgBAIIAAAAQAGgHAJAAQAIAAAFAFQAGAFAAAJQAAAKgGAGQgGAHgJAAQgKAAgGgIgAgGgBQgEACgCADIAAAEQAAAIADAFQAEAFAGAAQAFAAAEgEQADgEAAgHQAAgHgEgEQgDgDgGAAQgDAAgDACg");
	this.shape_5.setTransform(128.825,5.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00426F").s().p("AACAgIAAg3IgKAGIgCgHIANgHIAIAAIAAA/g");
	this.shape_6.setTransform(123.325,5.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00426F").s().p("AACAgIAAg3IgKAGIgCgHIANgHIAIAAIAAA/g");
	this.shape_7.setTransform(118.225,5.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00426F").s().p("AgPAZQgGgJAAgQQAAgOAGgJQAHgJAJAAQAKAAAFAIQAGAKAAAOQAAAPgGAKQgGAIgKAAQgJAAgGgIgAgIgSQgEAHAAALQAAANADAGQAEAIAFgBQAGABAEgIQADgGAAgNQAAgMgDgGQgDgHgHAAQgFAAgDAHg");
	this.shape_8.setTransform(113.625,5.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00426F").s().p("AAQAhIgUghQgIgNgEgIIAAAaIAAAcIgIAAIAAhBIAKAAIAUAgQAHAMAEAKIABgBIgBgaIAAgbIAIAAIAABBg");
	this.shape_9.setTransform(107.825,5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00426F").s().p("AAPAhIAAg6IgdAAIAAA6IgJAAIAAhBIAvAAIAABBg");
	this.shape_10.setTransform(99.35,5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00426F").s().p("AgBgKIAJgBIgFAMIgEALIgGAAQAEgKACgMg");
	this.shape_11.setTransform(92.975,8.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00426F").s().p("AACAgIAAg3IgKAGIgCgHIANgHIAIAAIAAA/g");
	this.shape_12.setTransform(89.025,5.125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00426F").s().p("AgPAZQgGgJAAgQQAAgOAGgJQAHgJAJAAQAKAAAFAIQAGAKAAAOQAAAPgGAKQgGAIgKAAQgJAAgGgIgAgIgSQgEAHAAALQAAANADAGQAEAIAFgBQAGABAEgIQADgGAAgNQAAgMgDgGQgDgHgHAAQgFAAgDAHg");
	this.shape_13.setTransform(84.425,5.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00426F").s().p("AgQAkIAahGIAHAAIgbBGg");
	this.shape_14.setTransform(80.2,5.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00426F").s().p("AgTAgIAAgFIAGgGQANgNAFgHQAFgGAAgHQAAgFgDgEQgDgDgFAAQgHAAgHAFIgDgGQAIgGAKgBQAJABAFAFQAFAGAAAHQAAAIgFAHQgGAIgKALIgFAEIAAAAIAbAAIAAAHg");
	this.shape_15.setTransform(75.875,5.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00426F").s().p("AgTAcIADgGQAGAEAHAAQAHAAADgDQAEgEAAgFQAAgGgFgDQgFgEgGAAIgFAAIAAgFIAFAAQAFAAAEgDQAEgDABgFQAAgEgDgDQgDgDgFAAQgGAAgGAFIgCgHQAGgFAKAAQAIAAAFAEQAEAFABAGQgBAGgDADQgCAFgHACQAHABAEADQAEAEAAAHQAAAIgHAFQgFAGgLAAQgKAAgGgFg");
	this.shape_16.setTransform(70.75,5.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00426F").s().p("AgPAZQgGgHAAgMQAAgRALgLQAIgIALgBIAHgBIAAAHIgHABQgJABgFAGQgGAHgBAIIAAAAQAGgHAJAAQAIAAAFAFQAGAFAAAJQAAAKgGAGQgGAHgJAAQgKAAgGgIgAgGgBQgEACgCADIAAAEQAAAIADAFQAEAFAGAAQAFAAAEgEQADgEAAgHQAAgHgEgEQgDgDgGAAQgDAAgDACg");
	this.shape_17.setTransform(65.825,5.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00426F").s().p("AACAgIAAg3IgKAGIgCgHIANgHIAIAAIAAA/g");
	this.shape_18.setTransform(60.275,5.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00426F").s().p("AACAgIAAg3IgKAGIgCgHIANgHIAIAAIAAA/g");
	this.shape_19.setTransform(55.225,5.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00426F").s().p("AgPAZQgGgJAAgQQAAgOAGgJQAHgJAJAAQAKAAAFAIQAGAKAAAOQAAAPgGAKQgGAIgKAAQgJAAgGgIgAgIgSQgEAHAAALQAAANADAGQAEAIAFgBQAGABAEgIQADgGAAgNQAAgMgDgGQgDgHgHAAQgFAAgDAHg");
	this.shape_20.setTransform(50.575,5.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#00426F").s().p("AAQAhIgUghQgIgNgEgIIAAAaIAAAcIgIAAIAAhBIAKAAIAUAgQAHAMAEAKIABgBIgBgaIAAgbIAIAAIAABBg");
	this.shape_21.setTransform(44.775,5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#00426F").s().p("AAPAhIAAg6IgeAAIAAA6IgIAAIAAhBIAvAAIAABBg");
	this.shape_22.setTransform(36.3,5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#00426F").s().p("AgDAWQAAgBgBAAQAAgBAAAAQAAgBgBgBQAAAAAAgBQAAAAAAgBQABgBAAAAQAAgBAAAAQABgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAAAAAQABAAABABQAAAAAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAABAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAgAgDgMQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAgBAAgBQABAAAAgBQAAAAAAgBQABAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAAAABQABAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAABgBAAQAAABAAAAQAAABgBAAQAAABgBAAQAAAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAg");
	this.shape_23.setTransform(30.075,6.075);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#00426F").s().p("AgDAFQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAABAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_24.setTransform(28.025,7.775);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#00426F").s().p("AARAfIgBgPIggAAIAAAPIgHAAIAAgVIAEAAQADgFABgFQADgIAAgKIAAgMIAfAAIAAAoIAFAAIAAAVgAgEgQQAAAKgDAHIgDAJIAUAAIAAgiIgOAAg");
	this.shape_25.setTransform(24.25,6.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#00426F").s().p("AgTAbQAEgBAEgDQAEgEADgFIABgCIgBgDIgRgrIAJAAIAKAdIACAJIABAAIABgEIACgFIAJgdIAJAAIgNAiIgIASQgDAHgEAEQgFAEgGABg");
	this.shape_26.setTransform(19.375,7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#00426F").s().p("AgDAFQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_27.setTransform(16.075,7.775);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#00426F").s().p("AgOAYIAAgvIAcAAIAAAHIgTAAIAAAog");
	this.shape_28.setTransform(13.35,5.925);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#00426F").s().p("AgNASQgHgGAAgLQAAgKAHgHQAGgIAIAAQAGAAAEADQAEACACADIADAHIABAIIAAADIggAAQgBAIAFAEQAEAEAHAAQAHAAAGgCIABAGQgGADgKAAQgJAAgGgHgAgIgNQgDAEAAAFIAYAAQAAgFgDgEQgCgEgHAAQgFAAgEAEg");
	this.shape_29.setTransform(8.7,5.925);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#00426F").s().p("AgTAhIAAhAIAQgBQAMAAAGAFQAFAFAAAJQAAAJgFAEQgHAHgMAAIgHAAIAAAagAgLgZIAAAZIAHABQAHAAAEgDQAFgEAAgGQAAgHgEgDQgFgEgGAAIgIABg");
	this.shape_30.setTransform(3.775,4.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ34, new cjs.Rectangle(0,0,167,11.8), null);


(lib.Символ33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#004470").s().p("AgIAXIgGgDQgCgCgBgEQgCgFAAgFIAAgbIAJAAIAAAZQAAAPAKAAQADAAADgCIAEgGIABgEIAAgcIAJAAIAAAhIAAANIgIAAIAAgIQgCAEgEADQgEACgFAAIgFgBg");
	this.shape.setTransform(166.9,35.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#004470").s().p("AgLAYIAAgfIAAgPIAIAAIAAAJIAAAAQACgEADgDQADgDAEAAIADAAIAAAIIgDAAQgEAAgDADQgDADgBAFIAAAEIAAAYg");
	this.shape_1.setTransform(162.8,35.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#004470").s().p("AgDAFQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAABAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_2.setTransform(159.875,37.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#004470").s().p("AgSAYIAAgFIAUgbIAGgIIgZAAIAAgHIAkAAIAAAGIgUAaIgHAIIAbAAIAAAHg");
	this.shape_3.setTransform(156.65,35.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#004470").s().p("AgQASQgGgHAAgLQAAgKAHgHQAGgHAJAAQALAAAGAHQAGAHAAAKQAAAMgHAGQgHAHgJAAQgJAAgHgHgAgJgMQgEAGAAAGQAAAIAEAFQAEAFAFAAQAGAAAEgFQAEgFAAgIQAAgGgDgGQgEgFgHAAQgGAAgDAFg");
	this.shape_4.setTransform(151.725,35.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#004470").s().p("AgQAdQgFgHAAgLQAAgLAGgGQAGgHAJAAQAEAAAEACQAEACACADIAAgcIAIAAIAAA4IABAMIgIAAIAAgIIgBAAQgCAEgEADQgFACgEAAQgIAAgHgGgAgJgBQgDAEAAAIQgBAHAEAFQAEAFAFAAQAFAAADgCQAEgDABgFIABgEIAAgIIgBgEQgBgDgEgDQgCgCgGAAQgFAAgEAFg");
	this.shape_5.setTransform(146.05,34.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#004470").s().p("AAMAYIAAgaQAAgGgCgEQgDgEgGAAQgDAAgDACQgEADAAAEIgBAEIAAAbIgJAAIAAghIgBgNIAIAAIABAIQACgEAEgDQAEgCAFAAIAFABIAFADQADACACAEQABAEAAAGIAAAbg");
	this.shape_6.setTransform(140.6,35.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#004470").s().p("AgOAVQgEgEAAgGQAAgIAIgEQAHgFANABIAAgBIgBgEIgBgDIgDgDIgFgBQgHAAgGADIgCgGQAHgEAIAAQAKAAAEAGQAEAFAAAJIAAAQIABAMIgIAAIgBgGQgCADgEACQgEACgDAAQgHAAgEgEgAgJAKQAAAEACACQACACAEAAQADAAADgCIAFgFIAAgDIAAgIIgCAAQgRAAAAAKg");
	this.shape_7.setTransform(135.325,35.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#004470").s().p("AgPAWIADgHQAFADAGAAQAEAAACgCQACgCAAgDQAAgDgCgCQgCgCgEgBQgMgEAAgJQgBgGAFgEQAEgEAHAAQAHAAAFADIgDAHQgEgDgFAAQgDAAgCACQgBAAAAABQAAAAgBABQAAAAAAABQAAABAAAAQAAABAAABQAAAAAAABQABAAAAABQAAAAABABIAGADQAGADAEACQADADAAAGQAAAGgGAEQgEAEgHAAQgIAAgGgDg");
	this.shape_8.setTransform(131.1,35.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#004470").s().p("AgDAFQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_9.setTransform(128.125,37.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#004470").s().p("AALAYIgHgXIgEgOIgEAOIgHAXIgIAAIgOgvIAIAAIAHAXIADAQIAFgPIAHgYIAHAAIAHAXIAEAQIAEgQIAHgXIAIAAIgPAvg");
	this.shape_10.setTransform(123.375,35.625);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#004470").s().p("AALAYIgHgXIgEgOIgEAOIgHAXIgIAAIgOgvIAIAAIAHAXIADAQIAFgPIAHgYIAHAAIAHAXIAEAQIAEgQIAHgXIAIAAIgPAvg");
	this.shape_11.setTransform(116.075,35.625);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#004470").s().p("AALAYIgHgXIgEgOIgEAOIgHAXIgIAAIgOgvIAIAAIAHAXIADAQIAFgPIAHgYIAHAAIAHAXIAEAQIAEgQIAHgXIAIAAIgPAvg");
	this.shape_12.setTransform(108.775,35.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#004470").s().p("AgDAFQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAABAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_13.setTransform(101.975,37.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#004470").s().p("AgPAaIAHgBQAIAAAEgGQAHgFABgMQgFAIgJgBQgIABgFgGQgFgFgBgIQABgKAFgGQAHgHAJAAQAJAAAFAHQAHAIgBAMQABATgLAKQgIAHgKACIgIAAgAgIgVQgEAFAAAHQAAAFAEAEQACADAGAAQAEAAADgCQADgBACgDIAAgDQAAgIgCgGQgEgFgGAAQgFAAgDAEg");
	this.shape_14.setTransform(98.3,34.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#004470").s().p("AgPAZQgGgJAAgQQAAgOAGgJQAHgJAJAAQAKAAAFAIQAGAKAAAOQAAAPgGAKQgGAIgKAAQgJAAgGgIgAgIgSQgEAHAAALQAAANADAGQAEAIAFgBQAGABAEgIQADgGAAgNQAAgMgDgGQgDgHgHAAQgFAAgDAHg");
	this.shape_15.setTransform(93.175,34.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#004470").s().p("AgLADIAAgFIAXAAIAAAFg");
	this.shape_16.setTransform(89.05,35.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#004470").s().p("AgTAcIADgGQAFADAIAAQAGAAAEgDQAEgEAAgGQAAgHgEgEQgFgCgIAAIgJAAIAEgeIAeAAIAAAHIgYAAIgCAQIAFAAQAHAAAGADQAEADACADQADAEAAAGQAAAJgHAGQgGAGgKAAQgJAAgHgEg");
	this.shape_17.setTransform(84.825,34.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#004470").s().p("AgPAgIAag4IgeAAIAAgHIAnAAIAAAGIgaA5g");
	this.shape_18.setTransform(79.85,34.825);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#004470").s().p("AgLADIAAgFIAXAAIAAAFg");
	this.shape_19.setTransform(75.75,35.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#004470").s().p("AgPAZQgGgJAAgQQAAgOAGgJQAHgJAJAAQAKAAAFAIQAGAKAAAOQAAAPgGAKQgGAIgKAAQgJAAgGgIgAgIgSQgEAHAAALQAAANADAGQAEAIAFgBQAGABAEgIQADgGAAgNQAAgMgDgGQgDgHgHAAQgFAAgDAHg");
	this.shape_20.setTransform(71.625,34.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#004470").s().p("AgPAZQgGgHAAgMQAAgRALgLQAIgIALgBIAHgBIAAAHIgHABQgJABgFAGQgGAHgBAIIAAAAQAGgHAJAAQAIAAAFAFQAGAFAAAJQAAAKgGAGQgGAHgJAAQgKAAgGgIgAgGgBQgEACgCADIAAAEQAAAIADAFQAEAFAGAAQAFAAAEgEQADgEAAgHQAAgHgEgEQgDgDgGAAQgDAAgDACg");
	this.shape_21.setTransform(66.525,34.825);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#004470").s().p("AgPAZQgGgHAAgMQAAgRALgLQAIgIALgBIAHgBIAAAHIgHABQgJABgFAGQgGAHgBAIIAAAAQAGgHAJAAQAIAAAFAFQAGAFAAAJQAAAKgGAGQgGAHgJAAQgKAAgGgIgAgGgBQgEACgCADIAAAEQAAAIADAFQAEAFAGAAQAFAAAEgEQADgEAAgHQAAgHgEgEQgDgDgGAAQgDAAgDACg");
	this.shape_22.setTransform(61.375,34.825);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#004470").s().p("AgJAoQALgSAAgWQAAgWgLgRIAHAAQAMARAAAWQAAAXgMARg");
	this.shape_23.setTransform(55.025,35.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#004470").s().p("AgTAcIADgGQAFADAIAAQAGAAAEgDQAEgEAAgGQAAgHgEgEQgFgCgIAAIgJAAIAEgeIAeAAIAAAHIgYAAIgCAQIAFAAQAHAAAGADQAEADACADQADAEAAAGQAAAJgHAGQgGAGgKAAQgJAAgHgEg");
	this.shape_24.setTransform(51.075,34.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#004470").s().p("AgPAaIAHgBQAIAAAEgGQAHgFACgMQgGAIgJgBQgIABgGgGQgEgFAAgIQgBgKAHgGQAGgHAIAAQAKAAAGAHQAFAIABAMQAAATgMAKQgHAHgKACIgIAAgAgJgVQgDAFAAAHQAAAFADAEQADADAGAAQAEAAADgCQADgBACgDIABgDQAAgIgEgGQgDgFgGAAQgFAAgEAEg");
	this.shape_25.setTransform(46.15,34.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#004470").s().p("AAGAgIAAgSIgcAAIAAgFIAbgoIAJAAIAAAnIAJAAIAAAGIgJAAIAAASgAABgNIgPAUIAAABIAUAAIAAgVIABgKIgBAAg");
	this.shape_26.setTransform(40.975,34.825);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#004470").s().p("AADAoQgMgRAAgXQAAgWAMgRIAHAAQgMAQAAAXQAAAWAMASg");
	this.shape_27.setTransform(37.225,35.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#004470").s().p("AgPAgIAag4IgeAAIAAgHIAnAAIAAAGIgbA5g");
	this.shape_28.setTransform(30.9,34.825);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#004470").s().p("AgCAaIAAgXIgWAAIAAgFIAWAAIAAgXIAFAAIAAAXIAWAAIAAAFIgWAAIAAAXg");
	this.shape_29.setTransform(23.175,35.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#004470").s().p("AgDAFQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_30.setTransform(17.075,37.475);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#004470").s().p("AgUASIAEgDQADgCACgEIABgNIAAgTIAfAAIAAAuIgJAAIAAgnIgOAAIAAAMQAAAKgCAGQgBAHgFACQgEADgFAAg");
	this.shape_31.setTransform(13.1,35.65);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#004470").s().p("AgOASQgGgGAAgLQAAgKAGgHQAHgIAJAAQAFAAAEADQAEACACADIADAHIABAIIAAADIghAAQAAAIAFAEQAFAEAFAAQAJAAAFgCIACAGQgIADgJAAQgJAAgHgHgAgHgNQgEAEgBAFIAYAAQABgFgDgEQgCgEgHAAQgFAAgDAEg");
	this.shape_32.setTransform(8.4,35.625);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#004470").s().p("AgEAhIAAg6IgUAAIAAgHIAxAAIAAAHIgVAAIAAA6g");
	this.shape_33.setTransform(3.45,34.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#004470").s().p("AgDAFQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAABAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_34.setTransform(207.375,27.575);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#004470").s().p("AgTAcIACgGQAHAEAIAAQAGAAAEgDQADgEAAgFQAAgGgFgDQgFgEgFAAIgGAAIAAgFIAGAAQAEAAAFgDQADgDAAgFQABgEgDgDQgDgDgEAAQgIAAgFAFIgDgHQAIgFAJAAQAIAAAFAEQAEAFAAAGQAAAGgCADQgDAFgGACQAGABAEADQAEAFAAAGQAAAIgGAFQgGAGgKAAQgKAAgHgFg");
	this.shape_35.setTransform(203.55,24.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#004470").s().p("AgDAFQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_36.setTransform(197.975,27.575);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#004470").s().p("AALAYIAAgoIgVAAIAAAoIgIAAIAAgvIAmAAIAAAvg");
	this.shape_37.setTransform(194.15,25.725);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#004470").s().p("AgVAiIAAgyIgBgQIAIAAIABAIQAFgJALAAQAIAAAGAHQAGAHAAAKQAAAMgGAGQgHAHgJgBQgDAAgEgCQgEgCgCgDIgBAAIAAAagAgHgXQgEADgBAFIgBADIAAAIIABADQABAFAEACQADADAEAAQAHAAADgFQAEgEAAgIQAAgIgEgFQgDgFgHAAQgDAAgEADg");
	this.shape_38.setTransform(188.775,26.65);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#004470").s().p("AgQASQgGgHAAgLQAAgKAHgHQAGgHAJAAQALAAAGAHQAGAHAAAKQAAAMgHAGQgHAHgJAAQgJAAgHgHgAgJgMQgEAGAAAGQAAAIAEAFQAEAFAFAAQAGAAAEgFQAEgFAAgIQAAgGgDgGQgEgFgHAAQgGAAgDAFg");
	this.shape_39.setTransform(183.075,25.725);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#004470").s().p("AALAYIgFgKQgCgGgEgCQgDgDgFAAIgCAAIAAAVIgJAAIAAgvIAJAAIAAAVIACAAIARgVIAKAAIgTAWQAEAAAEADQAEAEADAGIAFAMg");
	this.shape_40.setTransform(178.275,25.725);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#004470").s().p("AgBgKIAJgBIgFAMIgEALIgGAAQAEgKACgMg");
	this.shape_41.setTransform(172.275,28.075);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#004470").s().p("AgDAFQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_42.setTransform(170.325,27.575);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#004470").s().p("AgTAgIAAgFIAGgGQANgNAFgHQAFgGAAgHQAAgFgDgEQgDgDgFAAQgHAAgHAFIgDgGQAIgGAKAAQAJAAAFAFQAFAGAAAHQAAAJgFAGQgGAIgKALIgFAEIAAAAIAbAAIAAAHg");
	this.shape_43.setTransform(166.575,24.85);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#004470").s().p("AgPAgIAag4IgeAAIAAgHIAnAAIAAAGIgaA5g");
	this.shape_44.setTransform(161.55,24.925);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#004470").s().p("AgDAFQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAABAAAAQABAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQAAAAgBAAQAAABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_45.setTransform(157.975,27.575);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#004470").s().p("AARAfIgBgPIgfAAIgBAPIgHAAIAAgVIAEAAQADgFACgFQACgIAAgKIAAgMIAfAAIAAAoIAFAAIgBAVgAgEgQQAAAKgCAHIgFAJIAWAAIAAgiIgPAAg");
	this.shape_46.setTransform(154.1,26.475);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#004470").s().p("AgBgKIAJgBIgFAMIgEALIgGAAQAEgKACgMg");
	this.shape_47.setTransform(148.275,28.075);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#004470").s().p("AgDAYIAAgoIgPAAIAAgHIAlAAIAAAHIgOAAIAAAog");
	this.shape_48.setTransform(145.25,25.725);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#004470").s().p("AALAYIgFgKQgCgGgEgCQgDgDgFAAIgCAAIAAAVIgJAAIAAgvIAJAAIAAAVIACAAIARgVIAKAAIgTAWQAEAAAEADQAEAEADAGIAFAMg");
	this.shape_49.setTransform(141.125,25.725);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#004470").s().p("AgNASQgHgGAAgLQAAgKAHgHQAFgIAKAAQAFAAAEADQAEACACADIADAHIABAIIAAADIghAAQABAIAEAEQAEAEAHAAQAHAAAGgCIACAGQgIADgIAAQgKAAgGgHgAgHgNQgEAEgBAFIAZAAQAAgFgDgEQgCgEgHAAQgFAAgDAEg");
	this.shape_50.setTransform(135.9,25.725);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#004470").s().p("AALAYIAAgoIgVAAIAAAoIgJAAIAAgvIAmAAIAAAvg");
	this.shape_51.setTransform(130.75,25.725);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#004470").s().p("AgLASQgHgGAAgLQAAgKAHgIQAIgHAKAAQAHAAAFADIgCAGQgEgCgGAAQgHAAgEAFQgFAGAAAGQAAAIAFAFQAEAFAHAAQAFAAAFgCIACAGQgGADgIAAQgKAAgGgHg");
	this.shape_52.setTransform(125.825,25.725);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#004470").s().p("AgQASQgGgHAAgLQAAgKAHgHQAGgHAJAAQALAAAGAHQAGAHAAAKQAAAMgHAGQgHAHgJAAQgJAAgHgHgAgJgMQgEAGAAAGQAAAIAEAFQAEAFAFAAQAGAAAEgFQAEgFAAgIQAAgGgDgGQgEgFgHAAQgGAAgDAFg");
	this.shape_53.setTransform(120.825,25.725);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#004470").s().p("AgVAiIAAgyIgBgQIAIAAIABAIQAFgJALAAQAIAAAGAHQAGAHAAAKQAAAMgGAGQgHAHgJgBQgDAAgEgCQgEgCgCgDIgBAAIAAAagAgHgXQgEADgBAFIgBADIAAAIIABADQABAFAEACQADADAEAAQAHAAADgFQAEgEAAgIQAAgIgEgFQgDgFgHAAQgDAAgEADg");
	this.shape_54.setTransform(115.375,26.65);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#004470").s().p("AALAYIAAgoIgVAAIAAAoIgIAAIAAgvIAlAAIAAAvg");
	this.shape_55.setTransform(109.75,25.725);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#004470").s().p("AAMAhIAAgUIABgSIgBAAIgIANIgGAOIgHALIgKAAIAAguIAIAAIAAATIgBATIABAAIAHgPIAOgXIAKAAIAAAugAgJgYQgDgDAAgFIAGAAIACAFQABAAAAABQABAAAAAAQABAAAAABQABAAAAAAQAFAAABgHIAHAAQgBAFgDAEQgEADgFAAQgGAAgDgEg");
	this.shape_56.setTransform(102.125,24.775);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#004470").s().p("AAMAYIAAgUIABgTIgBAAIgIAPIgGAMIgHAMIgKAAIAAgvIAIAAIAAAUIgBASIABAAIAHgOIAOgYIAKAAIAAAvg");
	this.shape_57.setTransform(96.625,25.725);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#004470").s().p("AALAYIgFgKQgCgGgEgCQgDgDgFAAIgCAAIAAAVIgJAAIAAgvIAJAAIAAAVIACAAIARgVIAKAAIgTAWQAEAAAEADQAEAEADAGIAFAMg");
	this.shape_58.setTransform(91.775,25.725);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#004470").s().p("AgLASQgHgGAAgLQAAgKAHgIQAIgHAKAAQAHAAAFADIgCAGQgEgCgGAAQgHAAgEAFQgFAGAAAGQAAAIAFAFQAEAFAHAAQAFAAAFgCIACAGQgGADgIAAQgKAAgGgHg");
	this.shape_59.setTransform(86.875,25.725);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#004470").s().p("AARAfIgBgPIggAAIAAAPIgHAAIAAgVIAEAAQADgFABgFQADgIAAgKIAAgMIAfAAIAAAoIAFAAIAAAVgAgEgQQAAAKgDAHIgDAJIAUAAIAAgiIgOAAg");
	this.shape_60.setTransform(81.85,26.475);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#004470").s().p("AgOAVQgEgEAAgGQAAgIAIgEQAHgFANABIAAgBIgBgEIgBgDIgDgDIgFgBQgHAAgGADIgCgGQAHgEAIAAQAKAAAEAGQAEAFAAAJIAAAQIABAMIgIAAIgBgGQgCADgEACQgEACgDAAQgHAAgEgEgAgJAKQAAAEACACQACACAEAAQADAAADgCIAFgFIAAgDIAAgIIgCAAQgRAAAAAKg");
	this.shape_61.setTransform(76.775,25.725);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#004470").s().p("AgVAiIAAgyIgBgQIAIAAIABAIQAFgJALAAQAIAAAGAHQAGAHAAAKQAAAMgGAGQgHAHgJgBQgDAAgEgCQgEgCgCgDIgBAAIAAAagAgHgXQgEADgBAFIgBADIAAAIIABADQABAFAEACQADADAEAAQAHAAADgFQAEgEAAgIQAAgIgEgFQgDgFgHAAQgDAAgEADg");
	this.shape_62.setTransform(71.825,26.65);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#004470").s().p("AgNAYIAAgvIAcAAIAAAHIgUAAIAAAog");
	this.shape_63.setTransform(67.2,25.725);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#004470").s().p("AALAYIAAgWIgVAAIAAAWIgJAAIAAgvIAJAAIAAATIAVAAIAAgTIAJAAIAAAvg");
	this.shape_64.setTransform(62.275,25.725);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#004470").s().p("AAMAYIAAgUIABgTIgBAAIgIAPIgGAMIgHAMIgKAAIAAgvIAIAAIAAAUIgBASIABAAIAHgOIAOgYIAKAAIAAAvg");
	this.shape_65.setTransform(56.825,25.725);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#004470").s().p("AALAYIAAgWIgVAAIAAAWIgJAAIAAgvIAJAAIAAATIAVAAIAAgTIAJAAIAAAvg");
	this.shape_66.setTransform(51.325,25.725);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#004470").s().p("AgOASQgGgGAAgLQAAgKAGgHQAHgIAJAAQAFAAAEADQAEACACADIADAHIABAIIAAADIghAAQAAAIAFAEQAFAEAFAAQAJAAAFgCIACAGQgIADgJAAQgJAAgHgHgAgHgNQgEAEgBAFIAYAAQABgFgDgEQgCgEgHAAQgFAAgDAEg");
	this.shape_67.setTransform(46.1,25.725);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#004470").s().p("AgZAbQAEgBADgDQAGgGAAgWIAAgbIAmAAIAABAIgJAAIAAg5IgVAAIAAAUIAAAJIgBAKIgDAKQgCAEgEACQgFAEgFgBg");
	this.shape_68.setTransform(40.275,24.85);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#004470").s().p("AgBgKIAJgBIgFAMIgEALIgGAAQAEgKACgMg");
	this.shape_69.setTransform(34.425,28.075);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#004470").s().p("AgOAVQgEgEAAgGQAAgIAIgEQAHgFANABIAAgBIgBgEIgBgDIgDgDIgFgBQgHAAgGADIgCgGQAHgEAIAAQAKAAAEAGQAEAFAAAJIAAAQIABAMIgIAAIgBgGQgCADgEACQgEACgDAAQgHAAgEgEgAgJAKQAAAEACACQACACAEAAQADAAADgCIAFgFIAAgDIAAgIIgCAAQgRAAAAAKg");
	this.shape_70.setTransform(30.925,25.725);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#004470").s().p("AgSAYIAAguIAPgBQAUAAAAAMQAAAEgDADQgDACgEABIAAABQAFAAAEACQADADAAAFQAAAOgYAAgAgKASIAHAAQAEAAAFgBQAEgCAAgFQAAgEgEgCQgEgCgGAAIgGAAgAgKgRIAAAOIAGAAQAFAAAEgBQADgCAAgEQAAgHgLAAg");
	this.shape_71.setTransform(26.325,25.725);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#004470").s().p("AALAYIgFgKQgCgGgEgCQgDgDgFAAIgCAAIAAAVIgJAAIAAgvIAJAAIAAAVIACAAIARgVIAKAAIgTAWQAEAAAEADQAEAEADAGIAFAMg");
	this.shape_72.setTransform(21.575,25.725);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#004470").s().p("AgLASQgHgGAAgLQAAgKAHgIQAIgHAKAAQAHAAAFADIgCAGQgEgCgGAAQgHAAgEAFQgFAGAAAGQAAAIAFAFQAEAFAHAAQAFAAAFgCIACAGQgGADgIAAQgKAAgGgHg");
	this.shape_73.setTransform(16.675,25.725);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#004470").s().p("AgQASQgGgHAAgLQAAgKAHgHQAGgHAJAAQALAAAGAHQAGAHAAAKQAAAMgHAGQgHAHgJAAQgJAAgHgHgAgJgMQgEAGAAAGQAAAIAEAFQAEAFAFAAQAGAAAEgFQAEgFAAgIQAAgGgDgGQgEgFgHAAQgGAAgDAFg");
	this.shape_74.setTransform(11.625,25.725);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#004470").s().p("AAZAhIgBgdIgBgcIgJAYIgLAhIgGAAIgLggIgHgZIgCAdIgBAcIgJAAIAFhBIALAAIALAgIAGAVIAAAAQACgJAFgMIAMggIALAAIAEBBg");
	this.shape_75.setTransform(4.925,24.8);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#004470").s().p("AgBgKIAJgBIgFAMIgEALIgGAAQAEgKACgMg");
	this.shape_76.setTransform(94.375,18.175);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#004470").s().p("AgTAcIADgGQAFADAIAAQAGAAAEgDQAEgEAAgGQAAgHgEgEQgFgCgIAAIgJAAIAEgeIAeAAIAAAHIgYAAIgCAQIAFAAQAHAAAGADQAEADACADQADAEAAAGQAAAJgHAGQgGAGgKAAQgJAAgHgEg");
	this.shape_77.setTransform(90.775,15.075);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#004470").s().p("AACAgIAAg3IgKAGIgCgHIANgHIAIAAIAAA/g");
	this.shape_78.setTransform(85.475,15.025);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#004470").s().p("AgTAcIADgGQAGAEAHAAQAHAAAEgDQADgEAAgFQAAgGgFgDQgEgEgHAAIgEAAIAAgFIAEAAQAFAAAEgDQAFgDAAgFQAAgEgDgDQgDgDgFAAQgGAAgGAFIgCgHQAGgFAKAAQAIAAAEAEQAFAFABAGQAAAGgEADQgCAFgHACQAHABAEADQAEAFAAAGQAAAIgHAFQgFAGgLAAQgJAAgHgFg");
	this.shape_79.setTransform(80.75,15);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#004470").s().p("AgTAcIADgGQAFADAIAAQAGAAAEgDQAEgEAAgGQAAgHgEgEQgFgCgIAAIgJAAIAEgeIAeAAIAAAHIgYAAIgCAQIAFAAQAHAAAGADQAEADACADQADAEAAAGQAAAJgHAGQgGAGgKAAQgJAAgHgEg");
	this.shape_80.setTransform(75.725,15.075);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#004470").s().p("AgTAgIAAgFIAGgGQANgNAFgHQAFgGAAgHQAAgFgDgEQgDgDgFAAQgHAAgHAFIgDgGQAIgGAKgBQAJABAFAFQAFAGAAAHQAAAIgFAHQgGAIgKALIgFAEIAAAAIAbAAIAAAHg");
	this.shape_81.setTransform(70.775,14.95);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#004470").s().p("AACAgIAAg3IgKAGIgCgHIANgHIAIAAIAAA/g");
	this.shape_82.setTransform(65.375,15.025);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#004470").s().p("AgBgKIAJgBIgFAMIgEALIgGAAQAEgKACgMg");
	this.shape_83.setTransform(60.175,18.175);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#004470").s().p("AgBASIAMgSIgMgRIAGAAIANARIgNASgAgRASIANgSIgNgRIAHAAIAMARIgMASg");
	this.shape_84.setTransform(57.175,15.75);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#004470").s().p("AgRAVIADgGQAFADAHAAQAFAAACgCQADgCAAgEQAAgIgMAAIgFAAIAAgFIAFAAQAEAAAEgCQADgCAAgEQAAgDgCgCQgEgBgDAAQgFAAgGADIgCgFQAHgFAIAAIAHABQAEACADADQACACAAAFQAAAEgDADQgDADgFABQAGAAAEADQADADAAAFQAAAHgGADQgGAEgIAAQgIAAgHgEg");
	this.shape_85.setTransform(53,15.825);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#004470").s().p("AgQASQgGgHAAgLQAAgKAHgHQAGgHAJAAQALAAAGAHQAGAHAAAKQAAAMgHAGQgHAHgJAAQgJAAgHgHgAgJgMQgEAGAAAGQAAAIAEAFQAEAFAFAAQAGAAAEgFQAEgFAAgIQAAgGgDgGQgEgFgHAAQgGAAgDAFg");
	this.shape_86.setTransform(48.225,15.825);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#004470").s().p("AAQAfIAAgPIggAAIAAAPIgHAAIAAgVIAEAAQADgFABgFQADgIAAgKIAAgMIAfAAIAAAoIAFAAIAAAVgAgEgQQAAAKgDAHIgDAJIAUAAIAAgiIgOAAg");
	this.shape_87.setTransform(42.9,16.575);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#004470").s().p("AALAYIAAgWIgVAAIAAAWIgJAAIAAgvIAJAAIAAATIAVAAIAAgTIAJAAIAAAvg");
	this.shape_88.setTransform(37.725,15.825);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#004470").s().p("AgOAVQgEgEAAgGQAAgIAIgEQAHgFANABIAAgBIgBgEIgBgDIgDgDIgFgBQgHAAgGADIgCgGQAHgEAIAAQAKAAAEAGQAEAFAAAJIAAAQIABAMIgIAAIgBgGQgCADgEACQgEACgDAAQgHAAgEgEgAgJAKQAAAEACACQACACAEAAQADAAADgCIAFgFIAAgDIAAgIIgCAAQgRAAAAAKg");
	this.shape_89.setTransform(32.575,15.825);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#004470").s().p("AgPAZQgJgIAAgRQAAgOAJgKQAKgJAOAAQALAAAFADIgCAHQgGgDgHAAQgLAAgHAHQgHAIAAALQAAANAGAGQAIAIAKAAQAJAAAGgDIABAHQgGADgLAAQgOAAgJgJg");
	this.shape_90.setTransform(27.5,14.9);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#004470").s().p("AALASIgMgSIAMgRIAHAAIgNARIANASgAgEASIgNgSIANgRIAFAAIgLARIAMASg");
	this.shape_91.setTransform(22.65,15.75);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#004470").s().p("AgVAZQgIgJAAgQQAAgOAIgKQAJgJAMAAQAOAAAIAJQAIAJAAAPQAAAQgJAJQgIAJgNAAQgNAAgIgJgAgPgSQgFAHAAALQAAAMAGAHQAFAIAJAAQAKAAAFgIQAGgHAAgMQAAgKgFgIQgGgIgKgBQgJAAgGAJg");
	this.shape_92.setTransform(15.175,14.9);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#004470").s().p("AASAhIgGgVIgXAAIgHAVIgJAAIAXhBIAJAAIAWBBgAAKAGIgGgSIgEgNIAAAAIgCANIgHASIATAAg");
	this.shape_93.setTransform(8.8,14.9);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#004470").s().p("AgUAdIADgGQAHAEAHAAQAGAAAEgDQAFgEAAgFQAAgHgGgDQgFgDgGAAIgEAAIAAgFIADAAQAGAAAFgEQAEgEAAgFQAAgFgDgDQgDgDgFAAQgHABgHAEIgCgGQAIgFAKAAQAHAAAGAEQAFAFAAAHQAAAGgEAEQgEAFgGABIAAABQAHAAAFADQAEAFABAHQAAAKgHAEQgHAFgJAAQgKAAgIgFg");
	this.shape_94.setTransform(3.375,14.9);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#004470").s().p("AgPAZQgGgJAAgQQAAgOAGgJQAHgJAJAAQAKAAAFAIQAGAKAAAOQAAAPgGAKQgGAIgKAAQgJAAgGgIgAgIgSQgEAHAAALQAAANADAGQAEAIAFgBQAGABAEgIQADgGAAgNQAAgMgDgGQgDgHgHAAQgFAAgDAHg");
	this.shape_95.setTransform(60.325,5.1);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#004470").s().p("AgPAZQgGgJAAgQQAAgOAGgJQAHgJAJAAQAKAAAFAIQAGAKAAAOQAAAPgGAKQgGAIgKAAQgJAAgGgIgAgIgSQgEAHAAALQAAANADAGQAEAIAFgBQAGABAEgIQADgGAAgNQAAgMgDgGQgDgHgHAAQgFAAgDAHg");
	this.shape_96.setTransform(55.275,5.1);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#004470").s().p("AgPAgIAag4IgeAAIAAgHIAnAAIAAAGIgaA5g");
	this.shape_97.setTransform(50.3,5.125);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#004470").s().p("AgQAgIAbg4IgeAAIAAgHIAnAAIAAAGIgbA5g");
	this.shape_98.setTransform(45.25,5.125);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#004470").s().p("AgTAgIAAgFIAGgGQANgNAFgHQAFgGAAgHQAAgFgDgEQgDgDgFAAQgHAAgHAFIgDgGQAIgGAKgBQAJABAFAFQAFAGAAAHQAAAIgFAHQgGAIgKALIgFAEIAAAAIAbAAIAAAHg");
	this.shape_99.setTransform(40.175,5.05);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#004470").s().p("AgQAgIAbg4IgeAAIAAgHIAnAAIAAAGIgbA5g");
	this.shape_100.setTransform(35.25,5.125);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#004470").s().p("AgPAaIAHAAQAIgBAEgGQAHgFABgMQgFAIgJgBQgIABgGgGQgEgFAAgIQAAgKAFgGQAHgHAIAAQAKAAAGAHQAFAIAAAMQAAATgLAKQgHAHgKACIgIAAgAgJgVQgDAFAAAGQAAAGADAEQAEADAFAAQADAAAEgCQADgBACgDIAAgDQAAgIgDgGQgDgFgGAAQgFAAgEAEg");
	this.shape_101.setTransform(30.2,5.1);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#004470").s().p("AgPAZQgGgJAAgQQAAgOAGgJQAHgJAJAAQAKAAAFAIQAGAKAAAOQAAAPgGAKQgGAIgKAAQgJAAgGgIgAgIgSQgEAHAAALQAAANADAGQAEAIAFgBQAGABAEgIQADgGAAgNQAAgMgDgGQgDgHgHAAQgFAAgDAHg");
	this.shape_102.setTransform(25.175,5.1);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#004470").s().p("AgPAaIAHAAQAIgBAEgGQAHgFACgMQgGAIgJgBQgIABgFgGQgGgFABgIQgBgKAHgGQAGgHAIAAQAKAAAFAHQAHAIAAAMQgBATgKAKQgIAHgKACIgIAAgAgJgVQgDAFAAAGQAAAGADAEQAEADAFAAQADAAAEgCQADgBACgDIABgDQAAgIgEgGQgDgFgGAAQgFAAgEAEg");
	this.shape_103.setTransform(20.15,5.1);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#004470").s().p("AACAgIAAg3IgKAGIgCgHIANgHIAIAAIAAA/g");
	this.shape_104.setTransform(14.675,5.125);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#004470").s().p("AgRAbQgGgHAAgPIAAglIAIAAIAAAlQAAALAEAFQAFAFAGABQAHgBAEgFQAFgFAAgLIAAglIAIAAIAAAlQAAAOgHAIQgGAGgLAAQgLABgGgHg");
	this.shape_105.setTransform(9.425,5.05);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#004470").s().p("AAMAhQgBgCgCgOQgCgGgDgDQgDgDgFAAIgIAAIAAAcIgJAAIAAhAQAIgBAJAAQAMAAAGAFQAFAFAAAIQAAAGgDAEQgEAEgFABIAAABQAHACADALIAEASgAgMgZIAAAYIAIAAQAGAAAFgDQAEgEgBgFQABgHgEgDQgFgDgGAAIgIABg");
	this.shape_106.setTransform(3.9,4.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ33, new cjs.Rectangle(0,0,211.2,41.5), null);


(lib.Символ32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._3();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ32, new cjs.Rectangle(0,0,238,339.5), null);


(lib.Символ31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAdB7IgHgtIguAAIgHAtIgjAAIAmj0IA4AAIAoD0gAAQAsIgRh6IgTB6IAkAAg");
	this.shape.setTransform(73.25,16);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAYB7IgkhiIgMAXIAABLIgnAAIAAj0IAnAAIAABqIAyhqIAmAAIg2BtIA2CHg");
	this.shape_1.setTransform(57.475,16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgqBuQgPgQAAgeIAAh/QAAgdAPgQQAOgQAcAAQAcAAAOAQQAPAQABAdIAAAYIglAAIAAgaQAAgNgGgGQgFgFgJAAQgIAAgGAFQgFAGAAANIAACDQAAAOAFAFQAGAFAIAAQAJAAAFgFQAGgFAAgOIAAgjIAlAAIAAAhQgBAegPAQQgOAPgcAAQgcAAgOgPg");
	this.shape_2.setTransform(40.95,15.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAaB7IAAixIguCxIgoAAIAAj0IAiAAIAACRIAniRIAwAAIAAD0g");
	this.shape_3.setTransform(24.65,16);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("Ag4B7IAAj0IA4AAQAdAAAOAPQAOAQAAAdIAAAgQAAAdgOAPQgOAQgdAAIgRAAIAABcgAgRgDIARAAQAJAAAFgGQAFgEAAgOIAAglQAAgNgFgFQgFgEgJAAIgRAAg");
	this.shape_4.setTransform(9.1,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ31, new cjs.Rectangle(0,0,84.5,39), null);


(lib.Символ30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AghBRIAAihIBDAAIAAAYIgqAAIAAAtIAhAAIAAAVIghAAIAAAvIAqAAIAAAYg");
	this.shape.setTransform(76.15,11.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AARBRIAAh0IgeB0IgaAAIAAihIAXAAIAABgIAYhgIAgAAIAAChg");
	this.shape_1.setTransform(67.075,11.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAOBRIAAhGIgcAAIAABGIgZAAIAAihIAZAAIAABGIAcAAIAAhGIAaAAIAAChg");
	this.shape_2.setTransform(57.45,11.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgiBRIAAihIBFAAIAAAYIgrAAIAAAtIAhAAIAAAVIghAAIAAAvIArAAIAAAYg");
	this.shape_3.setTransform(48.75,11.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAtBRIgYhAIgIANIAAAzIgZAAIAAgzIgHgNIgZBAIgaAAIAjhZIgjhIIAZAAIAhBGIAAhGIAZAAIAABGIAihGIAYAAIgjBIIAjBZg");
	this.shape_4.setTransform(37.25,11.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AARBRIAAh0IgeB0IgaAAIAAihIAXAAIAABgIAYhgIAgAAIAAChg");
	this.shape_5.setTransform(25.225,11.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAOBRIAAhGIgcAAIAABGIgZAAIAAihIAZAAIAABGIAcAAIAAhGIAaAAIAAChg");
	this.shape_6.setTransform(15.6,11.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgbBIQgKgKAAgUIAAhTQAAgUAKgKQAJgKASAAQASAAAKAKQAKAKAAAUIAAAQIgYAAIAAgSQAAgIgEgDQgDgFgGAAQgFAAgEAFQgEADAAAIIAABXQAAAIAEADQAEAEAFAAQAGAAADgEQAEgDAAgIIAAgYIAYAAIAAAWQAAAUgKAKQgKAKgSAAQgSAAgJgKg");
	this.shape_7.setTransform(6.475,11.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ30, new cjs.Rectangle(0,0,82.2,27), null);


(lib.Символ29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AANA7IAAhNIgKAeIgOAvIgLAAIAAhhIAJAAIAABIIAKgdIAOgrIAMAAIAABhgAgOg6IAHAAQABAHAHAAQAHAAABgHIAHAAQAAAGgEAEQgEADgHABQgOAAgBgOg");
	this.shape.setTransform(76.725,6.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AANAxIAAhNIgKAfIgOAuIgLAAIAAhhIAJAAIAABIIALgeIANgqIAMAAIAABhg");
	this.shape_1.setTransform(68.925,7.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAMAxIAAgsIgXAAIAAAsIgLAAIAAhhIALAAIAAAsIAXAAIAAgsIALAAIAABhg");
	this.shape_2.setTransform(61.1,7.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgTAxIAAhhIAnAAIAAAKIgcAAIAAAhIAXAAIAAAJIgXAAIAAAjIAcAAIAAAKg");
	this.shape_3.setTransform(53.725,7.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAMAxIAAgsIgXAAIAAAsIgLAAIAAhhIALAAIAAAsIAXAAIAAgsIALAAIAABhg");
	this.shape_4.setTransform(46.2,7.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAeAxIgTguIgGAJIAAAlIgJAAIAAglIgGgKIgTAvIgLAAIAXg4IgWgpIALAAIAYAtIAAgtIAJAAIAAAtIAYgtIALAAIgWApIAWA4g");
	this.shape_5.setTransform(37,7.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgQAsQgFgHAAgLIAAgzQAAgLAFgHQAGgGAKAAQALAAAGAGQAFAHAAALIAAAzQAAALgFAHQgGAGgLAAQgKAAgGgGgAgLgZIAAAzQAAAOALAAQAMAAAAgOIAAgzQAAgOgMAAQgLAAAAAOg");
	this.shape_6.setTransform(27.925,7.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAQAxIAAhXIgSAAIgCA/QAAAMgEAGQgFAGgLAAIgCAAIAAgKQAHAAACgDQACgDAAgIIADhJIAnAAIAABhg");
	this.shape_7.setTransform(19.825,7.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgQAsQgFgHAAgLIAAgzQAAgLAFgGQAGgHAKAAQAKAAAHAHQAFAGAAALIAAAJIgLAAIAAgJQAAgOgLAAQgKAAAAAOIAAAzQAAAOAKAAQALAAAAgOIAAgNIALAAIAAANQAAALgFAHQgHAGgKAAQgKAAgGgGg");
	this.shape_8.setTransform(12.2,7.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgQAsQgFgHAAgLIAAgzQAAgLAFgHQAGgGAKAAQALAAAGAGQAFAHAAALIAAAzQAAALgFAHQgGAGgLAAQgKAAgGgGgAgLgZIAAAzQAAAOALAAQAMAAAAgOIAAgzQAAgOgMAAQgLAAAAAOg");
	this.shape_9.setTransform(4.725,7.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ29, new cjs.Rectangle(0,0,83.9,18), null);


(lib.Символ27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAAAEIgIASIgIgGIANgOIgTgCIADgKIASAJIgDgUIAJAAIgDAUIASgJIADAKIgTACIAOAOIgJAGg");
	this.shape.setTransform(74.625,4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAPBDIgDgZIgZAAIgDAZIgTAAIAUiEIAeAAIAWCEgAAJAZIgJhDIgKBDIATAAg");
	this.shape_1.setTransform(68.6,10.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgWA8QgIgKAAgQIAAgQIAUAAIAAASQAAAHADADQADADAEAAQAEAAADgDQADgDAAgJIAAgKQAAgJgDgFQgDgEgGABIgEAAIAAgSIAFAAQAFAAADgDQADgEAAgIIAAgHQAAgJgDgDQgDgDgEAAQgEAAgDADQgDADAAAHIAAAPIgUAAIAAgOQAAgQAIgIQAIgJAOAAQAPAAAIAJQAIAIAAAQIAAAEQAAAVgOAGQAIADADAHQADAHAAAKIAAAKQAAAQgIAKQgIAIgPAAQgOAAgIgIg");
	this.shape_2.setTransform(59.275,10.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAQBDIgEgZIgZAAIgEAZIgTAAIAViEIAfAAIAUCEgAAJAZIgJhDIgKBDIATAAg");
	this.shape_3.setTransform(50,10.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgeBDIAAiEIAeAAQAPAAAJAIQAHAIAAARIAAAQQAAAQgHAIQgJAIgPAAIgJAAIAAAzgAgJgCIAJAAQAFAAACgCQADgDAAgHIAAgUQAAgHgDgDQgCgCgFgBIgJAAg");
	this.shape_4.setTransform(41.1,10.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgfBDIAAiEIAfAAQAQAAAHAHQAHAIAAAPIAAAFQAAAKgDAHQgDAHgHADQAIADAEAGQADAIAAAKIAAALQAAAPgIAJQgIAHgPABgAgKAwIALAAQAFgBADgDQADgCAAgIIAAgLQAAgJgEgEQgDgDgGAAIgJAAgAgKgLIAIAAQAFAAADgDQADgEAAgIIAAgHQAAgHgCgEQgDgDgEAAIgKAAg");
	this.shape_5.setTransform(5.975,10.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ27, new cjs.Rectangle(0,0,79.5,24), null);


(lib.Символ26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgsBwQgOgQAAgfIAAgUIAlAAIAAAXQAAAOAFAFQAHAGAIAAQAJAAAGgGQAFgGAAgQIAAgUQAAgSgGgHQgGgHgNgBIgNAAIAAgjIAQAAQAJAAAHgFQAGgGAAgPIAAgOQAAgRgFgGQgGgGgJAAQgIAAgHAGQgFAFAAAOIAAAQIglAAIAAgOQAAgeAOgRQAPgQAdAAQAdAAAPAQQAPARAAAeIAAAHQAAApgcALQAQAGAFANQAHANAAAUIAAATQAAAfgPAQQgPARgdAAQgdAAgPgRg");
	this.shape.setTransform(9.15,16.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ26, new cjs.Rectangle(0,0,20.3,40), null);


(lib.Символ21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#008FAB","rgba(0,143,171,0)"],[0.008,1],-4.7,20.4,-4.7,-51.6).s().p("Ay6I5IABx0MAlXAAAIAdR3g");
	this.shape.setTransform(121.125,57.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ21, new cjs.Rectangle(0,0,242.3,114.4), null);


(lib.Символ20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgCADIgBgDIABgCQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQABABAAAAIABACQAAABAAAAQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape.setTransform(171.675,24.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgJAbIgFgEIADgGIAGAEIAFABIADgBIADgBIACgDQAAgBABAAQAAgBAAAAQAAgBAAgBQABAAAAgBIAAgJIgIADIgFABQgFAAgEgEQgEgDABgGIAAgHIABgGIADgFIAGgDIAFgBIAGABIAGADIADAFQABADAAADIAAAbQAAADgBADIgDAFIgGADIgGABQgFAAgEgCgAgDgUIgCABIgDADIgBAFIAAAEQAAAFADABQACABACAAIAFAAIAHgDIAAgIIgCgFIgCgDIgDgBIgDgBIgDABg");
	this.shape_1.setTransform(168.75,22.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJAbIgGgEIAEgGQAFAFAGAAIACgBIADgBIADgDQACgCAAgDIAAgHQAAgEgDgBQgBgCgEAAIgCABIgDABIgDAAIgCACIgGgCIAAgbIAdAAIAAAGIgWAAIAAAQIAFgDIAFgBIAGABIAEADIACAEIABAFIAAAJQAAAEgBACIgEAFQgCACgEABIgFABQgFAAgEgBg");
	this.shape_2.setTransform(164.8,22.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgKAcIATgxIgRAAIAAAIIgHAAIAAgOIAfAAIAAAGIgTAxg");
	this.shape_3.setTransform(160.75,22.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgLADIAAgFIAXAAIAAAFg");
	this.shape_4.setTransform(157.175,22.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgGAcIgFgEIgEgEQgBgEgBgEIABgDIACgFIADgCIACgCQgDgBgBgEQgDgDAAgEQAAgDACgDIAEgGIAFgCIAFgBIAGABIAFACIAEAGQABADABADIgCAHQgCAEgDABIAEACIACACIABAFIAAADQABAFgCADIgEAEIgFAEIgHABIgGgBgAgDADIgDACIgDAEIAAADQAAAFACADQADACAEAAQAFAAACgCQADgDAAgFIgBgDIgCgEIgDgCIgEAAIgDAAgAgCgVIgEADIgCADIgBADIABAEIACADIAEACIACAAIAEAAIADgCIABgDIABgEIAAgDIgCgDIgDgDIgEAAIgCAAg");
	this.shape_5.setTransform(153.6,22.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAGAcIAAgIIgXAAIAAgHIAJgTIAIgVIAIAAIgRAoIAPAAIAAgQIAIAAIAAAQIAEAAIAAAHIgEAAIAAAIg");
	this.shape_6.setTransform(149.55,22.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgKAcIATgxIgRAAIAAAIIgHAAIAAgOIAgAAIAAAGIgUAxg");
	this.shape_7.setTransform(145.55,22.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgCADIgBgDIABgCQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAABABAAIABACQAAABAAAAQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_8.setTransform(140.775,24.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgPAcIAAg3IAGAAIABAEIAHgDIAEgBQAGgBADAEQAEADABAIIAAANQgBAFgEAEQgDAEgHAAIgEgBIgGgCIAAASgAAAgUIgDABIgDACIgCABIAAAUIAFACIAFABIADgBIACgBIACgDIABgCIAAgNQAAgEgCgBQgDgCgDAAg");
	this.shape_9.setTransform(137.9,23.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgDAUIAAghIgMAAIAAgGIAfAAIAAAGIgMAAIAAAhg");
	this.shape_10.setTransform(134.2,23.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgEAUIgFgDIgEgFIgBgGIAAgLIABgGIAEgFIAFgDIAFgBIAHABQAEABADADIgFAGIgEgDIgFgBIgCAAIgDACIgCADIgBAEIAAAJIABAEIACADIADACIACAAIAFgBQACAAACgCIAFAFQgDADgEABIgHABIgFgBg");
	this.shape_11.setTransform(130.9,23.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgEAHIADgEIABgDQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAIgBgDQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABgBQAAAAAAAAQAAAAABgBQAAAAABAAQAAAAAAAAIACABIADABIAAACIABADIgBADIgCADIgDAEIgCACg");
	this.shape_12.setTransform(126.15,25.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgQAcIAAgGIABgGIADgGIAFgEIAFgFIAEgCIADgDIADgEIABgEIgBgEIgCgDIgDgBIgDAAIgHABIgFACIgDgEIAGgFQAEgCAFABIAFAAIAGADIAEAFQACACAAAFIgCAFIgEAGIgEADIgFAEIgDACIgDADIgDAFQgBAAAAABQAAAAAAABQgBAAAAABQAAAAAAABIAAADIAZAAIAAAFg");
	this.shape_13.setTransform(123.125,22.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgQAcIAAgGIABgGIADgGIAFgEIAFgFIAEgCIADgDIADgEIABgEIgBgEIgCgDIgDgBIgDAAIgHABIgFACIgDgEIAGgFQAEgCAFABIAFAAIAGADIAEAFQACACAAAFIgCAFIgEAGIgEADIgFAEIgDACIgDADIgDAFQgBAAAAABQAAAAAAABQgBAAAAABQAAAAAAABIAAADIAZAAIAAAFg");
	this.shape_14.setTransform(119.125,22.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AANAUIAAgYIAAAAIgEAHIgHALIgDAAIgGgJIgFgJIAAAAIAAAYIgHAAIAAgnIAGAAIAIAPIAFAKIAGgKIAIgPIAGAAIAAAng");
	this.shape_15.setTransform(112.775,23.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgFAUIgGgDIgDgFIgBgGIAAgLIABgGIADgFIAGgDIAFgBIAGABIAGADIADAFQACADgBADIAAALQABADgCADIgDAFIgGADIgGABIgFgBgAgCgNIgDACIgDADIgBAEIAAAJIABAEIACADIADACIADAAIADAAIADgCIACgDIABgEIAAgJIgBgEIgCgDIgDgCIgDAAg");
	this.shape_16.setTransform(108.35,23.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgDAUIAAghIgMAAIAAgGIAfAAIAAAGIgMAAIAAAhg");
	this.shape_17.setTransform(104.65,23.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgFAHIADgEIACgDQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAIgBgDQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBQABAAAAAAQAAAAABgBQAAAAABAAQAAAAAAAAIADABIABABIABACIAAADIgBADIgBADIgDAEIgCACg");
	this.shape_18.setTransform(100,25.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgFAcIgGgDQgCgCgBgDQgCgCAAgEIAAgbQAAgDACgDIADgFIAGgDIAFgBIAGABIAGADIADAFQACADAAADIAAAbQAAAEgCACQgBADgCACIgGADIgGABIgFgBgAgCgUIgDABIgDADIgBAFIAAAXIABAFIADADIADACIACAAIAEAAIADgCIACgDIABgFIAAgXIgBgFIgCgDIgDgBIgEgBg");
	this.shape_19.setTransform(97,22.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgFAcIgFgDQgDgCgCgDQgBgCAAgEIAAgbQAAgDABgDIAFgFIAFgDIAFgBIAGABIAFADIAFAFQABADAAADIAAAbQAAAEgBACQgCADgDACIgFADIgGABIgFgBgAgCgUIgEABIgCADIAAAFIAAAXIAAAFIACADIAEACIACAAIADAAIAEgCIACgDIABgFIAAgXIgBgFIgCgDIgEgBIgDgBg");
	this.shape_20.setTransform(93,22.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgFAcIgFgDQgDgCgCgDQgBgCAAgEIAAgbQAAgDABgDIAFgFIAFgDIAFgBIAGABIAFADIAFAFQABADAAADIAAAbQAAAEgBACQgCADgDACIgFADIgGABIgFgBgAgCgUIgEABIgCADIAAAFIAAAXIAAAFIACADIAEACIACAAIADAAIAEgCIACgDIABgFIAAgXIgBgFIgCgDIgEgBIgDgBg");
	this.shape_21.setTransform(88.95,22.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgQAcIAAgGIABgGIADgGIAFgEIAFgFIAEgCIADgDIADgEIABgEIgBgEIgCgDIgDgBIgDAAIgHABIgFACIgDgEIAGgFQAEgCAFABIAFAAIAGADIAEAFQACACAAAFIgCAFIgEAGIgEADIgFAEIgDACIgDADIgDAFQgBAAAAABQAAAAAAABQgBAAAAABQAAAAAAABIAAADIAZAAIAAAFg");
	this.shape_22.setTransform(84.975,22.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgEAHIACgEIACgDQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAIgBgDQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABgBQAAAAAAAAQAAAAABgBQAAAAABAAQAAAAAAAAIADABIACABIAAACIAAADIAAADIgCADIgDAEIgCACg");
	this.shape_23.setTransform(80,25.15);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAJAUIAAgQIgIAAIgEABQgCABgBAEIgCAKIgHAAIACgLIACgEQAAgBABAAQAAgBABAAQAAAAABAAQAAgBABAAQgEgBgBgCQgCgCAAgEIABgFIACgEIAEgCIAFgBIASAAIAAAngAgFgLQgBAAAAAAQgBABAAAAQAAABAAABQAAAAAAABQAAABAAABQAAAAAAABQAAAAABABQAAAAABAAQAAABABAAQAAAAABAAQAAABABAAQAAAAABAAIAKAAIAAgMIgKAAQAAAAgBAAQgBAAAAABQgBAAAAAAQgBAAAAABg");
	this.shape_24.setTransform(77.075,23.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAJAUIAAgcIAAAAIgGAIIgMAUIgHAAIAAgnIAHAAIAAAcIABAAIAGgJIAMgTIAGAAIAAAng");
	this.shape_25.setTransform(73.15,23.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAJAUIAAghIgSAAIAAAhIgHAAIAAgnIAgAAIAAAng");
	this.shape_26.setTransform(69.1,23.025);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgMARQgDgDAAgGQgBgDACgCIADgDIAFgCIAFgBIALAAIAAgDQAAgEgCgCQgDgBgEAAIgFAAQgCABgDACIgEgFQAEgDAEgBIAGgBQAIAAAEAEQAEADAAAHIAAAaIgGAAIgBgDIAAgBIgIAEIgFABQgGAAgDgEgAgGADIgBACIgBADQAAABAAABQAAAAAAABQAAAAABABQAAAAABABQABABADAAIADAAIADgBIADgCIADgBIAAgIIgKAAIgDAAg");
	this.shape_27.setTransform(65,23.025);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgPAcIAAg3IAFAAIABAEIAIgDIAEgBQAGgBAEAEQADADAAAIIAAANQAAAFgDAEQgEAEgGAAIgFgBIgHgCIAAASgAAAgUIgDABIgCACIgEABIAAAUIAGACIAFABIADgBIACgBIACgDIAAgCIAAgNQAAgEgCgBQgCgCgCAAg");
	this.shape_28.setTransform(61.1,23.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgDgCgBgDIgBgGIAAgKIABgGQABgDADgCIAEgDQAEgCACAAQAEAAADACIAEADIAEAEQABADAAAEIAAAHIgZAAIAAACIABAEIACADIAEACIACAAIAGgBQACAAACgDIAFAFQgDADgEABQgEACgEAAIgFgBgAgCgNIgEACIgCADIAAAEIAAACIARAAIAAgCIgBgEIgBgDIgEgCIgDAAIgCAAg");
	this.shape_29.setTransform(57.2,23.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgDAUIAAghIgMAAIAAgGIAfAAIAAAGIgMAAIAAAhg");
	this.shape_30.setTransform(53.55,23.025);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAJAUIAAgQIgIAAIgEABQgCABgBAEIgCAKIgHAAIACgLIACgEQAAgBABAAQAAgBABAAQAAAAABAAQAAgBABAAQgEgBgBgCQgCgCAAgEIABgFIACgEIAEgCIAFgBIASAAIAAAngAgFgLQgBAAAAAAQAAABgBAAQAAABAAABQAAAAAAABQAAABAAABQAAAAAAABQABAAAAABQAAAAABAAQAAABABAAQAAAAABAAQAAABABAAQAAAAABAAIAKAAIAAgMIgKAAQAAAAgBAAQgBAAAAABQgBAAAAAAQgBAAAAABg");
	this.shape_31.setTransform(47.975,23.025);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgMARQgEgDABgGQAAgDABgCIADgDIAGgCIAEgBIALAAIAAgDQgBgEgCgCQgCgBgEAAIgFAAQgCABgEACIgDgFQAEgDAEgBIAGgBQAIAAAEAEQAEADgBAHIAAAaIgFAAIgBgDIAAgBIgIAEIgFABQgGAAgDgEgAgFADIgCACIgCADQAAABABABQAAAAAAABQAAAAABABQAAAAABABQACABACAAIADAAIADgBIADgCIADgBIAAgIIgKAAIgDAAg");
	this.shape_32.setTransform(44.1,23.025);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAJAUIgDgLIgBgDIgCgCIgDgBIgBAAIgIAAIAAARIgHAAIAAgnIAHAAIAAARIAHAAIACAAIABgBIADgBIABgEIADgLIAIAAIgEAMIgDAFIgDACQABAAAAAAQABAAAAAAQABAAAAABQABAAAAABIACAFIAEANg");
	this.shape_33.setTransform(40.3,23.025);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgEAUIgFgDIgEgFIgBgGIAAgLIABgGIAEgFIAFgDIAFgBIAHABQADABADADIgDAGIgGgDIgDgBIgDAAIgDACIgCADIgBAEIAAAJIABAEIACADIADACIADAAIADgBQADAAACgCIAEAFQgDADgDABIgHABIgFgBg");
	this.shape_34.setTransform(36.65,23.025);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgCgCgCgDIgBgGIAAgKIABgGQABgDACgCIAGgDQADgCACAAQADAAADACIAGADIACAEQACADAAAEIAAAHIgYAAIAAACIABAEIACADIADACIADAAIAEgBQADAAADgDIAEAFQgDADgEABQgDACgEAAIgGgBgAgDgNIgCACIgCADIgBAEIAAACIARAAIAAgCIgBgEIgCgDIgDgCIgDAAIgDAAg");
	this.shape_35.setTransform(32.95,23.025);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAJAUIAAgSIgDACIgEACIgCAAIgCABQgHAAgDgEQgEgDAAgHIAAgMIAHAAIAAALQAAAFACACQACABAEAAIAFAAIAFgEIAAgPIAIAAIAAAng");
	this.shape_36.setTransform(28.95,23.025);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAKAUIAAgcIgBAAIgGAIIgMAUIgHAAIAAgnIAIAAIAAAcIAAAAIAGgJIAMgTIAHAAIAAAng");
	this.shape_37.setTransform(25.05,23.025);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAJAUIAAgRIgSAAIAAARIgHAAIAAgnIAHAAIAAARIASAAIAAgRIAHAAIAAAng");
	this.shape_38.setTransform(20.95,23.025);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAKAUIAAgcIgBAAIgGAIIgMAUIgGAAIAAgnIAHAAIAAAcIAAAAIAGgJIAMgTIAHAAIAAAng");
	this.shape_39.setTransform(16.85,23.025);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgSAPIAFgCIACgDIACgFIAAgIIAAgRIAbAAIAAAoIgGAAIAAghIgOAAIAAAKIgBAKIgCAHIgFAEIgEADg");
	this.shape_40.setTransform(12.5,23.075);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAMAcIgEgRIgCgFIgDgCIgDgBIgCAAIgJAAIAAAZIgHAAIAAg3IAHAAIAAAYIAJAAIACAAIACgCIADgCIACgEIAFgQIAHAAIgFAQIgEAHQgBADgDABQAEAAABADIADAHIAFASg");
	this.shape_41.setTransform(8.5,22.25);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgMAfIAUg+IAEABIgTA+g");
	this.shape_42.setTransform(4.8,22.275);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgMAfIATg+IAGABIgTA+g");
	this.shape_43.setTransform(2.25,22.275);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgCADIgBgDIABgCQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQABABAAAAIABACQAAABAAAAQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_44.setTransform(226.125,16.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgTAcIAAg3IAWAAIAHABIAFADIADAFIABAFQAAAEgBADQgCAEgEABQAEACACADQACAEAAAEIgBAGQgBADgCABIgFAFQgDABgEAAgAgMAVIAOAAQAFAAADgCQADgDgBgEIgBgFIgBgDIgEgBIgEgBIgOAAgAgMgEIAOAAIAEgBIADgBIACgCIAAgEQAAgEgCgDQgDgCgEAAIgOAAg");
	this.shape_45.setTransform(222.95,14.05);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgCADIgBgDIABgCQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAABABAAIABACQAAABAAAAQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_46.setTransform(219.625,16.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AATAUIgDgLIgCgDIgBgCIgCgBIgDAAIgFAAIAAARIgFAAIAAgRIgFAAIgDAAIgCABIgCACIgBADIgDALIgHAAIAEgNIABgDIABgCIACgCIACAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIgCgFIgEgMIAIAAIADALIACAEIABABIADABIACAAIAEAAIAAgRIAFAAIAAARIAEAAIACAAIADgBIABgBIACgEIADgLIAHAAIgDAMIgCAFIgEACQAAAAABAAQABAAAAAAQABABAAAAQAAABABAAIACAFIAEANg");
	this.shape_47.setTransform(215.925,14.825);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AATAiIAAgMIglAAIAAAMIgHAAIAAgTIAEAAIADgDIADgFIABgHIABgLIAAgWIAiAAIAAAwIAFAAIAAATgAgGgLIgBAKIgBAHIgCAFIgCAEIAaAAIAAgqIgTAAg");
	this.shape_48.setTransform(210.25,14.65);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgHATQgDgBgEgDIAEgEIAFACIAFABIAEAAIACgCIACgCIAAgCQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBgBAAQgCgCgDAAIgFAAIAAgEIAFAAQADAAACgCQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBAAgBgBQgBgBgDAAIgFABQgCAAgCACIgEgFQACgCAEgBIAHgCIAGABIAEADIADADIAAAFIAAACIgBACIgBACIgDACIADABIACADIABACIAAACIgBAFIgCAEIgGADIgGABIgHgCg");
	this.shape_49.setTransform(203.4,14.825);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgCgCgCgDIgBgGIAAgKIABgGQABgDACgCIAGgDQADgCACAAQADAAADACIAGADIACAEQACADAAAEIAAAHIgYAAIAAACIABAEIACADIADACIADAAIAEgBQADAAADgDIAEAFQgDADgEABQgDACgEAAIgGgBgAgDgNIgCACIgCADIgBAEIAAACIARAAIAAgCIgBgEIgCgDIgDgCIgDAAIgDAAg");
	this.shape_50.setTransform(199.9,14.825);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgPAcIAAg3IAGAAIABAEIAHgDIAEgBQAGgBADAEQAEADABAIIAAANQgBAFgEAEQgDAEgHAAIgEgBIgGgCIAAASgAAAgUIgDABIgCACIgDABIAAAUIAFACIAFABIADgBIACgBIACgDIABgCIAAgNQAAgEgCgBQgDgCgDgBg");
	this.shape_51.setTransform(195.95,15.6);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgDgCgBgDIgBgGIAAgKIABgGQABgDACgCIAGgDQADgCACAAQADAAADACIAGADIACAEQACADAAAEIAAAHIgZAAIAAACIABAEIADADIADACIACAAIAFgBQADAAADgDIAEAFQgEADgDABQgDACgFAAIgFgBgAgDgNIgCACIgDADIAAAEIAAACIARAAIAAgCIgBgEIgCgDIgCgCIgEAAIgDAAg");
	this.shape_52.setTransform(192.05,14.825);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAMAcIAAgxIgZAAIAAAxIgGAAIAAg3IAnAAIAAA3g");
	this.shape_53.setTransform(187.6,14.05);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgLADIAAgFIAXAAIAAAFg");
	this.shape_54.setTransform(183.525,14.65);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgMARQgDgDAAgGQAAgDABgCIADgDIAGgCIAEgBIAKAAIAAgDQAAgEgCgCQgCgBgFAAIgDAAQgEABgDACIgDgFQAEgDAEgBIAGgBQAIAAAEAEQAEADgBAHIAAAaIgFAAIgCgDIAAgBIgHAEIgFABQgFAAgEgEgAgFADIgDACIgBADQAAABABABQAAAAAAABQAAAAABABQAAAAABABQACABACAAIADAAIADgBIADgCIACgBIAAgIIgJAAIgCAAg");
	this.shape_55.setTransform(179.9,14.825);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgQAcIAAg3IAHAAIABAEIAHgDIAEgBQAGgBADAEQAFADAAAIIAAANQAAAFgFAEQgDAEgHAAIgDgBIgHgCIAAASgAAAgUIgCABIgEACIgCABIAAAUIAGACIADABIAEgBIACgBIACgDIAAgCIAAgNQAAgEgBgBQgCgCgEgBg");
	this.shape_56.setTransform(176,15.6);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgMARQgEgDABgGQAAgDABgCIADgDIAGgCIAEgBIALAAIAAgDQgBgEgCgCQgCgBgEAAIgFAAQgCABgEACIgDgFQAEgDAEgBIAGgBQAIAAAEAEQAEADgBAHIAAAaIgFAAIgBgDIAAgBIgIAEIgFABQgGAAgDgEgAgFADIgCACIgCADQAAABABABQAAAAAAABQAAAAABABQAAAAABABQACABACAAIADAAIADgBIADgCIADgBIAAgIIgKAAIgDAAg");
	this.shape_57.setTransform(171.9,14.825);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AATAUIgDgLIgCgDIgBgCIgCgBIgDAAIgFAAIAAARIgFAAIAAgRIgFAAIgDAAIgCABIgCACIgBADIgDALIgHAAIAEgNIABgDIABgCIACgCIACAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIgCgFIgEgMIAIAAIADALIACAEIABABIADABIACAAIAEAAIAAgRIAFAAIAAARIAEAAIACAAIADgBIABgBIACgEIADgLIAHAAIgDAMIgCAFIgEACQAAAAABAAQAAAAABAAQAAABABAAQAAABABAAIACAFIAEANg");
	this.shape_58.setTransform(167.175,14.825);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AATAiIAAgMIglAAIAAAMIgHAAIAAgTIAEAAIADgDIACgFIACgHIAAgLIABgWIAiAAIAAAwIAFAAIAAATgAgHgLIAAAKIgBAHIgBAFIgDAEIAaAAIAAgqIgUAAg");
	this.shape_59.setTransform(161.5,14.65);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgCADIgBgDIABgCQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQAAABABAAIABACQAAABAAAAQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAABQAAAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAgBAAAAg");
	this.shape_60.setTransform(155.525,16.45);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AAJAUIAAgcIAAAAIgGAIIgMAUIgHAAIAAgnIAHAAIAAAcIABAAIAGgJIAMgTIAHAAIAAAng");
	this.shape_61.setTransform(152.6,14.825);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AAKAUIAAgcIgBAAIgGAIIgMAUIgGAAIAAgnIAGAAIAAAcIABAAIAGgJIAMgTIAGAAIAAAng");
	this.shape_62.setTransform(148.5,14.825);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AAKAUIAAghIgTAAIAAAhIgGAAIAAgnIAfAAIAAAng");
	this.shape_63.setTransform(144.45,14.825);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgMARQgEgDABgGQAAgDABgCIADgDIAGgCIAEgBIALAAIAAgDQgBgEgCgCQgCgBgEAAIgFAAQgCABgEACIgDgFQAEgDAEgBIAGgBQAIAAAEAEQAEADgBAHIAAAaIgFAAIgBgDIAAgBIgIAEIgFABQgGAAgDgEgAgFADIgCACIgCADQAAABABABQAAAAAAABQAAAAABABQAAAAABABQACABACAAIADAAIADgBIADgCIADgBIAAgIIgKAAIgDAAg");
	this.shape_64.setTransform(140.4,14.825);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgPAcIAAg3IAFAAIACAEIAHgDIAEgBQAGgBADAEQAEADAAAIIAAANQAAAFgEAEQgDAEgGAAIgFgBIgGgCIAAASgAAAgUIgDABIgCACIgDABIAAAUIAFACIAFABIADgBIACgBIACgDIABgCIAAgNQAAgEgDgBQgCgCgCgBg");
	this.shape_65.setTransform(136.45,15.6);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgDgCgBgDIgBgGIAAgKIABgGQABgDACgCIAGgDQADgCACAAQAEAAACACIAGADIADAEQABADAAAEIAAAHIgZAAIAAACIABAEIADADIADACIACAAIAGgBQACAAACgDIAFAFQgEADgDABQgEACgEAAIgFgBgAgCgNIgDACIgDADIAAAEIAAACIARAAIAAgCIgBgEIgCgDIgCgCIgEAAIgCAAg");
	this.shape_66.setTransform(132.55,14.825);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgDAUIAAghIgMAAIAAgGIAfAAIAAAGIgNAAIAAAhg");
	this.shape_67.setTransform(128.9,14.825);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AAJAcIAAgcIAAAAIgGAIIgMAUIgHAAIAAgnIAIAAIAAAcIAAAAIAGgJIAMgTIAHAAIAAAngAgFgSIgDgCIgCgEIAAgDIAFAAIABABIABACIACABIABAAIACAAIACgBIACgCIAAgBIAFAAIAAADIgCAEIgDACIgGABIgFgBg");
	this.shape_68.setTransform(122.8,14);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgDgCgBgDIgBgGIAAgKIABgGQABgDADgCIAEgDQAEgCACAAQAEAAADACIAEADIAEAEQABADAAAEIAAAHIgYAAIAAACIAAAEIACADIAEACIACAAIAGgBQACAAACgDIAFAFQgDADgEABQgEACgEAAIgFgBgAgCgNIgEACIgCADIAAAEIAAACIARAAIAAgCIgBgEIgBgDIgEgCIgDAAIgCAAg");
	this.shape_69.setTransform(118.85,14.825);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AATAaIAAgLIgsAAIAAgoIAHAAIAAAiIAOAAIAAgiIAGAAIAAAiIAOAAIAAgiIAHAAIAAAiIADAAIAAARg");
	this.shape_70.setTransform(114.1,15.35);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AAAAUIgEgDQgCgCgBgDIgBgGIAAgDIgGAAIAAARIgHAAIAAgnIAHAAIAAARIAGAAIAAgDIABgGQABgDACgCIAEgDIAGgBQAIAAAEAEQAEAEAAAHIAAALQAAADgBADIgDAFIgFADIgHABIgGgBgAADgNIgDACIgBADIAAAEIAAAJQAAAFABACQACACAEAAIAEAAIACgCIACgDIABgEIAAgJIgBgEIgCgDIgCgCIgEAAIgDAAg");
	this.shape_71.setTransform(108.525,14.825);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgJAdIAGgRIgEgEIgKgkIAHAAIAFASIAEAPIABAAIAFgPIAFgSIAIAAIgTA5g");
	this.shape_72.setTransform(104.1,15.65);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgPAcIAAg3IAFAAIABAEIAIgDIAEgBQAGgBAEAEQADADAAAIIAAANQAAAFgDAEQgEAEgGAAIgFgBIgHgCIAAASgAAAgUIgCABIgDACIgEABIAAAUIAHACIAEABIADgBIACgBIACgDIAAgCIAAgNQAAgEgCgBQgCgCgCgBg");
	this.shape_73.setTransform(100.25,15.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AAKAUIAAgcIgBAAIgGAIIgMAUIgHAAIAAgnIAIAAIAAAcIAAAAIAGgJIAMgTIAHAAIAAAng");
	this.shape_74.setTransform(96.15,14.825);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgSAPIAFgCIACgDIACgFIAAgIIAAgRIAcAAIAAAoIgHAAIAAghIgOAAIAAAKIgBAKIgCAHIgFAEIgEADg");
	this.shape_75.setTransform(91.8,14.875);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgJAdIAGgRIgDgEIgLgkIAHAAIAFASIAEAPIABAAIAFgPIAGgSIAHAAIgUA5g");
	this.shape_76.setTransform(88.1,15.65);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AANAUIAAgYIAAAAIgEAHIgHALIgDAAIgGgJIgFgJIAAAAIAAAYIgHAAIAAgnIAGAAIAIAPIAFAKIAGgKIAIgPIAGAAIAAAng");
	this.shape_77.setTransform(83.775,14.825);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AAKAUIAAgcIgBAAIgGAIIgMAUIgGAAIAAgnIAHAAIAAAcIAAAAIAGgJIAMgTIAGAAIAAAng");
	this.shape_78.setTransform(79.3,14.825);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgDAUIAAghIgMAAIAAgGIAfAAIAAAGIgMAAIAAAhg");
	this.shape_79.setTransform(75.6,14.825);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgEAUIgFgDIgEgFIgBgGIAAgLIABgGIAEgFIAFgDIAFgBIAHABQADABADADIgEAGIgFgDIgEgBIgCAAIgDACIgCADIgBAEIAAAJIABAEIACADIADACIACAAIAEgBQADAAACgCIAEAFQgDADgDABIgHABIgFgBg");
	this.shape_80.setTransform(72.3,14.825);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgGAUIgFgDIgEgFIgBgGIAAgLIABgGIAFgFIAEgDIAGgBIAHABIAFADIADAFQABADABADIAAALQgBADgBADIgEAFIgFADIgGABIgGgBgAgCgNIgEACIgCADIAAAEIAAAJIAAAEIACADIADACIADAAIADAAIAEgCIABgDIABgEIAAgJIgBgEIgBgDIgEgCIgDAAg");
	this.shape_81.setTransform(68.45,14.825);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AAKAUIAAgRIgTAAIAAARIgGAAIAAgnIAGAAIAAARIATAAIAAgRIAGAAIAAAng");
	this.shape_82.setTransform(64.35,14.825);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgJAdIAGgRIgEgEIgKgkIAHAAIAFASIAEAPIABAAIAFgPIAFgSIAIAAIgTA5g");
	this.shape_83.setTransform(60.45,15.65);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AANAUIAAgYIAAAAIgEAHIgHALIgDAAIgGgJIgFgJIAAAAIAAAYIgHAAIAAgnIAGAAIAIAPIAFAKIAGgKIAIgPIAGAAIAAAng");
	this.shape_84.setTransform(56.125,14.825);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AANAUIAAgYIAAAAIgEAHIgHALIgDAAIgGgJIgFgJIAAAAIAAAYIgHAAIAAgnIAGAAIAIAPIAFAKIAGgKIAIgPIAGAAIAAAng");
	this.shape_85.setTransform(51.275,14.825);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AAKAUIAAgcIgBAAIgGAIIgMAUIgGAAIAAgnIAGAAIAAAcIABAAIAGgJIAMgTIAGAAIAAAng");
	this.shape_86.setTransform(46.8,14.825);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AANAUIAAgYIAAAAIgEAHIgHALIgDAAIgGgJIgFgJIAAAAIAAAYIgHAAIAAgnIAGAAIAIAPIAFAKIAGgKIAIgPIAGAAIAAAng");
	this.shape_87.setTransform(39.975,14.825);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgDgCgBgDIgBgGIAAgKIABgGQABgDADgCIAEgDQADgCADAAQAEAAADACIAEADIAEAEQABADAAAEIAAAHIgZAAIAAACIABAEIACADIAEACIACAAIAGgBQACAAACgDIAFAFQgDADgEABQgDACgFAAIgFgBgAgCgNIgEACIgCADIAAAEIAAACIARAAIAAgCIgBgEIgBgDIgDgCIgEAAIgCAAg");
	this.shape_88.setTransform(35.7,14.825);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AAJAUIAAgcIAAAAIgGAIIgMAUIgHAAIAAgnIAHAAIAAAcIABAAIAGgJIAMgTIAGAAIAAAng");
	this.shape_89.setTransform(31.65,14.825);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgPAUIAAgnIASAAIAGABIADACIACAEIABAEQAAAAAAABQAAABAAAAQAAABAAAAQgBABAAAAQgBADgCABQACABABACIACAFIgBAEQAAABAAAAQgBABAAABQAAAAgBAAQAAABgBAAIgDADIgGABgAgIAOIAKAAQAEAAACgCQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgEgCIgLAAgAgIgDIAKAAQABAAABAAQAAAAABAAQAAAAABgBQABAAAAAAQAAAAABgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAgBgBQAAgBAAAAQAAgBgBAAQAAAAgBgBIgEgBIgKAAg");
	this.shape_90.setTransform(27.65,14.825);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgDAUIAAghIgMAAIAAgGIAfAAIAAAGIgNAAIAAAhg");
	this.shape_91.setTransform(24.05,14.825);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgEAUIgGgDIgDgFIAAgGIAAgLIAAgGIAEgFIAFgDIAFgBIAHABQADABADADIgDAGIgGgDIgDgBIgDAAIgDACIgCADIgBAEIAAAJIABAEIACADIADACIADAAIADgBQADAAACgCIAEAFQgDADgDABIgHABIgFgBg");
	this.shape_92.setTransform(20.8,14.825);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgDAUIAAghIgMAAIAAgGIAfAAIAAAGIgNAAIAAAhg");
	this.shape_93.setTransform(17.3,14.825);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgJAdIAGgRIgEgEIgKgkIAHAAIAFASIAEAPIABAAIAFgPIAFgSIAIAAIgUA5g");
	this.shape_94.setTransform(13.75,15.65);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgEAUIgGgDIgCgFIgBgGIAAgLIABgGIADgFIAFgDIAFgBIAHABQAEABACADIgDAGIgFgDIgEgBIgDAAIgDACIgCADIgBAEIAAAJIABAEIACADIADACIADAAIAEgBQACAAACgCIAEAFQgCADgEABIgHABIgFgBg");
	this.shape_95.setTransform(10.25,14.825);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgDAUIAAghIgMAAIAAgGIAfAAIAAAGIgMAAIAAAhg");
	this.shape_96.setTransform(6.75,14.825);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgFAUIgGgDIgDgFIgBgGIAAgLIABgGIADgFIAGgDIAFgBIAGABIAGADIADAFQACADgBADIAAALQABADgCADIgDAFIgGADIgGABIgFgBgAgCgNIgDACIgDADIgBAEIAAAJIABAEIACADIADACIADAAIADAAIADgCIACgDIABgEIAAgJIgBgEIgCgDIgDgCIgDAAg");
	this.shape_97.setTransform(3.05,14.825);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgEAUIgGgDIgCgFIgBgGIAAgLIABgGIADgFIAFgDIAFgBIAHABQAEABADADIgEAGIgGgDIgDgBIgDAAIgDACIgCADIgBAEIAAAJIABAEIACADIADACIADAAIADgBQADAAACgCIAFAFQgDADgEABIgHABIgFgBg");
	this.shape_98.setTransform(225.35,6.575);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AAAAUIgEgDIgDgFIgBgGIAAgDIgGAAIAAARIgHAAIAAgnIAHAAIAAARIAGAAIAAgDIABgGQABgDACgCIAEgDIAGgBQAIAAAEAEQAEAEAAAHIAAALQAAADgBADIgDAFIgFADIgHABIgGgBgAADgNIgDACIgBADIAAAEIAAAJQAAAFABACQACACAEAAIAEAAIACgCIACgDIABgEIAAgJIgBgEIgCgDIgCgCIgEAAIgDAAg");
	this.shape_99.setTransform(215.325,6.575);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AAKAUIAAgcIgBAAIgGAIIgMAUIgGAAIAAgnIAHAAIAAAcIAAAAIAGgJIAMgTIAGAAIAAAng");
	this.shape_100.setTransform(210.7,6.575);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AAJAUIAAgRIgSAAIAAARIgHAAIAAgnIAHAAIAAARIASAAIAAgRIAIAAIAAAng");
	this.shape_101.setTransform(206.6,6.575);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgDgCgBgDIgBgGIAAgKIABgGQABgDADgCIAEgDQADgCADAAQAEAAADACIAEADIAEAEQABADAAAEIAAAHIgZAAIAAACIABAEIACADIAEACIACAAIAGgBQACAAACgDIAFAFQgDADgEABQgDACgFAAIgFgBgAgCgNIgEACIgCADIAAAEIAAACIARAAIAAgCIgBgEIgBgDIgDgCIgEAAIgCAAg");
	this.shape_102.setTransform(202.65,6.575);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AAJAUIAAgRIgSAAIAAARIgHAAIAAgnIAHAAIAAARIASAAIAAgRIAIAAIAAAng");
	this.shape_103.setTransform(198.6,6.575);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgPAUIAAgnIASAAIAFABIAFACIACAEIAAAEQAAAAAAABQAAABAAAAQAAABAAAAQgBABAAAAQgBADgDABQAEABABACIABAFIgBAEQAAABAAAAQgBABAAABQAAAAgBAAQAAABAAAAIgEADIgFABgAgIAOIAKAAQAEAAABgCQABAAAAgBQAAAAABAAQAAgBAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAIgEgCIgLAAgAgIgDIALAAQAAAAABAAQAAAAABAAQAAAAABgBQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAAAgBIgFgBIgKAAg");
	this.shape_104.setTransform(194.65,6.575);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgMARQgDgDgBgGQABgDABgCIAEgDIAEgCIAFgBIALAAIAAgDQAAgEgCgCQgDgBgEAAIgFAAQgDABgCACIgEgFQAEgDAEgBIAGgBQAIAAAEAEQAEADAAAHIAAAaIgHAAIAAgDIAAgBIgIAEIgFABQgGAAgDgEgAgGADIgBACIgBADQAAABAAABQAAAAAAABQAAAAABABQAAAAAAABQACABAEAAIACAAIADgBIADgCIADgBIAAgIIgKAAIgDAAg");
	this.shape_105.setTransform(190.65,6.575);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgPAcIAAg3IAFAAIABAFIAIgFIAEAAQAGAAAEADQADAEAAAHIAAAMQAAAGgDAEQgEAEgGAAIgFAAIgHgDIAAASgAAAgUIgDABIgCABIgEACIAAAUIAGACIAFABIADgBIACgBIACgDIABgDIAAgLQgBgFgCgBQgCgCgCAAg");
	this.shape_106.setTransform(186.75,7.35);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgEAUIgFgDIgEgFIgBgGIAAgLIABgGIAEgFIAFgDIAFgBIAHABQAEABADADIgFAGIgEgDIgFgBIgCAAIgDACIgCADIgBAEIAAAJIABAEIACADIADACIACAAIAFgBQACAAACgCIAFAFQgDADgEABIgHABIgFgBg");
	this.shape_107.setTransform(183.1,6.575);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgFAUIgGgDIgDgFIgBgGIAAgLIABgGIADgFIAGgDIAFgBIAGABIAGADIADAFQACADgBADIAAALQABADgCADIgDAFIgGADIgGABIgFgBgAgCgNIgDACIgDADIgBAEIAAAJIABAEIACADIADACIADAAIADAAIADgCIACgDIABgEIAAgJIgBgEIgCgDIgDgCIgDAAg");
	this.shape_108.setTransform(173.6,6.575);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AAJAUIAAghIgSAAIAAAhIgGAAIAAgnIAfAAIAAAng");
	this.shape_109.setTransform(169.55,6.575);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgFAHIADgDIACgEQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBgBAAAAIgBgDQAAgBAAAAQAAAAAAgBQABAAAAgBQAAAAAAgBQABAAAAAAQAAAAABgBQAAAAABAAQAAAAAAAAIACAAIACACIABADIAAACIgBADIgBAEIgDADIgCACg");
	this.shape_110.setTransform(160.85,8.7);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgMARQgDgDgBgGQABgDABgCIAEgDIAEgCIAFgBIALAAIAAgDQAAgEgCgCQgDgBgEAAIgFAAQgCABgDACIgEgFQAEgDAEgBIAGgBQAIAAAEAEQAEADAAAHIAAAaIgHAAIAAgDIAAgBIgJAEIgEABQgGAAgDgEgAgGADIgBACIgBADQAAABAAABQAAAAAAABQAAAAABABQAAAAABABQABABAEAAIACAAIADgBIADgCIADgBIAAgIIgKAAIgDAAg");
	this.shape_111.setTransform(157.8,6.575);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgDAUIAAghIgMAAIAAgGIAfAAIAAAGIgNAAIAAAhg");
	this.shape_112.setTransform(154.2,6.575);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AAJAUIAAgcIAAAAIgGAIIgMAUIgHAAIAAgnIAHAAIAAAcIABAAIAGgJIAMgTIAGAAIAAAng");
	this.shape_113.setTransform(150.45,6.575);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AgDAUIAAghIgMAAIAAgGIAfAAIAAAGIgNAAIAAAhg");
	this.shape_114.setTransform(146.8,6.575);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgFAUIgGgDIgDgFIgBgGIAAgLIABgGIADgFIAGgDIAFgBIAGABIAGADIADAFQABADAAADIAAALQAAADgBADIgDAFIgGADIgGABIgFgBgAgDgNIgCACIgDADIgBAEIAAAJIABAEIACADIADACIADAAIADAAIADgCIACgDIACgEIAAgJIgCgEIgCgDIgDgCIgDAAg");
	this.shape_115.setTransform(143.1,6.575);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AgGAUIgFgDIgEgFIAAgGIAAgLIAAgGIAEgFIAFgDIAGgBIAGABIAGADIADAFQACADAAADIAAALQAAADgCADIgDAFIgGADIgGABIgGgBgAgDgNIgDACIgCADIAAAEIAAAJIAAAEIACADIADACIADAAIADAAIADgCIADgDIABgEIAAgJIgBgEIgDgDIgDgCIgDAAg");
	this.shape_116.setTransform(133.4,6.575);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgNAUIAAgnIAbAAIAAAGIgUAAIAAAhg");
	this.shape_117.setTransform(129.925,6.575);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgDgCgBgDIgBgGIAAgKIABgGQABgDACgCIAGgDQADgCACAAQAEAAADACIAFADIADAEQABADAAAEIAAAHIgZAAIAAACIABAEIADADIADACIACAAIAGgBQACAAACgDIAFAFQgEADgDABQgEACgEAAIgFgBgAgCgNIgDACIgDADIAAAEIAAACIARAAIAAgCIgBgEIgBgDIgDgCIgEAAIgCAAg");
	this.shape_118.setTransform(126.25,6.575);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AAJAUIAAgRIgSAAIAAARIgHAAIAAgnIAHAAIAAARIASAAIAAgRIAHAAIAAAng");
	this.shape_119.setTransform(122.2,6.575);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AAOAZIAAgKIgbAAIAAAKIgHAAIAAgQIADAAIADgDIABgDIABgEIABgHIABgQIAcAAIAAAhIADAAIAAAQgAgEgIIgBAKQgBAEgCADIATAAIAAgbIgPAAg");
	this.shape_120.setTransform(117.8,7.1);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgCgCgCgDIgBgGIAAgKIABgGQABgDADgCIAEgDQADgCADAAQAEAAADACIAEADIADAEQACADAAAEIAAAHIgYAAIAAACIABAEIABADIAEACIADAAIAEgBQADAAADgDIAEAFQgEADgDABQgEACgDAAIgGgBgAgDgNIgDACIgBADIgBAEIAAACIARAAIAAgCIgBgEIgBgDIgEgCIgDAAIgDAAg");
	this.shape_121.setTransform(113.7,6.575);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AgQAcIAAg3IAHAAIABAFIAHgFIAEAAQAGAAADADQAFAEAAAHIAAAMQAAAGgFAEQgDAEgHAAIgDAAIgHgDIAAASgAAAgUIgCABIgEABIgCACIAAAUIAGACIADABIAEgBIACgBIACgDIAAgDIAAgLQAAgFgBgBQgDgCgDAAg");
	this.shape_122.setTransform(109.75,7.35);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgEAUIgGgDIgCgFIgBgGIAAgLIABgGIADgFIAFgDIAFgBIAHABQAEABACADIgDAGIgFgDIgEgBIgDAAIgDACIgCADIgBAEIAAAJIABAEIACADIADACIADAAIAEgBQACAAACgCIAEAFQgCADgEABIgHABIgFgBg");
	this.shape_123.setTransform(106.1,6.575);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgCgCgCgDIgBgGIAAgKIABgGQABgDADgCIAEgDQADgCADAAQADAAAEACIAEADIAEAEQABADAAAEIAAAHIgYAAIAAACIAAAEIACADIAEACIADAAIAFgBQACAAACgDIAFAFQgDADgEABQgEACgDAAIgGgBgAgCgNIgEACIgCADIAAAEIAAACIARAAIAAgCIgBgEIgBgDIgEgCIgDAAIgCAAg");
	this.shape_124.setTransform(96.7,6.575);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AAOAZIAAgKIgbAAIAAAKIgHAAIAAgQIADAAIADgDIABgDIABgEIABgHIABgQIAcAAIAAAhIADAAIAAAQgAgFgIIAAAKQgBAEgCADIATAAIAAgbIgPAAg");
	this.shape_125.setTransform(92.35,7.1);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AAJAUIAAgcIAAAAIgGAIIgMAUIgGAAIAAgnIAGAAIAAAcIABAAIAGgJIAMgTIAGAAIAAAng");
	this.shape_126.setTransform(88.1,6.575);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgPAUIAAgnIASAAIAFABIAFACIABAEIABAEQAAAAAAABQAAABAAAAQAAABAAAAQgBABAAAAQgBADgCABQACABABACIACAFIgBAEQAAABAAAAQgBABAAABQAAAAgBAAQAAABAAAAIgEADIgFABgAgIAOIAKAAQAEAAABgCQABAAAAgBQAAAAABAAQAAgBAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAIgEgCIgLAAgAgIgDIALAAQAAAAABAAQAAAAABAAQAAAAABgBQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAgBgBIgEgBIgKAAg");
	this.shape_127.setTransform(84.15,6.575);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgPAUIAAgnIASAAIAFABIAFACIABAEIABAEQAAAAAAABQAAABAAAAQAAABAAAAQgBABAAAAQgBADgCABQADABAAACIACAFIgBAEQAAABAAAAQgBABAAABQAAAAgBAAQAAABAAAAIgEADIgFABgAgIAOIAKAAQAEAAABgCQABAAAAgBQAAAAABAAQAAgBAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAIgEgCIgLAAgAgIgDIALAAQAAAAABAAQAAAAABAAQAAAAABgBQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAgBgBIgEgBIgKAAg");
	this.shape_128.setTransform(74.6,6.575);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AAJAdIAAgdIAAAAIgGAIIgMAVIgHAAIAAgoIAHAAIAAAcIABAAIAGgJIAMgTIAGAAIAAAogAgEgSIgEgDIgCgDIAAgEIAGAAIAAACIABACIACABIABABIACgBIADgBIABgCIAAgCIAFAAIAAAEIgCADIgDADIgGABIgEgBg");
	this.shape_129.setTransform(64.95,5.75);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AAKAUIAAgcIgBAAIgGAIIgMAUIgGAAIAAgnIAHAAIAAAcIAAAAIAGgJIAMgTIAGAAIAAAng");
	this.shape_130.setTransform(60.85,6.575);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AAJAUIAAgRIgSAAIAAARIgHAAIAAgnIAHAAIAAARIASAAIAAgRIAIAAIAAAng");
	this.shape_131.setTransform(56.75,6.575);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AgFAUIgFgDQgCgCgCgDIgBgGIAAgKIABgGQABgDACgCIAGgDQACgCADAAQADAAADACIAFADIADAEQACADAAAEIAAAHIgYAAIAAACIABAEIACADIADACIADAAIAEgBQADAAADgDIAEAFQgDADgEABQgDACgEAAIgGgBgAgDgNIgCACIgCADIgBAEIAAACIARAAIAAgCIgBgEIgCgDIgDgCIgDAAIgDAAg");
	this.shape_132.setTransform(52.85,6.575);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AAKAUIAAgRIgSAAIAAARIgHAAIAAgnIAHAAIAAARIASAAIAAgRIAHAAIAAAng");
	this.shape_133.setTransform(48.8,6.575);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AATAUIgDgLIgCgDIgBgCIgCgBIgDAAIgFAAIAAARIgFAAIAAgRIgFAAIgDAAIgCABIgCACIgBADIgDALIgHAAIAEgNIABgDIABgCIACgCIACAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIgCgFIgEgMIAIAAIADALIACAEIABABIADABIACAAIAEAAIAAgRIAFAAIAAARIAEAAIACAAIADgBIABgBIACgEIADgLIAHAAIgDAMIgCAFIgEACQACAAACACIACAFIAEANg");
	this.shape_134.setTransform(43.925,6.575);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgGAUIgFgDIgEgFIgBgGIAAgLIABgGIAFgFIAEgDIAGgBIAHABIAFADIADAFQABADABADIAAALQgBADgBADIgEAFIgFADIgGABIgGgBgAgCgNIgEACIgCADIAAAEIAAAJIAAAEIACADIADACIADAAIADAAIAEgCIACgDIAAgEIAAgJIAAgEIgCgDIgEgCIgDAAg");
	this.shape_135.setTransform(39.1,6.575);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgRAPIADgCIADgDIACgFIABgIIAAgRIAbAAIAAAoIgHAAIAAghIgOAAIAAAKIgBAKIgCAHIgFAEIgEADg");
	this.shape_136.setTransform(34.75,6.625);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgEAUIgGgDIgCgFIgBgGIAAgLIABgGIADgFIAFgDIAFgBIAHABQAEABADADIgFAGIgEgDIgFgBIgCAAIgDACIgCADIgBAEIAAAJIABAEIACADIADACIACAAIAFgBQACAAACgCIAFAFQgDADgEABIgHABIgFgBg");
	this.shape_137.setTransform(31.3,6.575);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgFAUIgGgDIgDgFIgBgGIAAgLIABgGIADgFIAGgDIAFgBIAGABIAGADIADAFQABADAAADIAAALQAAADgBADIgDAFIgGADIgGABIgFgBgAgDgNIgCACIgDADIgBAEIAAAJIABAEIACADIADACIADAAIADAAIADgCIACgDIACgEIAAgJIgCgEIgCgDIgDgCIgDAAg");
	this.shape_138.setTransform(27.45,6.575);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AAJAUIgDgLIgCgDIgCgCIgCgBIgBAAIgHAAIAAARIgIAAIAAgnIAIAAIAAARIAGAAIACAAIABgBIACgBIACgEIAEgLIAHAAIgEAMIgDAFIgDACQABAAAAAAQABAAAAAAQABAAAAABQABAAAAABIACAFIAFANg");
	this.shape_139.setTransform(17.95,6.575);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AgEAUIgGgDIgCgFIgBgGIAAgLIABgGIADgFIAFgDIAFgBIAHABQAEABACADIgDAGIgGgDIgDgBIgDAAIgDACIgCADIgBAEIAAAJIABAEIACADIADACIADAAIADgBQADAAACgCIAEAFQgCADgEABIgHABIgFgBg");
	this.shape_140.setTransform(14.3,6.575);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AAJAUIAAgcIAAAAIgGAIIgMAUIgHAAIAAgnIAHAAIAAAcIABAAIAGgJIAMgTIAHAAIAAAng");
	this.shape_141.setTransform(10.4,6.575);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgSAcIAAg3IAWAAQAEAAADABIAEAEIADAFIABAHIgBAFIgDAFIgFAEQgDACgDAAIgPAAIAAAWgAgLAAIANAAQAEgBADgCQADgCAAgFQAAgFgDgCQgDgDgEAAIgNAAg");
	this.shape_142.setTransform(6.275,5.8);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AAAAEIgEAIIgCgBIgCgCIAGgIIgEgBIgGAAIADgFIAIADIgBgJIAFAAIgBAJIAEgBIAFgCIABAFIgJABIAHAIIgCABIgDACg");
	this.shape_143.setTransform(2.45,4.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ20, new cjs.Rectangle(0,0,228,28.5), null);


(lib.Символ18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AANBGIAAhVIgWBVIgTAAIAAh2IAQAAIAABGIAShGIAXAAIAAB2gAgTg3IAAgOIAoAAIAAAOg");
	this.shape.setTransform(173.2,7.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AANA8IAAhWIgWBWIgUAAIAAh2IARAAIAABGIAShGIAYAAIAAB2g");
	this.shape_1.setTransform(165.35,8.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAKA8IAAg0IgUAAIAAA0IgTAAIAAh2IATAAIAAAyIAUAAIAAgyIAUAAIAAB2g");
	this.shape_2.setTransform(157.5,8.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgYA8IAAh2IAxAAIAAARIgfAAIAAAgIAZAAIAAAQIgZAAIAAAkIAfAAIAAARg");
	this.shape_3.setTransform(150.3,8.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAKA8IAAg0IgUAAIAAA0IgTAAIAAh2IATAAIAAAyIAUAAIAAgyIAUAAIAAB2g");
	this.shape_4.setTransform(142.85,8.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAhA8IgSgwIgFALIAAAlIgTAAIAAglIgFgLIgSAwIgTAAIAahBIgag1IASAAIAYAzIAAgzIATAAIAAAzIAYgzIASAAIgaA1IAaBBg");
	this.shape_5.setTransform(133.2,8.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgUA1QgHgIgBgOIAAg9QABgPAHgHQAIgIAMAAQANAAAIAIQAIAHgBAPIAAA9QABAOgIAIQgIAIgNAAQgMAAgIgIgAgGgoQgCACgBAHIAAA/QABAHACACQACADAEAAQAEAAADgDQADgCgBgHIAAg/QABgHgDgCQgDgDgEAAQgEAAgCADg");
	this.shape_6.setTransform(123.9,8.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AghA8IgEgBIAAgRIADAAIADAAQAFAAADgCQADgCAAgHIAAhaIA6AAIAAB2IgSAAIAAhlIgVAAIAABIQAAAJgCAFQgDAGgDAEQgEADgFABQgFACgFAAg");
	this.shape_7.setTransform(115.475,8.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUA1QgHgIAAgOIAAg9QAAgPAHgHQAHgIANAAQAOAAAHAIQAHAHAAAPIAAALIgSAAIAAgMQAAgHgDgCQgCgDgEAAQgEAAgCADQgDACAAAHIAAA/QAAAHADACQACADAEgBQAEABACgDQADgCAAgHIAAgRIASAAIAAAQQAAAOgHAIQgHAIgOAAQgNAAgHgIg");
	this.shape_8.setTransform(107.65,8.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgUA1QgIgIAAgOIAAg9QAAgPAIgHQAHgIANAAQAOAAAHAIQAIAHAAAPIAAA9QAAAOgIAIQgHAIgOAAQgNAAgHgIgAgGgoQgCACAAAHIAAA/QAAAHACACQADADADAAQAEAAADgDQADgCAAgHIAAg/QAAgHgDgCQgDgDgEAAQgDAAgDADg");
	this.shape_9.setTransform(100.45,8.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AANA8IAAhWIgWBWIgTAAIAAh2IAQAAIAABGIAShGIAXAAIAAB2g");
	this.shape_10.setTransform(89.7,8.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAXA8IAAh2IATAAIAAB2gAgpA8IAAh2IATAAIAAAsIAJAAQANAAAHAHQAHAHAAAPIAAAPQAAAOgHAIQgHAHgNABgAgWArIAJAAQAEgBACgCQADgCAAgGIAAgSQAAgHgDgCQgCgDgEAAIgJAAg");
	this.shape_11.setTransform(77.45,8.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAYBCIAAgNIgvAAIAAANIgTAAIAAgeIADAAIADAAQAFAAADgCQADgCAAgHIAAhaIA7AAIAABlIAJAAIAAAegAgGAXQAAAIgCAFIAXAAIAAhUIgVAAg");
	this.shape_12.setTransform(67.65,9.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgVA8IgFgBIAAgRIADAAIADAAIAFAAIADgCIACgEIABgGIgchZIATAAIAUBFIARhFIATAAIgZBXQgDAMgEAHQgCAGgEADQgDADgFAAIgJABg");
	this.shape_13.setTransform(58.85,8.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgIA8IAAhlIgUAAIAAgRIA5AAIAAARIgTAAIAABlg");
	this.shape_14.setTransform(51.3,8.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgUA1QgHgIAAgOIAAg9QAAgPAHgHQAHgIANAAQANAAAIAIQAHAHAAAPIAAALIgSAAIAAgMQAAgHgCgCQgDgDgEAAQgEAAgDADQgCACAAAHIAAA/QAAAHACACQADADAEgBQAEABADgDQACgCAAgHIAAgRIASAAIAAAQQAAAOgHAIQgIAIgNAAQgNAAgHgIg");
	this.shape_15.setTransform(44.4,8.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgUA1QgIgIABgOIAAg9QgBgPAIgHQAIgIAMAAQANAAAIAIQAHAHAAAPIAAA9QAAAOgHAIQgIAIgNAAQgMAAgIgIgAgGgoQgDACABAHIAAA/QgBAHADACQADADADAAQAFAAACgDQACgCABgHIAAg/QgBgHgCgCQgCgDgFAAQgDAAgDADg");
	this.shape_16.setTransform(37.2,8.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgbA8IAAh2IAbAAQAOgBAHAIQAHAIAAAOIAAAQQAAANgHAHQgHAIgOAAIgIAAIAAAtgAgIgBIAIAAQAEAAACgCQADgDAAgGIAAgSQAAgGgDgDQgCgCgEAAIgIAAg");
	this.shape_17.setTransform(30.375,8.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAKA8IAAhlIgUAAIAABlIgTAAIAAh2IA6AAIAAB2g");
	this.shape_18.setTransform(22.7,8.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgIA8IAAhlIgUAAIAAgRIA5AAIAAARIgUAAIAABlg");
	this.shape_19.setTransform(12.2,8.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgUA1QgIgIABgOIAAg9QgBgPAIgHQAIgIAMAAQANAAAIAIQAHAHAAAPIAAA9QAAAOgHAIQgIAIgNAAQgMAAgIgIgAgGgoQgDACABAHIAAA/QgBAHADACQADADADAAQAFAAACgDQACgCABgHIAAg/QgBgHgCgCQgCgDgFAAQgDAAgDADg");
	this.shape_20.setTransform(5.25,8.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ18, new cjs.Rectangle(-0.2,0,179.7,21), null);


(lib.Символ17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAPBSIAAhkIgbBkIgWAAIAAiLIATAAIAABTIAWhTIAcAAIAACLgAgXhBIAAgQIAvAAIAAAQg");
	this.shape.setTransform(197.3,8.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAPBGIAAhkIgaBkIgXAAIAAiLIATAAIAABTIAWhTIAcAAIAACLg");
	this.shape_1.setTransform(188.15,9.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgfBGIAAiLIAfAAQAQAAAIAJQAJAIAAARIAAATQAAAQgJAJQgIAJgQgBIgKAAIAAA1gAgKgBIAKAAQAFAAADgEQACgCAAgIIAAgVQAAgHgCgDQgDgDgFAAIgKAAg");
	this.shape_2.setTransform(179.8,9.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgdBGIAAiLIA7AAIAAAUIglAAIAAAnIAdAAIAAATIgdAAIAAApIAlAAIAAAUg");
	this.shape_3.setTransform(171.65,9.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgKBGIAAh3IgXAAIAAgUIBDAAIAAAUIgXAAIAAB3g");
	this.shape_4.setTransform(163.65,9.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AANBGIgUg4IgHANIAAArIgVAAIAAiLIAVAAIAAA9IAdg9IAWAAIgfA+IAfBNg");
	this.shape_5.setTransform(155.65,9.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AARBGIgFgaIgaAAIgDAaIgUAAIAWiLIAfAAIAWCLgAAKAaIgKhGIgKBGIAUAAg");
	this.shape_6.setTransform(146.55,9.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgfBGIAAiLIA4AAIAAAUIgjAAIAAAgIAKAAQARAAAHAJQAJAIgBARIAAATQABARgJAIQgHAJgRAAgAgKAyIAKAAQAFAAADgDQADgCAAgIIAAgVQAAgIgDgCQgDgEgFAAIgKAAg");
	this.shape_7.setTransform(138.15,9.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAPBGIAAhkIgbBkIgWAAIAAiLIAUAAIAABTIAVhTIAcAAIAACLg");
	this.shape_8.setTransform(125.55,9.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AghBGIAAiLIAhAAQAQAAAIAIQAIAIAAAQIAAAFQAAALgDAHQgEAHgHAEQAIADAEAHQAEAHAAAMIAAALQAAAQgJAJQgIAIgQAAgAgLAyIAMAAQAFAAADgDQADgDAAgIIAAgMQAAgKgDgEQgEgDgGAAIgKAAgAgLgMIAIAAQAGAAADgDQAEgDAAgJIAAgIQAAgHgDgDQgCgEgGAAIgKAAg");
	this.shape_9.setTransform(113.05,9.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgYA+QgIgJAAgRIAAhIQAAgQAIgKQAJgJAPAAQAQAAAJAJQAIAKAAAQIAABIQAAARgIAJQgJAKgQAAQgPAAgJgKgAgHgvQgDADAAAHIAABLQAAAHADADQADAEAEAAQAFAAADgEQAEgDAAgHIAAhLQAAgHgEgDQgDgEgFAAQgEAAgDAEg");
	this.shape_10.setTransform(104.325,9.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgXA+QgJgJAAgRIAAhIQAAgQAJgKQAIgJAPAAQAQAAAJAJQAIAKAAAQIAAAOIgVAAIAAgPQAAgHgDgDQgDgEgFAAQgFAAgDAEQgDADAAAHIAABLQAAAHADADQADAEAFAAQAFAAADgEQADgDAAgHIAAgUIAVAAIAAASQAAARgIAJQgJAKgQAAQgPAAgIgKg");
	this.shape_11.setTransform(95.925,9.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgaBGIgFAAIAAgUIAEAAIAEAAIAEgBIAFgCIACgEIABgIIgghoIAWAAIAXBRIAUhRIAWAAIgdBmQgDAOgFAIQgDAIgEADQgEADgFABIgMAAg");
	this.shape_12.setTransform(86.85,9.975);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgfBGIAAiLIAfAAQARAAAHAJQAJAIgBARIAAATQABAQgJAJQgHAJgRgBIgKAAIAAA1gAgKgBIAKAAQAFAAADgEQADgCAAgIIAAgVQAAgHgDgDQgDgDgFAAIgKAAg");
	this.shape_13.setTransform(78.2,9.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAPBGIAAhkIgbBkIgWAAIAAiLIAUAAIAABTIAVhTIAcAAIAACLg");
	this.shape_14.setTransform(69.3,9.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AghBGIAAiLIAhAAQAQAAAIAIQAIAIAAAQIAAAFQAAALgDAHQgEAHgHAEQAIADAEAHQAEAHAAAMIAAALQAAAQgIAJQgJAIgQAAgAgLAyIAMAAQAFAAADgDQADgDAAgIIAAgMQAAgKgDgEQgEgDgGAAIgKAAgAgLgMIAIAAQAGAAADgDQAEgDAAgJIAAgIQAAgHgDgDQgCgEgFAAIgLAAg");
	this.shape_15.setTransform(60.5,9.95);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AghBGIAAiLIAhAAQARAAAHAIQAIAIAAAQIAAAFQAAALgEAHQgDAHgHAEQAJADADAHQAEAHAAAMIAAALQAAAQgIAJQgJAIgRAAgAgLAyIALAAQAGAAADgDQADgDAAgIIAAgMQAAgKgDgEQgDgDgHAAIgKAAgAgLgMIAJAAQAFAAAEgDQADgDAAgJIAAgIQAAgHgDgDQgDgEgEAAIgLAAg");
	this.shape_16.setTransform(48.1,9.95);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAPBGIAAhkIgbBkIgWAAIAAiLIAUAAIAABTIAVhTIAcAAIAACLg");
	this.shape_17.setTransform(39.05,9.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgKBGIAAh3IgXAAIAAgUIBDAAIAAAUIgXAAIAAB3g");
	this.shape_18.setTransform(30.55,9.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgYA+QgIgJAAgRIAAhIQAAgQAIgKQAJgJAPAAQAQAAAJAJQAIAKAAAQIAABIQAAARgIAJQgJAKgQAAQgPAAgJgKgAgHgvQgDADAAAHIAABLQAAAHADADQADAEAEAAQAFAAADgEQAEgDAAgHIAAhLQAAgHgEgDQgDgEgFAAQgEAAgDAEg");
	this.shape_19.setTransform(22.425,9.95);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AggBGIAAiLIAgAAQAQAAAJAJQAHAIABARIAAATQgBAQgHAJQgJAJgQgBIgJAAIAAA1gAgJgBIAJAAQAFAAADgEQADgCgBgIIAAgVQABgHgDgDQgDgDgFAAIgJAAg");
	this.shape_20.setTransform(14.45,9.95);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAMBGIAAh3IgYAAIAAB3IgWAAIAAiLIBFAAIAACLg");
	this.shape_21.setTransform(5.575,9.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ17, new cjs.Rectangle(-0.7,0,205,24), null);


(lib.Символ16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#013764","rgba(1,55,100,0)"],[0.224,1],0,0,0,0,0,33.9).s().p("AjsDsQhhhiAAiKQAAiJBhhjQBjhhCJAAQCKAABiBhQBiBjAACJQAACKhiBiQhiBiiKAAQiJAAhjhig");
	this.shape.setTransform(33.4,33.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ16, new cjs.Rectangle(0,0,66.8,66.8), null);


(lib.Символ15копия9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15копия9, new cjs.Rectangle(0,0,74.5,73), null);


(lib.Символ15копия8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15копия8, new cjs.Rectangle(0,0,74.5,73), null);


(lib.Символ15копия7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15копия7, new cjs.Rectangle(0,0,74.5,73), null);


(lib.Символ15копия6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15копия6, new cjs.Rectangle(0,0,74.5,73), null);


(lib.Символ15копия5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15копия5, new cjs.Rectangle(0,0,74.5,73), null);


(lib.Символ15копия4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15копия4, new cjs.Rectangle(0,0,74.5,73), null);


(lib.Символ15копия3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15копия3, new cjs.Rectangle(0,0,74.5,73), null);


(lib.Символ15копия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15копия2, new cjs.Rectangle(0,0,74.5,73), null);


(lib.Символ15копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15копия, new cjs.Rectangle(0,0,74.5,73), null);


(lib.Символ15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15, new cjs.Rectangle(0,0,74.5,73), null);


(lib.Символ8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#C41621","#DD1B26","#C41621","#780713","#DD1B26"],[0,0,0.004,0.494,1],-1.7,0,1.8,0).s().p("AgLDLQgGgGAAgHIAAl7QAAgHAGgFQAFgGAGAAQAIAAAEAGQAGAFAAAHIAAF7QAAAHgGAGQgEAEgIAAQgGAAgFgEg");
	this.shape.setTransform(1.75,20.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ8, new cjs.Rectangle(0,0,3.5,41.5), null);


(lib.Символ7копия11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(32.45,0,0.66,0.5,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия11, new cjs.Rectangle(-4.5,0,37,40.5), null);


(lib.Символ7копия10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(28,0,0.5,0.5,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия10, new cjs.Rectangle(0,0,28,40.5), null);


(lib.Символ7копия9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(28,0,0.5,0.5,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия9, new cjs.Rectangle(0,0,28,40.5), null);


(lib.Символ7копия8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(32.45,0,0.66,0.5,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия8, new cjs.Rectangle(-4.5,0,37,40.5), null);


(lib.Символ7копия7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(-12.15,41.6,0.451,0.3894,0,53.6555,84.1858);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия7, new cjs.Rectangle(-37.5,41.6,27.9,43.800000000000004), null);


(lib.Символ7копия6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(-13.7,42.75,0.4511,0.3436,0,53.6344,84.0048);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия6, new cjs.Rectangle(-36.1,42.8,25.1,41.60000000000001), null);


(lib.Символ7копия5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(26.85,-0.65,0.5288,0.3428,0,0,151.3959);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия5, new cjs.Rectangle(0.9,-0.6,26,41.9), null);


(lib.Символ7копия4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(28,0,0.5,0.5,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия4, new cjs.Rectangle(0,0,28,40.5), null);


(lib.Символ7копия3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(28,0,0.5,0.5,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия3, new cjs.Rectangle(0,0,28,40.5), null);


(lib.Символ7копия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(28,0,0.5,0.5,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия2, new cjs.Rectangle(0,0,28,40.5), null);


(lib.Символ7копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(28,0,0.5,0.5,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7копия, new cjs.Rectangle(0,0,28,40.5), null);


(lib.Символ7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение17();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7, new cjs.Rectangle(0,0,28,40.5), null);


(lib.Символ6копия10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(123.2,26.7,0.6996,0.699,0,120.0576,-59.9417);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6копия10, new cjs.Rectangle(68.2,-55.4,84.10000000000001,82.1), null);


(lib.Символ6копия9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(114.3,21.6,0.7006,0.4681,0,120.0447,-59.9552);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6копия9, new cjs.Rectangle(77.5,-50.1,65.9,71.7), null);


(lib.Символ6копия8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(114.85,11.75,0.4393,0.4393,0,120.046,-59.954);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6копия8, new cjs.Rectangle(80.3,-39.8,52.8,51.599999999999994), null);


(lib.Символ6копия7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(114.85,11.75,0.4393,0.4393,0,120.046,-59.954);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6копия7, new cjs.Rectangle(80.3,-39.8,52.8,51.599999999999994), null);


(lib.Символ6копия6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(114.85,11.75,0.4393,0.4393,0,120.046,-59.954);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6копия6, new cjs.Rectangle(80.3,-39.8,52.8,51.599999999999994), null);


(lib.Символ6копия5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(114.85,11.75,0.4393,0.4393,0,120.046,-59.954);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6копия5, new cjs.Rectangle(80.3,-39.8,52.8,51.599999999999994), null);


(lib.Символ6копия4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(114.85,11.75,0.4393,0.4393,0,120.046,-59.954);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6копия4, new cjs.Rectangle(80.3,-39.8,52.8,51.599999999999994), null);


(lib.Символ6копия3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(114.85,11.75,0.4393,0.4393,0,120.046,-59.954);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6копия3, new cjs.Rectangle(80.3,-39.8,52.8,51.599999999999994), null);


(lib.Символ6копия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(114.85,11.75,0.4393,0.4393,0,120.046,-59.9523);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6копия2, new cjs.Rectangle(80.3,-39.8,52.8,51.599999999999994), null);


(lib.Символ6копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6копия, new cjs.Rectangle(0,0,41.5,45.5), null);


(lib.Символ6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ6, new cjs.Rectangle(0,0,41.5,45.5), null);


(lib.Символ5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ak9DsIAAnXIJ7AAIAAHXg");
	mask.setTransform(32.175,23.975);

	// Слой_2
	this.instance = new lib._1();
	this.instance.parent = this;
	this.instance.setTransform(-1,-1,0.5,0.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ5, new cjs.Rectangle(0.4,0.4,63.6,47.2), null);


(lib.Символ3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.c1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ3, new cjs.Rectangle(0,0,240,400), null);


(lib.Символ2копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4D7894").s().p("AAQAqIAAgzIAAAAIgNAlIgFAAIgNglIgBAAIAAAzIgMAAIAAhTIAMAAIAQAtIAAAAIAQgtIAMAAIAABTg");
	this.shape.setTransform(221.55,15.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_1.setTransform(215.65,15.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4D7894").s().p("AgFAqIAAhHIgPAAIAAgMIApAAIAAAMIgPAAIAABHg");
	this.shape_2.setTransform(211.175,15.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4D7894").s().p("AgPAlQgEgFAAgLIAAgqQAAgLAGgFQAFgFAIAAQAIAAAHAFQAEAGAAAIIAAAGIgLAAIAAgFQAAgDgBgCQgCgDgEgBQgDABgDADQgCACAAAGIAAAoQAAAFABACQADADADAAQAEAAADgDQABgCAAgFIAAgCIAMAAIAAADQAAAKgFAFQgFAGgKAAQgKAAgFgGg");
	this.shape_3.setTransform(206.95,15.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4D7894").s().p("AAKAqIAAgyIgTApIAAAJIgMAAIAAhTIAMAAIAAAyIATgpIAAgJIAMAAIAABTg");
	this.shape_4.setTransform(201.75,15.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4D7894").s().p("AAMAqIAAhIIgKAAIAAAMIgCAbIAAAPQgCAIgEAEQgFAGgJAAIgDAAIAAgMIABAAIAFgBQADgCABgDQACgFABgQIABgVIAAgXIAhAAIAABTg");
	this.shape_5.setTransform(196.125,15.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4D7894").s().p("AAMAqIgEgSIgPAAIgEASIgMAAIAThTIAJAAIATBTgAAGANIgGgeIgFAeIALAAg");
	this.shape_6.setTransform(191.675,15.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4D7894").s().p("AAKAqIAAgyIgTApIAAAJIgMAAIAAhTIAMAAIAAAyIATgpIAAgJIAMAAIAABTg");
	this.shape_7.setTransform(186.6,15.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4D7894").s().p("AAMAxIAAgOIgiAAIAAhSIAMAAIAABIIAOAAIAAhIIAMAAIAABIIAHAAIAAAYg");
	this.shape_8.setTransform(181.675,15.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4D7894").s().p("AgRAqIAAhTIAjAAIAAAMIgXAAIAAAYIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_9.setTransform(176.75,15.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4D7894").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_10.setTransform(171.85,15.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4D7894").s().p("AgPAlQgEgFAAgLIAAgqQAAgLAGgFQAGgFAHAAQAIAAAHAFQAEAGAAAIIAAAGIgLAAIAAgFQAAgDgBgCQgCgDgFgBQgDABgCADQgCACAAAGIAAAoQAAAFABACQADADADAAQAEAAADgDQABgCAAgFIAAgCIAMAAIAAADQAAAKgFAFQgFAGgKAAQgKAAgFgGg");
	this.shape_11.setTransform(167.1,15.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_12.setTransform(159.65,15.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#4D7894").s().p("AgPAlQgEgFAAgLIAAgqQAAgLAGgFQAFgFAIAAQAJAAAFAFQAGAGAAAIIAAAGIgMAAIAAgFQAAgDgCgCQgCgDgDgBQgDABgDADQgCACAAAGIAAAoQAAAFACACQABADAEAAQAEAAACgDQACgCAAgFIAAgCIAMAAIAAADQAAAKgFAFQgFAGgKAAQgJAAgGgGg");
	this.shape_13.setTransform(154.9,15.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#4D7894").s().p("AAJAqIAAgkIgHAAIgKAkIgMAAIAMgnQgEgBgCgCQgDgGgBgIIAAgFQABgKAEgGQADgEAHgCIAKAAIAPAAIAABTgAgDgcQgDACAAAGIAAAFQAAAGADACQADADAEAAIAFAAIAAgaIgFAAQgEAAgDACg");
	this.shape_14.setTransform(147.3,15.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#4D7894").s().p("AgPAlQgEgFAAgLIAAgqQAAgLAGgFQAFgFAIAAQAJAAAFAFQAGAGAAAIIAAAGIgMAAIAAgFQAAgDgCgCQgCgDgDgBQgDABgDADQgCACAAAGIAAAoQAAAFACACQABADAEAAQAEAAACgDQACgCAAgFIAAgCIAMAAIAAADQAAAKgFAFQgFAGgKAAQgJAAgGgGg");
	this.shape_15.setTransform(142.75,15.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#4D7894").s().p("AgTAqIAAhTIAMAAIAAAiIAGAAQALAAAFAFQAFADAAAJIAAAKQAAAJgEAFQgFAIgMAAgAgHAfIAFAAQAKAAAAgMIAAgFQAAgGgDgDQgDgCgDgBIgGAAg");
	this.shape_16.setTransform(138.05,15.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#4D7894").s().p("AgFAqIAAhHIgPAAIAAgMIApAAIAAAMIgPAAIAABHg");
	this.shape_17.setTransform(133.575,15.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#4D7894").s().p("AAMAqIgEgSIgPAAIgEASIgMAAIAThTIAJAAIATBTgAAGANIgGgeIgFAeIALAAg");
	this.shape_18.setTransform(129.325,15.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#4D7894").s().p("AgTAqIAAhTIARAAQAIAAAGAEQAIAGAAAOQAAAIgDAEIgGAFQAFAAACADQACAFAAAGIAAAGQAAAMgIAGQgFAEgHAAgAgHAfIAGAAQAEAAADgDQACgDAAgGIAAgEQAAgGgEgDQgCgDgCAAIgHAAgAgHgGIAGAAQAEAAADgDQACgDAAgFIAAgFQAAgDgCgCQgDgDgEAAIgGAAg");
	this.shape_19.setTransform(124.6,15.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgGgcQgCACAAAGIAAApQAAAFACADQADACADAAQAEAAADgCQACgDAAgFIAAgpQAAgGgCgCQgDgDgEAAQgDAAgDADg");
	this.shape_20.setTransform(119.55,15.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#4D7894").s().p("AgUAqIAAhTIASAAQALAAAFAGQAHAGAAAMIAAADQAAALgGAFQgFAHgKAAIgHAAIAAAhgAgHgBIAGAAQAEAAADgDQACgDAAgGIAAgFQAAgIgDgCQgDgCgFAAIgEAAg");
	this.shape_21.setTransform(114.75,15.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#4D7894").s().p("AAKAqIAAgyIgTApIAAAJIgMAAIAAhTIAMAAIAAAyIATgpIAAgJIAMAAIAABTg");
	this.shape_22.setTransform(109.4,15.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#4D7894").s().p("AgFAqIAAhHIgPAAIAAgMIApAAIAAAMIgPAAIAABHg");
	this.shape_23.setTransform(104.725,15.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#4D7894").s().p("AgTAqIAAhTIAMAAIAAAiIAGAAQALAAAFAFQAFADAAAJIAAAKQAAAJgDAFQgGAIgMAAgAgHAfIAGAAQAJAAAAgMIAAgFQAAgGgDgDQgDgCgDgBIgGAAg");
	this.shape_24.setTransform(100.5,15.25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#4D7894").s().p("AAMAqIAAhIIgKAAIAAAMIgCAbIAAAPQgCAIgEAEQgFAGgJAAIgDAAIAAgMIABAAIAFgBQADgCABgDQACgFABgQIABgVIAAgXIAhAAIAABTg");
	this.shape_25.setTransform(95.025,15.25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#4D7894").s().p("AgQAqIAAgMIADAAQAEAAACgCQACgBAAgDIABgHIgSg6IAOAAIAKApIAAAAIAEgRIAFgYIAMAAIgOA5IgEANQgCAIgEACQgEADgGAAg");
	this.shape_26.setTransform(90.85,15.25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#4D7894").s().p("AgPAlQgEgFAAgLIAAgqQAAgLAGgFQAFgFAIAAQAJAAAFAFQAFAGABAIIAAAGIgMAAIAAgFQAAgDgCgCQgCgDgDgBQgDABgDADQgCACAAAGIAAAoQAAAFACACQABADAEAAQAEAAACgDQACgCAAgFIAAgCIAMAAIAAADQAAAKgFAFQgFAGgKAAQgJAAgGgGg");
	this.shape_27.setTransform(86.4,15.25);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#4D7894").s().p("AAIAqIAAglIgPAAIAAAlIgMAAIAAhTIAMAAIAAAkIAPAAIAAgkIAMAAIAABTg");
	this.shape_28.setTransform(81.375,15.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_29.setTransform(76.3,15.25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#4D7894").s().p("AAKAqIgKgkIgKAAIAAAkIgMAAIAAhSIAMAAIAAAkIAHAAQADgBABgCQABgDABgIIABgIQABgJAEgDQAEgDAHAAIACAAIAAALIgCAAIgDAAQgBACgBAIIgBAIIgCAJIgCADIANAqg");
	this.shape_30.setTransform(71.375,15.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_31.setTransform(66.05,15.25);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#4D7894").s().p("AgTAqIAAhTIASAAQAKAAAGAGQAFAGAAAMIAAADQAAALgEAFQgHAHgJAAIgIAAIAAAhgAgIgBIAHAAQAFAAACgDQACgDAAgGIAAgFQAAgIgDgCQgCgCgGAAIgFAAg");
	this.shape_32.setTransform(61.25,15.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#4D7894").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_33.setTransform(56.15,15.25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_34.setTransform(48.6,15.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#4D7894").s().p("AARAqIAAgzIgBAAIgNAlIgFAAIgNglIgBAAIAAAzIgLAAIAAhTIALAAIAQAtIAAAAIARgtIALAAIAABTg");
	this.shape_35.setTransform(42.7,15.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#4D7894").s().p("AAKAqIAAgyIgTApIAAAJIgMAAIAAhTIAMAAIAAAyIATgpIAAgJIAMAAIAABTg");
	this.shape_36.setTransform(36.55,15.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#4D7894").s().p("AAQAxIAAgOIgeAAIAAAOIgMAAIAAgYIAGAAQAEgKACgKQACgNAAgiIAAgFIAgAAIAABIIAHAAIAAAYgAAAgeQAAAZgDANQgBAJgEAIIAQAAIAAg+IgIAAg");
	this.shape_37.setTransform(31.225,15.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgGgcQgCACAAAGIAAApQAAAFACADQADACADAAQAEAAADgCQACgDAAgFIAAgpQAAgGgCgCQgDgDgEAAQgDAAgDADg");
	this.shape_38.setTransform(26.25,15.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#4D7894").s().p("AAMAqIgMgfIgKAfIgNAAIARgrIgQgoIANAAIAJAaIAJgaIAOAAIgRAoIASArg");
	this.shape_39.setTransform(21.275,15.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#4D7894").s().p("AgTAqIAAhTIAkAAIAAAMIgYAAIAAAWIAGAAQALAAAFAFQAFADAAAJIAAAKQAAAJgDAFQgGAIgLAAgAgHAfIAGAAQAEAAACgDQADgEAAgFIAAgFQAAgGgEgDQgCgCgCgBIgHAAg");
	this.shape_40.setTransform(16.5,15.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_41.setTransform(11.45,15.25);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#4D7894").s().p("AgRAqIAAhTIAjAAIAAAMIgXAAIAAAYIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_42.setTransform(6.85,15.25);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#4D7894").s().p("AAIAqIAAglIgPAAIAAAlIgMAAIAAhTIAMAAIAAAkIAPAAIAAgkIAMAAIAABTg");
	this.shape_43.setTransform(1.925,15.25);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#4D7894").s().p("AAQAqIAAg0IAAAAIgNAmIgFAAIgMgmIgBAAIAAA0IgNAAIAAhTIANAAIAPAtIABAAIAPgtIANAAIAABTg");
	this.shape_44.setTransform(221.95,3.25);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#4D7894").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_45.setTransform(216.1,3.25);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#4D7894").s().p("AAKAqIAAgyIgTAoIAAAKIgMAAIAAhTIAMAAIAAAzIATgqIAAgJIAMAAIAABTg");
	this.shape_46.setTransform(210.55,3.25);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#4D7894").s().p("AAIAqIAAglIgPAAIAAAlIgMAAIAAhTIAMAAIAAAkIAPAAIAAgkIAMAAIAABTg");
	this.shape_47.setTransform(204.825,3.25);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#4D7894").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_48.setTransform(199.8,3.25);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#4D7894").s().p("AAIAqIAAglIgPAAIAAAlIgMAAIAAhTIAMAAIAAAkIAPAAIAAgkIAMAAIAABTg");
	this.shape_49.setTransform(194.475,3.25);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#4D7894").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_50.setTransform(189.4,3.25);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#4D7894").s().p("AAQAqIAAg0IAAAAIgNAmIgFAAIgMgmIgBAAIAAA0IgNAAIAAhTIANAAIAPAtIABAAIAPgtIANAAIAABTg");
	this.shape_51.setTransform(183.25,3.25);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#4D7894").s().p("AAKAqIAAgyIgTAoIAAAKIgMAAIAAhTIAMAAIAAAzIATgqIAAgJIAMAAIAABTg");
	this.shape_52.setTransform(176.7,3.25);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#4D7894").s().p("AgTAqIAAhTIASAAQAKAAAFAGQAHAGgBANIAAACQAAALgEAFQgHAHgJAAIgHAAIAAAhgAgHgBIAGAAQAFAAACgDQACgDABgGIAAgGQgBgGgDgDQgDgCgFAAIgEAAg");
	this.shape_53.setTransform(171.3,3.25);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#4D7894").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_54.setTransform(165.75,3.25);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#4D7894").s().p("AAQAwIAAgMIgeAAIAAAMIgMAAIAAgXIAGAAQAEgKACgLQACgMAAgiIAAgGIAgAAIAABJIAHAAIAAAXgAAAgeQAAAZgDAOQgBAIgEAJIAQAAIAAg+IgIAAg");
	this.shape_55.setTransform(157.325,3.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#4D7894").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_56.setTransform(152.4,3.25);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#4D7894").s().p("AgUAqIAAhTIASAAQALAAAGAGQAFAGABANIAAACQgBALgFAFQgGAHgJAAIgIAAIAAAhgAgIgBIAHAAQAEAAADgDQADgDgBgGIAAgGQABgGgEgDQgCgCgGAAIgFAAg");
	this.shape_57.setTransform(147.4,3.25);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#4D7894").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_58.setTransform(142.3,3.25);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#4D7894").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_59.setTransform(137,3.25);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#4D7894").s().p("AgFAHIAAgNIALAAIAAANg");
	this.shape_60.setTransform(129.95,6.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#4D7894").s().p("AAKAqIAAgkIgIAAIgJAkIgOAAIANgnQgDgBgDgDQgEgFABgIIAAgGQgBgJAFgFQADgFAHgCIAJAAIAPAAIAABTgAgDgcQgCADgBAEIAAAHQABAFACACQADADADAAIAHAAIAAgaIgGAAQgFAAgCACg");
	this.shape_61.setTransform(125.75,3.25);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#4D7894").s().p("AAKAqIAAgyIgTAoIAAAKIgMAAIAAhTIAMAAIAAAzIATgqIAAgJIAMAAIAABTg");
	this.shape_62.setTransform(120.3,3.25);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#4D7894").s().p("AAIAqIAAglIgPAAIAAAlIgMAAIAAhTIAMAAIAAAkIAPAAIAAgkIAMAAIAABTg");
	this.shape_63.setTransform(114.575,3.25);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#4D7894").s().p("AAMAqIgEgSIgPAAIgEASIgMAAIAThTIAJAAIATBTgAAGANIgGgeIgFAeIALAAg");
	this.shape_64.setTransform(109.325,3.25);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#4D7894").s().p("AgOAnQgFgFAAgHIAAgIIAMAAIAAAEQAAAEACADQACABADAAQAEAAACgBQACgDAAgFIAAgHQAAgHgDgDQgCgCgDAAIgEAAIAAgJIADAAQAEAAADgDQACgCAAgFIAAgGQAAgFgCgCQgDgCgDAAQgDABgCACQgCACAAAEIAAAFIgMAAIAAgHQAAgJAGgFQAGgEAHAAQAJAAAEADQAHAGAAAJIAAAHQAAAIgDAFIgFADQAEACACACQACAFAAAGIAAAKQAAAJgFAGQgGAEgJAAQgJAAgFgEg");
	this.shape_65.setTransform(104.15,3.25);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#4D7894").s().p("AAMAqIgEgSIgPAAIgEASIgMAAIAThTIAJAAIATBTgAAGANIgGgeIgFAeIALAAg");
	this.shape_66.setTransform(99.275,3.25);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#4D7894").s().p("AAKArIgKglIgKAAIAAAlIgMAAIAAhUIAMAAIAAAkIAHAAQADAAABgCQABgDABgIIABgIQABgJAEgDQAEgEAHAAIACAAIAAAMIgCAAIgDABQgBABgBAIIgBAIIgCAJIgCADIANArg");
	this.shape_67.setTransform(94.175,3.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgGgcQgCADAAAEIAAArQAAAEACADQADADADgBQAEABACgDQADgDAAgEIAAgrQAAgEgDgDQgCgCgEgBQgDABgDACg");
	this.shape_68.setTransform(88.4,3.25);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#4D7894").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_69.setTransform(82.9,3.25);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDADAAAEIAAArQAAAEADADQACADADgBQAEABACgDQADgDAAgEIAAgrQAAgEgDgDQgCgCgEgBQgDABgCACg");
	this.shape_70.setTransform(77.4,3.25);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#4D7894").s().p("AgTAqIAAhTIARAAQAIAAAGAEQAIAGAAAOQAAAIgDAFIgGADQAFABABADQADAFAAAGIAAAHQAAAMgIAFQgEAEgIAAgAgHAfIAGAAQAEAAADgDQACgEAAgFIAAgEQAAgHgDgCQgDgCgCgBIgHAAgAgHgGIAGAAQAEAAADgEQACgCAAgEIAAgGQAAgDgCgDQgDgCgEAAIgGAAg");
	this.shape_71.setTransform(72.05,3.25);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#4D7894").s().p("AAKAqIAAgyIgTAoIAAAKIgMAAIAAhTIAMAAIAAAzIATgqIAAgJIAMAAIAABTg");
	this.shape_72.setTransform(66.35,3.25);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#4D7894").s().p("AgFAqIAAhIIgPAAIAAgLIApAAIAAALIgPAAIAABIg");
	this.shape_73.setTransform(61.225,3.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#4D7894").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDADAAAEIAAArQAAAEADADQACADADgBQAEABACgDQADgDAAgEIAAgrQAAgEgDgDQgCgCgEgBQgDABgCACg");
	this.shape_74.setTransform(56.35,3.25);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#4D7894").s().p("AgTAqIAAhTIASAAQAKAAAFAGQAHAGgBANIAAACQAAALgEAFQgHAHgJAAIgHAAIAAAhgAgHgBIAGAAQAFAAACgDQACgDABgGIAAgGQgBgGgDgDQgDgCgFAAIgEAAg");
	this.shape_75.setTransform(51.15,3.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#4D7894").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_76.setTransform(45.6,3.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#4D7894").s().p("AAJAqIAAgkIgHAAIgKAkIgMAAIAMgnQgEgBgCgDQgDgFgBgIIAAgGQABgJAEgFQAEgFAGgCIAKAAIAPAAIAABTgAgDgcQgDADAAAEIAAAHQAAAFADACQADADAEAAIAFAAIAAgaIgFAAQgFAAgCACg");
	this.shape_77.setTransform(37.05,3.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#4D7894").s().p("AgPAlQgEgFAAgKIAAgrQAAgLAGgGQAGgEAHAAQAIAAAHAFQAEAFAAAJIAAAGIgLAAIAAgFQAAgDgBgDQgCgDgFAAQgDAAgCADQgCADAAAFIAAApQAAAGABACQADACADAAQAEAAADgCQABgDAAgEIAAgDIAMAAIAAADQAAAKgFAGQgFAFgKAAQgKAAgFgGg");
	this.shape_78.setTransform(32.1,3.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#4D7894").s().p("AgFAqIAAhIIgPAAIAAgLIApAAIAAALIgPAAIAABIg");
	this.shape_79.setTransform(27.325,3.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#4D7894").s().p("AgCAmQgHgGAAgMIAAgPIgKAAIAAAlIgMAAIAAhTIAMAAIAAAkIAKAAIAAgOQAAgMAHgGQAEgFAJAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgJAAgEgFgAAFgcQgDADAAAEIAAArQAAAEADADQACADAEgBQAEABACgDQADgDAAgEIAAgrQAAgEgDgDQgCgCgEgBQgEABgCACg");
	this.shape_80.setTransform(21.3,3.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#4D7894").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_81.setTransform(15.05,3.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#4D7894").s().p("AAQAqIAAg0IAAAAIgNAmIgFAAIgMgmIgBAAIAAA0IgNAAIAAhTIANAAIAPAtIAAAAIAQgtIANAAIAABTg");
	this.shape_82.setTransform(8.9,3.25);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#4D7894").s().p("AAKAqIAAgyIgTAoIAAAKIgMAAIAAhTIAMAAIAAAzIATgqIAAgJIAMAAIAABTg");
	this.shape_83.setTransform(2.35,3.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ2копия, new cjs.Rectangle(-2,-2.7,233.8,25.9), null);


(lib.Символ2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQAqIAAgzIAAAAIgNAlIgFAAIgNglIgBAAIAAAzIgMAAIAAhTIAMAAIAQAtIAAAAIAQgtIAMAAIAABTg");
	this.shape.setTransform(221.55,15.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_1.setTransform(215.65,15.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgFAqIAAhHIgPAAIAAgMIApAAIAAAMIgPAAIAABHg");
	this.shape_2.setTransform(211.175,15.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgPAlQgEgFAAgLIAAgqQAAgLAGgFQAFgFAIAAQAIAAAHAFQAEAGAAAIIAAAGIgLAAIAAgFQAAgDgBgCQgCgDgEgBQgDABgDADQgCACAAAGIAAAoQAAAFABACQADADADAAQAEAAADgDQABgCAAgFIAAgCIAMAAIAAADQAAAKgFAFQgFAGgKAAQgKAAgFgGg");
	this.shape_3.setTransform(206.95,15.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAKAqIAAgyIgTApIAAAJIgMAAIAAhTIAMAAIAAAyIATgpIAAgJIAMAAIAABTg");
	this.shape_4.setTransform(201.75,15.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAMAqIAAhIIgKAAIAAAMIgCAbIAAAPQgCAIgEAEQgFAGgJAAIgDAAIAAgMIABAAIAFgBQADgCABgDQACgFABgQIABgVIAAgXIAhAAIAABTg");
	this.shape_5.setTransform(196.125,15.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAMAqIgEgSIgPAAIgEASIgMAAIAThTIAJAAIATBTgAAGANIgGgeIgFAeIALAAg");
	this.shape_6.setTransform(191.675,15.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAKAqIAAgyIgTApIAAAJIgMAAIAAhTIAMAAIAAAyIATgpIAAgJIAMAAIAABTg");
	this.shape_7.setTransform(186.6,15.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAMAxIAAgOIgiAAIAAhSIAMAAIAABIIAOAAIAAhIIAMAAIAABIIAHAAIAAAYg");
	this.shape_8.setTransform(181.675,15.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgRAqIAAhTIAjAAIAAAMIgXAAIAAAYIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_9.setTransform(176.75,15.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_10.setTransform(171.85,15.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPAlQgEgFAAgLIAAgqQAAgLAGgFQAGgFAHAAQAIAAAHAFQAEAGAAAIIAAAGIgLAAIAAgFQAAgDgBgCQgCgDgFgBQgDABgCADQgCACAAAGIAAAoQAAAFABACQADADADAAQAEAAADgDQABgCAAgFIAAgCIAMAAIAAADQAAAKgFAFQgFAGgKAAQgKAAgFgGg");
	this.shape_11.setTransform(167.1,15.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_12.setTransform(159.65,15.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgPAlQgEgFAAgLIAAgqQAAgLAGgFQAFgFAIAAQAJAAAFAFQAGAGAAAIIAAAGIgMAAIAAgFQAAgDgCgCQgCgDgDgBQgDABgDADQgCACAAAGIAAAoQAAAFACACQABADAEAAQAEAAACgDQACgCAAgFIAAgCIAMAAIAAADQAAAKgFAFQgFAGgKAAQgJAAgGgGg");
	this.shape_13.setTransform(154.9,15.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAJAqIAAgkIgHAAIgKAkIgMAAIAMgnQgEgBgCgCQgDgGgBgIIAAgFQABgKAEgGQADgEAHgCIAKAAIAPAAIAABTgAgDgcQgDACAAAGIAAAFQAAAGADACQADADAEAAIAFAAIAAgaIgFAAQgEAAgDACg");
	this.shape_14.setTransform(147.3,15.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgPAlQgEgFAAgLIAAgqQAAgLAGgFQAFgFAIAAQAJAAAFAFQAGAGAAAIIAAAGIgMAAIAAgFQAAgDgCgCQgCgDgDgBQgDABgDADQgCACAAAGIAAAoQAAAFACACQABADAEAAQAEAAACgDQACgCAAgFIAAgCIAMAAIAAADQAAAKgFAFQgFAGgKAAQgJAAgGgGg");
	this.shape_15.setTransform(142.75,15.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgTAqIAAhTIAMAAIAAAiIAGAAQALAAAFAFQAFADAAAJIAAAKQAAAJgEAFQgFAIgMAAgAgHAfIAFAAQAKAAAAgMIAAgFQAAgGgDgDQgDgCgDgBIgGAAg");
	this.shape_16.setTransform(138.05,15.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgFAqIAAhHIgPAAIAAgMIApAAIAAAMIgPAAIAABHg");
	this.shape_17.setTransform(133.575,15.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAMAqIgEgSIgPAAIgEASIgMAAIAThTIAJAAIATBTgAAGANIgGgeIgFAeIALAAg");
	this.shape_18.setTransform(129.325,15.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgTAqIAAhTIARAAQAIAAAGAEQAIAGAAAOQAAAIgDAEIgGAFQAFAAACADQACAFAAAGIAAAGQAAAMgIAGQgFAEgHAAgAgHAfIAGAAQAEAAADgDQACgDAAgGIAAgEQAAgGgEgDQgCgDgCAAIgHAAgAgHgGIAGAAQAEAAADgDQACgDAAgFIAAgFQAAgDgCgCQgDgDgEAAIgGAAg");
	this.shape_19.setTransform(124.6,15.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgGgcQgCACAAAGIAAApQAAAFACADQADACADAAQAEAAADgCQACgDAAgFIAAgpQAAgGgCgCQgDgDgEAAQgDAAgDADg");
	this.shape_20.setTransform(119.55,15.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgUAqIAAhTIASAAQALAAAFAGQAHAGAAAMIAAADQAAALgGAFQgFAHgKAAIgHAAIAAAhgAgHgBIAGAAQAEAAADgDQACgDAAgGIAAgFQAAgIgDgCQgDgCgFAAIgEAAg");
	this.shape_21.setTransform(114.75,15.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAKAqIAAgyIgTApIAAAJIgMAAIAAhTIAMAAIAAAyIATgpIAAgJIAMAAIAABTg");
	this.shape_22.setTransform(109.4,15.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgFAqIAAhHIgPAAIAAgMIApAAIAAAMIgPAAIAABHg");
	this.shape_23.setTransform(104.725,15.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgTAqIAAhTIAMAAIAAAiIAGAAQALAAAFAFQAFADAAAJIAAAKQAAAJgDAFQgGAIgMAAgAgHAfIAGAAQAJAAAAgMIAAgFQAAgGgDgDQgDgCgDgBIgGAAg");
	this.shape_24.setTransform(100.5,15.25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAMAqIAAhIIgKAAIAAAMIgCAbIAAAPQgCAIgEAEQgFAGgJAAIgDAAIAAgMIABAAIAFgBQADgCABgDQACgFABgQIABgVIAAgXIAhAAIAABTg");
	this.shape_25.setTransform(95.025,15.25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgQAqIAAgMIADAAQAEAAACgCQACgBAAgDIABgHIgSg6IAOAAIAKApIAAAAIAEgRIAFgYIAMAAIgOA5IgEANQgCAIgEACQgEADgGAAg");
	this.shape_26.setTransform(90.85,15.25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgPAlQgEgFAAgLIAAgqQAAgLAGgFQAFgFAIAAQAJAAAFAFQAFAGABAIIAAAGIgMAAIAAgFQAAgDgCgCQgCgDgDgBQgDABgDADQgCACAAAGIAAAoQAAAFACACQABADAEAAQAEAAACgDQACgCAAgFIAAgCIAMAAIAAADQAAAKgFAFQgFAGgKAAQgJAAgGgGg");
	this.shape_27.setTransform(86.4,15.25);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAIAqIAAglIgPAAIAAAlIgMAAIAAhTIAMAAIAAAkIAPAAIAAgkIAMAAIAABTg");
	this.shape_28.setTransform(81.375,15.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_29.setTransform(76.3,15.25);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAKAqIgKgkIgKAAIAAAkIgMAAIAAhSIAMAAIAAAkIAHAAQADgBABgCQABgDABgIIABgIQABgJAEgDQAEgDAHAAIACAAIAAALIgCAAIgDAAQgBACgBAIIgBAIIgCAJIgCADIANAqg");
	this.shape_30.setTransform(71.375,15.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_31.setTransform(66.05,15.25);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgTAqIAAhTIASAAQAKAAAGAGQAFAGAAAMIAAADQAAALgEAFQgHAHgJAAIgIAAIAAAhgAgIgBIAHAAQAFAAACgDQACgDAAgGIAAgFQAAgIgDgCQgCgCgGAAIgFAAg");
	this.shape_32.setTransform(61.25,15.25);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_33.setTransform(56.15,15.25);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_34.setTransform(48.6,15.25);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AARAqIAAgzIgBAAIgNAlIgFAAIgNglIgBAAIAAAzIgLAAIAAhTIALAAIAQAtIAAAAIARgtIALAAIAABTg");
	this.shape_35.setTransform(42.7,15.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAKAqIAAgyIgTApIAAAJIgMAAIAAhTIAMAAIAAAyIATgpIAAgJIAMAAIAABTg");
	this.shape_36.setTransform(36.55,15.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAQAxIAAgOIgeAAIAAAOIgMAAIAAgYIAGAAQAEgKACgKQACgNAAgiIAAgFIAgAAIAABIIAHAAIAAAYgAAAgeQAAAZgDANQgBAJgEAIIAQAAIAAg+IgIAAg");
	this.shape_37.setTransform(31.225,15.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgGgcQgCACAAAGIAAApQAAAFACADQADACADAAQAEAAADgCQACgDAAgFIAAgpQAAgGgCgCQgDgDgEAAQgDAAgDADg");
	this.shape_38.setTransform(26.25,15.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAMAqIgMgfIgKAfIgNAAIARgrIgQgoIANAAIAJAaIAJgaIAOAAIgRAoIASArg");
	this.shape_39.setTransform(21.275,15.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgTAqIAAhTIAkAAIAAAMIgYAAIAAAWIAGAAQALAAAFAFQAFADAAAJIAAAKQAAAJgDAFQgGAIgLAAgAgHAfIAGAAQAEAAACgDQADgEAAgFIAAgFQAAgGgEgDQgCgCgCgBIgHAAg");
	this.shape_40.setTransform(16.5,15.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDACAAAGIAAApQAAAFADADQACACADAAQAEAAACgCQADgDAAgFIAAgpQAAgGgDgCQgCgDgEAAQgDAAgCADg");
	this.shape_41.setTransform(11.45,15.25);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgRAqIAAhTIAjAAIAAAMIgXAAIAAAYIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_42.setTransform(6.85,15.25);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAIAqIAAglIgPAAIAAAlIgMAAIAAhTIAMAAIAAAkIAPAAIAAgkIAMAAIAABTg");
	this.shape_43.setTransform(1.925,15.25);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AAQAqIAAg0IAAAAIgNAmIgFAAIgMgmIgBAAIAAA0IgNAAIAAhTIANAAIAPAtIABAAIAPgtIANAAIAABTg");
	this.shape_44.setTransform(221.95,3.25);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_45.setTransform(216.1,3.25);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAKAqIAAgyIgTAoIAAAKIgMAAIAAhTIAMAAIAAAzIATgqIAAgJIAMAAIAABTg");
	this.shape_46.setTransform(210.55,3.25);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AAIAqIAAglIgPAAIAAAlIgMAAIAAhTIAMAAIAAAkIAPAAIAAgkIAMAAIAABTg");
	this.shape_47.setTransform(204.825,3.25);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_48.setTransform(199.8,3.25);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AAIAqIAAglIgPAAIAAAlIgMAAIAAhTIAMAAIAAAkIAPAAIAAgkIAMAAIAABTg");
	this.shape_49.setTransform(194.475,3.25);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_50.setTransform(189.4,3.25);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AAQAqIAAg0IAAAAIgNAmIgFAAIgMgmIgBAAIAAA0IgNAAIAAhTIANAAIAPAtIABAAIAPgtIANAAIAABTg");
	this.shape_51.setTransform(183.25,3.25);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAKAqIAAgyIgTAoIAAAKIgMAAIAAhTIAMAAIAAAzIATgqIAAgJIAMAAIAABTg");
	this.shape_52.setTransform(176.7,3.25);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgTAqIAAhTIASAAQAKAAAFAGQAHAGgBANIAAACQAAALgEAFQgHAHgJAAIgHAAIAAAhgAgHgBIAGAAQAFAAACgDQACgDABgGIAAgGQgBgGgDgDQgDgCgFAAIgEAAg");
	this.shape_53.setTransform(171.3,3.25);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_54.setTransform(165.75,3.25);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AAQAwIAAgMIgeAAIAAAMIgMAAIAAgXIAGAAQAEgKACgLQACgMAAgiIAAgGIAgAAIAABJIAHAAIAAAXgAAAgeQAAAZgDAOQgBAIgEAJIAQAAIAAg+IgIAAg");
	this.shape_55.setTransform(157.325,3.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_56.setTransform(152.4,3.25);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgUAqIAAhTIASAAQALAAAGAGQAFAGABANIAAACQgBALgFAFQgGAHgJAAIgIAAIAAAhgAgIgBIAHAAQAEAAADgDQADgDgBgGIAAgGQABgGgEgDQgCgCgGAAIgFAAg");
	this.shape_57.setTransform(147.4,3.25);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_58.setTransform(142.3,3.25);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_59.setTransform(137,3.25);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgFAHIAAgNIALAAIAAANg");
	this.shape_60.setTransform(129.95,6.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AAKAqIAAgkIgIAAIgJAkIgOAAIANgnQgDgBgDgDQgEgFABgIIAAgGQgBgJAFgFQADgFAHgCIAJAAIAPAAIAABTgAgDgcQgCADgBAEIAAAHQABAFACACQADADADAAIAHAAIAAgaIgGAAQgFAAgCACg");
	this.shape_61.setTransform(125.75,3.25);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AAKAqIAAgyIgTAoIAAAKIgMAAIAAhTIAMAAIAAAzIATgqIAAgJIAMAAIAABTg");
	this.shape_62.setTransform(120.3,3.25);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AAIAqIAAglIgPAAIAAAlIgMAAIAAhTIAMAAIAAAkIAPAAIAAgkIAMAAIAABTg");
	this.shape_63.setTransform(114.575,3.25);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AAMAqIgEgSIgPAAIgEASIgMAAIAThTIAJAAIATBTgAAGANIgGgeIgFAeIALAAg");
	this.shape_64.setTransform(109.325,3.25);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgOAnQgFgFAAgHIAAgIIAMAAIAAAEQAAAEACADQACABADAAQAEAAACgBQACgDAAgFIAAgHQAAgHgDgDQgCgCgDAAIgEAAIAAgJIADAAQAEAAADgDQACgCAAgFIAAgGQAAgFgCgCQgDgCgDAAQgDABgCACQgCACAAAEIAAAFIgMAAIAAgHQAAgJAGgFQAGgEAHAAQAJAAAEADQAHAGAAAJIAAAHQAAAIgDAFIgFADQAEACACACQACAFAAAGIAAAKQAAAJgFAGQgGAEgJAAQgJAAgFgEg");
	this.shape_65.setTransform(104.15,3.25);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AAMAqIgEgSIgPAAIgEASIgMAAIAThTIAJAAIATBTgAAGANIgGgeIgFAeIALAAg");
	this.shape_66.setTransform(99.275,3.25);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AAKArIgKglIgKAAIAAAlIgMAAIAAhUIAMAAIAAAkIAHAAQADAAABgCQABgDABgIIABgIQABgJAEgDQAEgEAHAAIACAAIAAAMIgCAAIgDABQgBABgBAIIgBAIIgCAJIgCADIANArg");
	this.shape_67.setTransform(94.175,3.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgGgcQgCADAAAEIAAArQAAAEACADQADADADgBQAEABACgDQADgDAAgEIAAgrQAAgEgDgDQgCgCgEgBQgDABgDACg");
	this.shape_68.setTransform(88.4,3.25);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_69.setTransform(82.9,3.25);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDADAAAEIAAArQAAAEADADQACADADgBQAEABACgDQADgDAAgEIAAgrQAAgEgDgDQgCgCgEgBQgDABgCACg");
	this.shape_70.setTransform(77.4,3.25);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgTAqIAAhTIARAAQAIAAAGAEQAIAGAAAOQAAAIgDAFIgGADQAFABABADQADAFAAAGIAAAHQAAAMgIAFQgEAEgIAAgAgHAfIAGAAQAEAAADgDQACgEAAgFIAAgEQAAgHgDgCQgDgCgCgBIgHAAgAgHgGIAGAAQAEAAADgEQACgCAAgEIAAgGQAAgDgCgDQgDgCgEAAIgGAAg");
	this.shape_71.setTransform(72.05,3.25);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AAKAqIAAgyIgTAoIAAAKIgMAAIAAhTIAMAAIAAAzIATgqIAAgJIAMAAIAABTg");
	this.shape_72.setTransform(66.35,3.25);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgFAqIAAhIIgPAAIAAgLIApAAIAAALIgPAAIAABIg");
	this.shape_73.setTransform(61.225,3.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgOAmQgGgGAAgMIAAgnQAAgMAGgGQAGgFAIAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgIAAgGgFgAgFgcQgDADAAAEIAAArQAAAEADADQACADADgBQAEABACgDQADgDAAgEIAAgrQAAgEgDgDQgCgCgEgBQgDABgCACg");
	this.shape_74.setTransform(56.35,3.25);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgTAqIAAhTIASAAQAKAAAFAGQAHAGgBANIAAACQAAALgEAFQgHAHgJAAIgHAAIAAAhgAgHgBIAGAAQAFAAACgDQACgDABgGIAAgGQgBgGgDgDQgDgCgFAAIgEAAg");
	this.shape_75.setTransform(51.15,3.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AAIAqIAAhIIgPAAIAABIIgMAAIAAhTIAnAAIAABTg");
	this.shape_76.setTransform(45.6,3.25);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AAJAqIAAgkIgHAAIgKAkIgMAAIAMgnQgEgBgCgDQgDgFgBgIIAAgGQABgJAEgFQAEgFAGgCIAKAAIAPAAIAABTgAgDgcQgDADAAAEIAAAHQAAAFADACQADADAEAAIAFAAIAAgaIgFAAQgFAAgCACg");
	this.shape_77.setTransform(37.05,3.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgPAlQgEgFAAgKIAAgrQAAgLAGgGQAGgEAHAAQAIAAAHAFQAEAFAAAJIAAAGIgLAAIAAgFQAAgDgBgDQgCgDgFAAQgDAAgCADQgCADAAAFIAAApQAAAGABACQADACADAAQAEAAADgCQABgDAAgEIAAgDIAMAAIAAADQAAAKgFAGQgFAFgKAAQgKAAgFgGg");
	this.shape_78.setTransform(32.1,3.25);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgFAqIAAhIIgPAAIAAgLIApAAIAAALIgPAAIAABIg");
	this.shape_79.setTransform(27.325,3.25);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgCAmQgHgGAAgMIAAgPIgKAAIAAAlIgMAAIAAhTIAMAAIAAAkIAKAAIAAgOQAAgMAHgGQAEgFAJAAQAJAAAGAFQAGAGAAAMIAAAnQAAAMgGAGQgGAFgJAAQgJAAgEgFgAAFgcQgDADAAAEIAAArQAAAEADADQACADAEgBQAEABACgDQADgDAAgEIAAgrQAAgEgDgDQgCgCgEgBQgEABgCACg");
	this.shape_80.setTransform(21.3,3.25);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgRAqIAAhTIAjAAIAAALIgXAAIAAAZIAUAAIAAAKIgUAAIAAAZIAXAAIAAAMg");
	this.shape_81.setTransform(15.05,3.25);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AAQAqIAAg0IAAAAIgNAmIgFAAIgMgmIgBAAIAAA0IgNAAIAAhTIANAAIAPAtIAAAAIAQgtIANAAIAABTg");
	this.shape_82.setTransform(8.9,3.25);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AAKAqIAAgyIgTAoIAAAKIgMAAIAAhTIAMAAIAAAzIATgqIAAgJIAMAAIAABTg");
	this.shape_83.setTransform(2.35,3.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ2, new cjs.Rectangle(-2,-2.7,233.8,25.9), null);


(lib.Символ1копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
	this.shape.setTransform(120,200);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ1копия, new cjs.Rectangle(0,0,240,400), null);


(lib.Символ1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
	this.shape.setTransform(120,200);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ1, new cjs.Rectangle(0,0,240,400), null);


(lib.Символ44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Bact12
	this.instance = new lib.Символ7копия11();
	this.instance.parent = this;
	this.instance.setTransform(235.2,313.3,0.5504,0.5952,-21.796,0,0,14.6,20.5);
	this.instance.filters = [new cjs.BlurFilter(3, 3, 3)];
	this.instance.cache(-6,-2,41,45);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:14.5,regY:20.4,scaleX:0.5793,scaleY:0.6266,rotation:-21.7986,x:231.35,y:309.35},119).wait(1));

	// Bact9
	this.instance_1 = new lib.Символ7копия8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(234,133.15,0.2866,0.31,133.9969,0,0,14.6,19.9);
	this.instance_1.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_1.cache(-6,-2,41,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:14.3,regY:20.4,scaleX:0.3018,scaleY:0.3264,rotation:68.0026,x:229.1,y:111.3},119).wait(1));

	// Bact8
	this.instance_2 = new lib.Символ7копия7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(207.65,40.2,0.4851,0.7304,10.9986,0,0,-23.2,63.2);
	this.instance_2.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_2.cache(-39,40,32,48);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:0.5106,scaleY:0.7689,rotation:82.1854,x:198.2,y:21.9},119).wait(1));

	// Bact7
	this.instance_3 = new lib.Символ7копия6();
	this.instance_3.parent = this;
	this.instance_3.setTransform(232.15,235,0.8929,0.8929,166.9992,0,0,-23.3,63.3);
	this.instance_3.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_3.cache(-38,41,29,46);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:-23.4,scaleX:0.94,scaleY:0.94,rotation:82.0003,x:221.95,y:226.95},119).wait(1));

	// Bact6
	this.instance_4 = new lib.Символ7копия5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(185.9,267.7,0.7397,0.7397,54.3284,0,0,14.1,20.4);
	this.instance_4.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_4.cache(-1,-3,30,46);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:14,scaleX:0.7787,scaleY:0.7787,rotation:54.3291,x:183.7,y:261.35},119).wait(1));

	// Bact5
	this.instance_5 = new lib.Символ7копия4();
	this.instance_5.parent = this;
	this.instance_5.setTransform(237.1,206.05,0.5125,0.5125,129.2598,0,0,14,20.4);
	this.instance_5.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_5.cache(-2,-2,32,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({scaleX:0.5395,scaleY:0.5395,rotation:129.2601,x:237.7,y:196.5},119).wait(1));

	// Bact4
	this.instance_6 = new lib.Символ7копия3();
	this.instance_6.parent = this;
	this.instance_6.setTransform(215.2,197.65,0.5125,0.5125,-75.2286,0,0,14,20.5);
	this.instance_6.alpha = 0.6992;
	this.instance_6.filters = [new cjs.BlurFilter(3, 3, 3)];
	this.instance_6.cache(-2,-2,32,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({regY:20.4,scaleX:0.5395,scaleY:0.5395,rotation:-75.2288,x:214.6,y:187.65},119).wait(1));

	// Bact3
	this.instance_7 = new lib.Символ7копия2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(202.75,356.85,0.8352,0.8352,-117.9995,0,0,14,20.4);
	this.instance_7.alpha = 0.6797;
	this.instance_7.filters = [new cjs.BlurFilter(3, 3, 3)];
	this.instance_7.cache(-2,-2,32,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({regX:14.1,scaleX:0.8793,scaleY:0.8793,rotation:-75.2108,x:201.55,y:347.85},119).wait(1));

	// Bact2
	this.instance_8 = new lib.Символ7копия();
	this.instance_8.parent = this;
	this.instance_8.setTransform(191.15,332.3,1.0909,1.0909,-23.0001,0,0,14.2,20.4);
	this.instance_8.filters = [new cjs.BlurFilter(3, 3, 3)];
	this.instance_8.cache(-2,-2,32,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({regX:14.1,regY:20.2,scaleX:1.1483,scaleY:1.1483,rotation:29.859,x:185.05,y:329.2},119).wait(1));

	// Bact1
	this.instance_9 = new lib.Символ7();
	this.instance_9.parent = this;
	this.instance_9.setTransform(213.2,269.9,0.95,0.95,-23.0002,0,0,14,20.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({regX:14.1,regY:20.2,scaleX:1,scaleY:1,rotation:21,x:212.55,y:263.65},119).wait(1));

	// bact11
	this.instance_10 = new lib.Символ6копия10();
	this.instance_10.parent = this;
	this.instance_10.setTransform(234.7,235.05,0.2656,0.2511,152.9553,0,0,106.6,-13.8);
	this.instance_10.alpha = 0.6797;
	this.instance_10.filters = [new cjs.BlurFilter(2.4000001, 2.4000001, 3)];
	this.instance_10.cache(66,-57,88,86);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({regX:106.5,regY:-13.6,scaleX:0.2796,scaleY:0.2643,rotation:152.9572,x:235.1,y:227},119).wait(1));

	// bact10
	this.instance_11 = new lib.Символ6копия9();
	this.instance_11.parent = this;
	this.instance_11.setTransform(189.05,296.65,0.5414,0.5119,-102.0013,0,0,106.7,-13.1);
	this.instance_11.alpha = 0.8398;
	this.instance_11.filters = [new cjs.BlurFilter(1.60000002, 1.60000002, 3)];
	this.instance_11.cache(76,-52,70,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({regX:106.8,regY:-13.2,scaleX:0.57,scaleY:0.5388,rotation:-37.9999,x:185.95,y:290.75},119).wait(1));

	// bact9
	this.instance_12 = new lib.Символ6копия8();
	this.instance_12.parent = this;
	this.instance_12.setTransform(202.65,349.85,0.5984,0.5657,-75.008,0,0,106.7,-13.8);
	this.instance_12.filters = [new cjs.BlurFilter(3, 3, 3)];
	this.instance_12.cache(78,-42,57,56);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({regY:-13.9,scaleX:0.63,scaleY:0.5955,rotation:-75.0066,x:201.4,y:347.8},119).wait(1));

	// bact8
	this.instance_13 = new lib.Символ6копия7();
	this.instance_13.parent = this;
	this.instance_13.setTransform(228.8,220.15,0.5509,0.5208,-103.998,0,0,106.7,-14);
	this.instance_13.filters = [new cjs.BlurFilter(3, 3, 3)];
	this.instance_13.cache(78,-42,57,56);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({regX:106.8,scaleX:0.58,scaleY:0.5482,rotation:-90.0207,x:222.6,y:211.3},119).wait(1));

	// bact7
	this.instance_14 = new lib.Символ6копия6();
	this.instance_14.parent = this;
	this.instance_14.setTransform(213.25,178.15,0.6733,0.6364,127.0004,0,0,107,-14.5);
	this.instance_14.filters = [new cjs.BlurFilter(3, 3, 3)];
	this.instance_14.cache(78,-42,57,56);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({regX:106.7,regY:-14.2,scaleX:0.7088,scaleY:0.67,rotation:74.9089,x:205.15,y:167},119).wait(1));

	// bact6
	this.instance_15 = new lib.Символ6копия5();
	this.instance_15.parent = this;
	this.instance_15.setTransform(189.55,10.6,0.6733,0.6364,66.0007,0,0,106.5,-14.3);
	this.instance_15.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_15.cache(78,-42,57,56);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({regX:106.6,regY:-14.1,scaleX:0.7088,scaleY:0.67,rotation:44.9059,x:187.6,y:-9.2},119).wait(1));

	// bact5
	this.instance_16 = new lib.Символ6копия4();
	this.instance_16.parent = this;
	this.instance_16.setTransform(241.85,44.35,0.399,0.3771,180,0,0,106.8,-13.9);
	this.instance_16.alpha = 0.75;
	this.instance_16.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_16.cache(78,-42,57,56);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).to({regY:-13.8,scaleX:0.42,scaleY:0.397,x:242.65,y:26.25},119).wait(1));

	// bact4
	this.instance_17 = new lib.Символ6копия3();
	this.instance_17.parent = this;
	this.instance_17.setTransform(232.65,80.4,0.399,0.3771,-17.9966,0,0,107,-13.8);
	this.instance_17.alpha = 0.75;
	this.instance_17.filters = [new cjs.BlurFilter(3, 3, 3)];
	this.instance_17.cache(78,-42,57,56);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).to({regX:106.8,scaleX:0.42,scaleY:0.397,rotation:0,x:232.95,y:64.2},119).wait(1));

	// bact3
	this.instance_18 = new lib.Символ6копия2();
	this.instance_18.parent = this;
	this.instance_18.setTransform(146.35,44.85,0.834,0.7884,24.9983,0,0,20.9,22.9);
	this.instance_18.alpha = 0.75;
	this.instance_18.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_18.cache(78,-42,57,56);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).to({regX:20.8,scaleX:0.878,scaleY:0.83,rotation:0,x:139,y:26.85},119).wait(1));

	// bact2
	this.instance_19 = new lib.Символ6копия();
	this.instance_19.parent = this;
	this.instance_19.setTransform(203.25,114.7,0.8075,0.7433,170.0005,0,0,20.7,22.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).to({regY:22.7,scaleX:0.85,scaleY:0.7824,rotation:179.001,x:202,y:100.3},119).wait(1));

	// bact1
	this.instance_20 = new lib.Символ6();
	this.instance_20.parent = this;
	this.instance_20.setTransform(212.9,97.05,0.9499,0.9499,32.0003,0,0,20.8,22.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).to({scaleX:1,scaleY:1,rotation:0,x:208.05,y:81.85},119).wait(1));

	// Bact10
	this.instance_21 = new lib.Символ7копия9();
	this.instance_21.parent = this;
	this.instance_21.setTransform(190,331.8,1.0909,1.0909,74.8598,0,0,14.2,20.2);
	this.instance_21.filters = [new cjs.BlurFilter(3, 3, 3)];
	this.instance_21.cache(-2,-2,32,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).to({regX:14.1,regY:20.3,scaleX:1.1483,scaleY:1.1483,rotation:74.8585,x:187.95,y:328.85},119).wait(1));

	// Bact11
	this.instance_22 = new lib.Символ7копия10();
	this.instance_22.parent = this;
	this.instance_22.setTransform(196.75,352,0.9774,0.9774,-68.164,0,0,14.2,20.3);
	this.instance_22.filters = [new cjs.BlurFilter(3, 3, 3)];
	this.instance_22.cache(-2,-2,32,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).to({regY:20.2,scaleX:1.0288,scaleY:1.0288,rotation:-68.1618,x:195.15,y:350.1},119).wait(1));

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7F47D0").s().p("AiVBkIAAjHIErAAIAADHg");
	this.shape.setTransform(219.05,-36);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(119));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(155.4,-46,111.6,437.6);


(lib.Символ43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// virus_10
	this.instance = new lib.Символ15копия9();
	this.instance.parent = this;
	this.instance.setTransform(18.3,20.5,0.4398,0.4398,3.9985,0,0,36.4,37.8);
	this.instance.filters = [new cjs.BlurFilter(6, 6, 3)];
	this.instance.cache(-2,-2,79,77);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:36.3,scaleX:0.4399,scaleY:0.4399,rotation:-4.8038,y:10.5},120).wait(1));

	// virus_9
	this.instance_1 = new lib.Символ15копия8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(15.25,123.25,0.3096,0.3096,-107.9973,0,0,36.4,37.6);
	this.instance_1.filters = [new cjs.BlurFilter(2.5999999, 2.5999999, 3)];
	this.instance_1.cache(-2,-2,79,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({rotation:-64.9671,x:15.3,y:106.25},120).wait(1));

	// virus_8
	this.instance_2 = new lib.Символ15копия7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(44,90.15,0.82,0.82,-66.0011,0,0,36.9,37.6);
	this.instance_2.filters = [new cjs.BlurFilter(1.70000005, 1.70000005, 3)];
	this.instance_2.cache(-2,-2,79,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({rotation:-94.9993,y:84.15},120).wait(1));

	// virus_7
	this.instance_3 = new lib.Символ15копия6();
	this.instance_3.parent = this;
	this.instance_3.setTransform(48.55,185.65,0.1698,0.1698,-64.0037,0,0,37,37.6);
	this.instance_3.filters = [new cjs.BlurFilter(1.60000002, 1.60000002, 3)];
	this.instance_3.cache(-2,-2,79,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:37.1,regY:37.5,scaleX:0.1699,scaleY:0.1699,rotation:-75.4631,y:172.65},120).wait(1));

	// virus_6
	this.instance_4 = new lib.Символ15копия5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(30.55,226.15,0.5192,0.5192,-89.9916,0,0,37.1,37.2);
	this.instance_4.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_4.cache(-2,-2,79,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regY:37.3,rotation:-75.4075,x:30.6,y:209.2},120).wait(1));

	// virus_5
	this.instance_5 = new lib.Символ15копия4();
	this.instance_5.parent = this;
	this.instance_5.setTransform(4.05,182.65,0.7493,0.7493,-73.0012,0,0,37.1,37.1);
	this.instance_5.filters = [new cjs.BlurFilter(4, 4, 3)];
	this.instance_5.cache(-2,-2,79,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regX:37.2,regY:37.2,rotation:-60.3189,x:6,y:165.65},120).wait(1));

	// virus_4
	this.instance_6 = new lib.Символ15копия3();
	this.instance_6.parent = this;
	this.instance_6.setTransform(61.05,252.7,0.3596,0.3596,11.9993,0,0,37.5,37.2);
	this.instance_6.filters = [new cjs.BlurFilter(4, 4, 3)];
	this.instance_6.cache(-2,-2,79,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({regY:37.1,scaleX:0.3597,scaleY:0.3597,rotation:-14.8091,x:62.05,y:234.7},120).wait(1));

	// virus_3
	this.instance_7 = new lib.Символ15копия2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(40.55,272.75,0.1996,0.1996,-50.9996,0,0,37.1,36.6);
	this.instance_7.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_7.cache(-2,-2,79,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({regX:37.2,regY:36.9,scaleX:0.1997,scaleY:0.1997,rotation:-59.9418,x:42.55,y:259.75},120).wait(1));

	// virus_2
	this.instance_8 = new lib.Символ15копия();
	this.instance_8.parent = this;
	this.instance_8.setTransform(3.05,353,0.6191,0.6191,-78.0001,0,0,37.1,36.7);
	this.instance_8.filters = [new cjs.BlurFilter(4, 4, 3)];
	this.instance_8.cache(-2,-2,79,77);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({regY:36.6,rotation:-59.953,x:4,y:342},120).wait(1));

	// virus_1
	this.instance_9 = new lib.Символ15();
	this.instance_9.parent = this;
	this.instance_9.setTransform(-2.55,289.55,1,1,45.0006,0,0,37.2,36.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({regY:36.5,rotation:0,x:-0.55,y:279.5},120).wait(1));

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#009900").s().p("AiLBpIAAjRIEXAAIAADRg");
	this.shape.setTransform(14,-37.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(120));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.5,-48,153.1,448.7);


(lib.Символ35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AqkHRQgMADgEgVIABufQgFgZAdABIB5gKITHATQANACAAAKIADPEQgBAEgHAFIhqAZg");
	mask.setTransform(70.8,53.725);

	// Слой_1
	this.instance = new lib._5();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Слой_4
	this.instance_1 = new lib.Символ38копия();
	this.instance_1.parent = this;
	this.instance_1.setTransform(65.85,101.6,0.9569,0.9998,2.262,0,0,67.2,2.2);
	this.instance_1.alpha = 0.1992;
	this.instance_1.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_1.cache(-2,-2,138,8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Слой_3
	this.instance_2 = new lib.Символ37();
	this.instance_2.parent = this;
	this.instance_2.setTransform(79.05,99.95,1,0.7903,0,0,0,75,7.8);
	this.instance_2.alpha = 0.1289;
	this.instance_2.filters = [new cjs.BlurFilter(2.5999999, 2.5999999, 3)];
	this.instance_2.cache(-2,-2,161,21);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ35, new cjs.Rectangle(-1.4,2.3,170.5,112.5), null);


(lib.Символ28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AqRH2IgfgRQgHgEgDgMIgGu0QABgOAWAAIT+gNQAQgCAPAEIBAAJQANAFgBAPIAAOvQgDALgOABI0pAbIgCAAQgMAAgJgFg");
	mask.setTransform(73.3503,53.8708);

	// Слой_1
	this.instance = new lib.Растровоеизображение221();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Слой_4
	this.instance_1 = new lib.Символ38();
	this.instance_1.parent = this;
	this.instance_1.setTransform(76.3,102.25,0.9999,0.9999,-1.2872,0,0,67.2,2.1);
	this.instance_1.alpha = 0.1992;
	this.instance_1.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance_1.cache(-2,-2,138,8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Слой_3
	this.instance_2 = new lib.Символ37копия();
	this.instance_2.parent = this;
	this.instance_2.setTransform(71.05,101.45,1,0.7903,0,0,180,75,7.8);
	this.instance_2.alpha = 0.1992;
	this.instance_2.filters = [new cjs.BlurFilter(2.5999999, 2.5999999, 3)];
	this.instance_2.cache(-2,-2,161,19);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ28, new cjs.Rectangle(-15.1,3.2,169,112.1), null);


(lib.Символ25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgsBwQgOgQAAgeIAAgWIAlAAIAAAYQAAAOAFAFQAHAGAJAAQAIAAAFgGQAGgGAAgQIAAgVQAAgRgGgHQgGgHgNAAIgNAAIAAgjIAPAAQAKgBAHgFQAGgGAAgPIAAgOQAAgRgGgGQgFgGgIAAQgJAAgHAGQgFAFAAAOIAAAQIglAAIAAgOQAAgeAOgRQAPgQAdAAQAdAAAPAQQAPARAAAeIAAAHQAAAogcAMQAPAGAHANQAGANAAAUIAAAUQAAAegPAQQgPARgdAAQgdAAgPgRg");
	this.shape.setTransform(22.9,5.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Слой_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAAAFIgIARIgIgGIANgOIgTgDIADgJIASAJIgDgUIAJAAIgDAUIASgJIADAJIgTADIAOAOIgJAGg");
	this.shape_1.setTransform(74.375,3.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAQBDIgEgZIgZAAIgEAZIgSAAIAUiFIAfAAIAVCFgAAJAYIgJhCIgKBCIATAAg");
	this.shape_2.setTransform(68.35,10.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgWA7QgIgIAAgRIAAgQIAUAAIAAASQAAAHADADQADADAEAAQAEAAADgDQADgDAAgJIAAgLQAAgJgDgDQgDgFgGAAIgEAAIAAgSIAFAAQAFAAADgCQADgDAAgIIAAgIQAAgJgDgDQgDgDgEAAQgEAAgDADQgDADAAAHIAAAOIgUAAIAAgMQAAgRAIgIQAIgJAOAAQAPAAAIAJQAIAIAAARIAAADQAAAVgOAGQAIADADAHQADAHAAAKIAAAKQAAARgIAIQgIAJgPAAQgOAAgIgJg");
	this.shape_3.setTransform(59.025,10.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAPBDIgDgZIgZAAIgEAZIgTAAIAWiFIAdAAIAVCFgAAJAYIgJhCIgKBCIATAAg");
	this.shape_4.setTransform(49.75,10.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgeBDIAAiFIAeAAQAPAAAJAJQAHAJAAAQIAAARQAAAPgHAIQgJAJgPgBIgJAAIAAAzgAgJgCIAJAAQAFABACgDQADgDAAgHIAAgUQAAgHgDgDQgCgCgFgBIgJAAg");
	this.shape_5.setTransform(40.85,10.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgfBDIAAiFIAfAAQAQABAHAHQAHAIAAAPIAAAFQAAAKgDAHQgDAHgHACQAIAEAEAGQADAHAAALIAAALQAAAPgIAIQgIAJgPAAgAgKAwIALAAQAFAAADgEQADgCAAgIIAAgLQAAgKgEgDQgDgDgGgBIgJAAgAgKgMIAIAAQAFAAADgCQADgDAAgIIAAgIQAAgHgCgDQgDgEgEAAIgKAAg");
	this.shape_6.setTransform(5.725,10.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Слой_3___копия
	this.instance = new lib.Символ26();
	this.instance.parent = this;
	this.instance.setTransform(23.85,10.5,1,1,0,0,0,10.1,20);
	this.instance.alpha = 0.8906;
	this.instance.filters = [new cjs.BlurFilter(1.5, 1.5, 3)];
	this.instance.cache(-2,-2,24,44);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Слой_1___копия
	this.instance_1 = new lib.Символ27();
	this.instance_1.parent = this;
	this.instance_1.setTransform(39.45,13,1,1,0,0,0,39.7,12);
	this.instance_1.alpha = 0.8906;
	this.instance_1.filters = [new cjs.BlurFilter(1.5, 1.5, 3)];
	this.instance_1.cache(-2,-2,84,28);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ25, new cjs.Rectangle(-2.2,-11.5,87,47), null);


(lib.Символ24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AANA7IAAhNIgKAeIgOAvIgLAAIAAhhIAJAAIAABIIAKgcIAOgsIAMAAIAABhgAgOg6IAHAAQABAHAHAAQAHAAABgHIAHAAQAAAGgEAEQgEADgHAAQgOAAgBgNg");
	this.shape.setTransform(76.725,6.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AANAxIAAhNIgKAgIgOAtIgLAAIAAhhIAJAAIAABIIALgeIANgqIAMAAIAABhg");
	this.shape_1.setTransform(68.925,7.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAMAxIAAgsIgXAAIAAAsIgLAAIAAhhIALAAIAAAsIAXAAIAAgsIALAAIAABhg");
	this.shape_2.setTransform(61.1,7.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgTAxIAAhhIAnAAIAAAKIgcAAIAAAiIAXAAIAAAIIgXAAIAAAjIAcAAIAAAKg");
	this.shape_3.setTransform(53.725,7.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAMAxIAAgsIgXAAIAAAsIgLAAIAAhhIALAAIAAAsIAXAAIAAgsIALAAIAABhg");
	this.shape_4.setTransform(46.2,7.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAeAxIgTguIgGAJIAAAlIgJAAIAAglIgGgKIgTAvIgLAAIAXg4IgWgpIALAAIAYAtIAAgtIAJAAIAAAtIAYgtIALAAIgWApIAWA4g");
	this.shape_5.setTransform(37,7.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQArQgFgGAAgMIAAgyQAAgLAFgHQAGgGAKAAQALAAAGAGQAFAHAAALIAAAyQAAAMgFAGQgGAHgLAAQgKAAgGgHgAgLgZIAAAzQAAAOALAAQAMAAAAgOIAAgzQAAgOgMAAQgLAAAAAOg");
	this.shape_6.setTransform(27.925,7.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAQAxIAAhXIgSAAIgCA/QAAAMgEAGQgFAGgLAAIgCAAIAAgKQAHAAACgEQACgCAAgIIADhJIAnAAIAABhg");
	this.shape_7.setTransform(19.825,7.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgQArQgFgGAAgMIAAgyQAAgLAFgGQAGgHAKAAQAKAAAHAHQAFAGAAALIAAAJIgLAAIAAgJQAAgOgLAAQgKAAAAAOIAAAzQAAAOAKAAQALAAAAgOIAAgNIALAAIAAAMQAAAMgFAGQgHAHgKAAQgKAAgGgHg");
	this.shape_8.setTransform(12.2,7.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQArQgFgGAAgMIAAgyQAAgLAFgHQAGgGAKAAQALAAAGAGQAFAHAAALIAAAyQAAAMgFAGQgGAHgLAAQgKAAgGgHgAgLgZIAAAzQAAAOALAAQAMAAAAgOIAAgzQAAgOgMAAQgLAAAAAOg");
	this.shape_9.setTransform(4.725,7.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_1___копия
	this.instance = new lib.Символ29();
	this.instance.parent = this;
	this.instance.setTransform(41.9,10,1,1,0,0,0,41.9,9);
	this.instance.filters = [new cjs.BlurFilter(1.5, 1.5, 3)];
	this.instance.cache(-2,-2,88,22);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ24, new cjs.Rectangle(-2,-1,91,26), null);


(lib.Символ23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAdB7IgHgtIguAAIgHAtIgjAAIAmj0IA4AAIAoD0gAAQAsIgRh6IgTB6IAkAAg");
	this.shape.setTransform(73.25,16);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAYB7IgkhiIgMAXIAABLIgnAAIAAj0IAnAAIAABqIAyhqIAmAAIg2BtIA2CHg");
	this.shape_1.setTransform(57.475,16);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgqBuQgPgQAAgeIAAh/QAAgdAPgQQAOgQAcAAQAcAAAOAQQAPAQABAdIAAAYIglAAIAAgaQAAgNgGgGQgFgFgJAAQgIAAgGAFQgFAGAAANIAACDQAAAOAFAFQAGAFAIAAQAJAAAFgFQAGgFAAgOIAAgjIAlAAIAAAhQgBAegPAQQgOAPgcAAQgcAAgOgPg");
	this.shape_2.setTransform(40.95,15.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAaB7IAAixIguCxIgoAAIAAj0IAiAAIAACRIAniRIAwAAIAAD0g");
	this.shape_3.setTransform(24.65,16);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag4B7IAAj0IA4AAQAdAAAOAPQAOAQAAAdIAAAgQAAAdgOAPQgOAQgdAAIgRAAIAABcgAgRgDIARAAQAJAAAFgGQAFgEAAgOIAAglQAAgNgFgFQgFgEgJAAIgRAAg");
	this.shape_4.setTransform(9.1,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_1___копия
	this.instance = new lib.Символ31();
	this.instance.parent = this;
	this.instance.setTransform(42.2,20.75,1,1,0,0,0,42.2,19.5);
	this.instance.alpha = 0.8906;
	this.instance.filters = [new cjs.BlurFilter(1.5, 1.5, 3)];
	this.instance.cache(-2,-2,89,43);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ23, new cjs.Rectangle(-2,-0.7,92,46), null);


(lib.Символ22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AghBQIAAigIBDAAIAAAYIgqAAIAAAtIAhAAIAAAVIghAAIAAAwIAqAAIAAAWg");
	this.shape.setTransform(76.15,10.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AARBQIAAhzIgeBzIgaAAIAAigIAXAAIAABgIAYhgIAgAAIAACgg");
	this.shape_1.setTransform(67.075,10.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAOBQIAAhFIgcAAIAABFIgZAAIAAigIAZAAIAABGIAcAAIAAhGIAaAAIAACgg");
	this.shape_2.setTransform(57.45,10.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgiBQIAAigIBFAAIAAAYIgrAAIAAAtIAhAAIAAAVIghAAIAAAwIArAAIAAAWg");
	this.shape_3.setTransform(48.75,10.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAtBQIgYhAIgIAPIAAAxIgZAAIAAgxIgHgPIgZBAIgaAAIAjhYIgjhIIAZAAIAhBGIAAhGIAZAAIAABGIAihGIAYAAIgjBIIAjBYg");
	this.shape_4.setTransform(37.25,10.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AARBQIAAhzIgeBzIgaAAIAAigIAXAAIAABgIAYhgIAgAAIAACgg");
	this.shape_5.setTransform(25.225,10.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAOBQIAAhFIgcAAIAABFIgZAAIAAigIAZAAIAABGIAcAAIAAhGIAaAAIAACgg");
	this.shape_6.setTransform(15.6,10.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgbBIQgKgKAAgUIAAhTQAAgUAKgKQAJgLASABQASgBAKALQAKAKAAAUIAAAQIgYAAIAAgSQAAgIgEgDQgDgEgGAAQgFAAgEAEQgEADAAAIIAABXQAAAIAEADQAEAEAFAAQAGAAADgEQAEgDAAgIIAAgYIAYAAIAAAWQAAAUgKAKQgKAKgSAAQgSAAgJgKg");
	this.shape_7.setTransform(6.475,10.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_1___копия
	this.instance = new lib.Символ30();
	this.instance.parent = this;
	this.instance.setTransform(41.1,14.5,1,1,0,0,0,41.1,13.5);
	this.instance.alpha = 0.8906;
	this.instance.filters = [new cjs.BlurFilter(1.5, 1.5, 3)];
	this.instance.cache(-2,-2,86,31);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ22, new cjs.Rectangle(-2,-1,90,35), null);


(lib.Символ19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ42();
	this.instance.parent = this;
	this.instance.setTransform(34.2,26.2,1,1,0,0,0,34.2,26.2);
	this.instance.alpha = 0;
	this.instance.filters = [new cjs.BlurFilter(6, 6, 3)];
	this.instance.cache(-2,-2,73,56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.0042},0).wait(1).to({alpha:0.0124},0).wait(1).to({alpha:0.0249},0).wait(1).to({alpha:0.042},0).wait(1).to({alpha:0.064},0).wait(1).to({alpha:0.0913},0).wait(1).to({alpha:0.1242},0).wait(1).to({alpha:0.1629},0).wait(1).to({alpha:0.2073},0).wait(1).to({alpha:0.2574},0).wait(1).to({alpha:0.3127},0).wait(1).to({alpha:0.3723},0).wait(1).to({alpha:0.4352},0).wait(1).to({alpha:0.4999},0).wait(1).to({alpha:0.5648},0).wait(1).to({alpha:0.6283},0).wait(1).to({alpha:0.6889},0).wait(1).to({alpha:0.7456},0).wait(1).to({alpha:0.7976},0).wait(1).to({alpha:0.8444},0).wait(1).to({alpha:0.8859},0).wait(1).to({alpha:0.9219},0).wait(1).to({alpha:0.9528},0).wait(1).to({alpha:0.9788},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.9416},0).wait(1).to({alpha:0.885},0).wait(1).to({alpha:0.8302},0).wait(1).to({alpha:0.7772},0).wait(1).to({alpha:0.726},0).wait(1).to({alpha:0.6765},0).wait(1).to({alpha:0.6288},0).wait(1).to({alpha:0.5828},0).wait(1).to({alpha:0.5386},0).wait(1).to({alpha:0.496},0).wait(1).to({alpha:0.4551},0).wait(1).to({alpha:0.4158},0).wait(1).to({alpha:0.3782},0).wait(1).to({alpha:0.3422},0).wait(1).to({alpha:0.3079},0).wait(1).to({alpha:0.2751},0).wait(1).to({alpha:0.2439},0).wait(1).to({alpha:0.2142},0).wait(1).to({alpha:0.1861},0).wait(1).to({alpha:0.1595},0).wait(1).to({alpha:0.1344},0).wait(1).to({alpha:0.1109},0).wait(1).to({alpha:0.0888},0).wait(1).to({alpha:0.0682},0).wait(1).to({alpha:0.049},0).wait(1).to({alpha:0.0312},0).wait(1).to({alpha:0.0149},0).wait(1).to({alpha:0},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16,-16,108,92);


(lib.Символ14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAPA/IAAg2IgJAAQgSAAAAATIAAATQAAALgCAFIgOAAQACgFAAgKIAAgTQAAgWAQgFQgQgEAAgVIAAgKQAAgdAbAAIAcAAIAAB9gAgMggIAAAMQAAAKAFAEQAEAEAIgBIAKAAIAAguIgNAAQgOAAAAARg");
	this.shape.setTransform(79.075,9.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AARA/IAAhjIgNAoIgSA7IgPAAIAAh9IANAAIAABdIANgnIARg2IAQAAIAAB9g");
	this.shape_1.setTransform(71.375,9.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAPA/IAAg5IgdAAIAAA5IgPAAIAAh9IAPAAIAAA5IAdAAIAAg5IAPAAIAAB9g");
	this.shape_2.setTransform(63.475,9.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZA/IAAh9IAzAAIAAANIglAAIAAArIAeAAIAAALIgeAAIAAAtIAlAAIAAANg");
	this.shape_3.setTransform(56.05,9.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAPA/IAAg5IgdAAIAAA5IgPAAIAAh9IAPAAIAAA5IAdAAIAAg5IAPAAIAAB9g");
	this.shape_4.setTransform(48.525,9.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAmA/IgZg8IgHAMIAAAwIgMAAIAAgwIgHgMIgYA8IgOAAIAdhHIgcg2IANAAIAfA6IAAg6IAMAAIAAA6IAfg6IAOAAIgcA1IAdBIg");
	this.shape_5.setTransform(38.8,9.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgUA4QgIgIAAgPIAAhAQAAgPAIgIQAHgJANAAQAOAAAIAJQAHAIAAAPIAABAQAAAPgHAIQgIAIgOAAQgNAAgHgIgAgOggIAABCQAAASAOAAQAPAAAAgSIAAhCQAAgSgPAAQgOAAAAASg");
	this.shape_6.setTransform(29.15,9.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAUA/IAAhwIgXAAIgDBQQAAAQgFAIQgGAIgOAAIgCAAIAAgNQAIABADgFQACgDABgLIADheIAyAAIAAB9g");
	this.shape_7.setTransform(20.875,9.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgVA4QgGgIgBgPIAAhAQABgPAGgIQAIgJANAAQAOAAAIAJQAHAIAAAPIAAALIgOAAIAAgMQAAgSgPAAQgNAAgBASIAABCQABASANAAQAPAAAAgSIAAgRIAOAAIAAAQQAAAPgHAIQgIAIgOAAQgNAAgIgIg");
	this.shape_8.setTransform(13.15,9.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgVA4QgHgIAAgPIAAhAQAAgPAHgIQAIgJANAAQAOAAAHAJQAIAIAAAPIAABAQAAAPgIAIQgHAIgOAAQgNAAgIgIgAgOggIAABCQAAASAOAAQAPAAAAgSIAAhCQAAgSgPAAQgOAAAAASg");
	this.shape_9.setTransform(5.6,9.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_1___копия
	this.instance = new lib.Символ48();
	this.instance.parent = this;
	this.instance.setTransform(42.7,11,1,1,0,0,0,42.7,11);
	this.instance.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance.cache(-2,-2,89,26);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ14, new cjs.Rectangle(-3,-3,95,32), null);


(lib.Символ13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AARA/IAAhjIgNAoIgSA7IgPAAIAAh9IANAAIAABdIANgnIARg2IAQAAIAAB9g");
	this.shape.setTransform(57.025,9.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AARA/IAAhjIgNAoIgSA7IgPAAIAAh9IANAAIAABdIANgnIARg2IAQAAIAAB9g");
	this.shape_1.setTransform(49.375,9.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbA/IAAh9IAbAAQAcAAAAAfIAAAPQAAAegcgBIgNAAIAAAygAgNABIANAAQAOAAAAgQIAAgRQAAgRgOAAIgNAAg");
	this.shape_2.setTransform(42.25,9.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZA/IAAh9IAzAAIAAANIglAAIAAArIAeAAIAAALIgeAAIAAAtIAlAAIAAANg");
	this.shape_3.setTransform(35.3,9.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGA/IAAhwIgXAAIAAgNIA7AAIAAANIgXAAIAABwg");
	this.shape_4.setTransform(28.4,9.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AARA/Igag3IgHANIAAAqIgPAAIAAh9IAPAAIAAA9IAgg9IAOAAIgfA5IAgBEg");
	this.shape_5.setTransform(21.25,9.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUA/IgEgZIgfAAIgFAZIgNAAIAYh9IATAAIAYB9gAAOAaIgOhIIgOBIIAcAAg");
	this.shape_6.setTransform(13.325,9.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcA/IAAh9IA0AAIAAANIgmAAIAAAnIAOAAQAdAAAAAdIAAANQAAAfgdAAgAgOAyIAOAAQAPABAAgSIAAgPQAAgJgEgEQgEgDgHAAIgOAAg");
	this.shape_7.setTransform(5.7,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_1___копия
	this.instance = new lib.Символ47();
	this.instance.parent = this;
	this.instance.setTransform(31.6,11,1,1,0,0,0,31.6,11);
	this.instance.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance.cache(-2,-2,67,26);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ13, new cjs.Rectangle(-3,-3,73,32), null);


(lib.Символ12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAbA/IAAh9IAOAAIAAB9gAgoA/IAAh9IAPAAIAAAyIAMAAQAcgBAAAeIAAAPQAAAfgbAAgAgZAzIANAAQANAAAAgSIAAgRQAAgQgOAAIgMAAg");
	this.shape.setTransform(46.725,9.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgVA4QgHgIAAgPIAAhAQAAgPAHgIQAIgJANAAQAOAAAIAJQAGAIABAPIAAALIgOAAIAAgMQAAgSgPAAQgNAAAAASIAABCQAAASANAAQAPAAAAgSIAAgRIAOAAIAAAQQgBAPgGAIQgIAIgOAAQgNAAgIgIg");
	this.shape_1.setTransform(37.7,9.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZA/IAAgNQAIABAEgDQAEgDACgHIADgIIgdhcIAOAAIAMArIAIAfIAHgfIAMgrIAOAAIgbBhQgDAPgGAHQgGAGgNAAIgEAAg");
	this.shape_2.setTransform(29.625,9.1563);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbA/IAAh9IAbAAQAcAAAAAfIAAAPQAAAegcAAIgNAAIAAAxgAgNAAIANAAQAOAAAAgPIAAgRQAAgRgOAAIgNAAg");
	this.shape_3.setTransform(21.8,9.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AARA/IAAhjIgNApIgSA6IgPAAIAAh9IANAAIAABdIANgnIARg2IAQAAIAAB9g");
	this.shape_4.setTransform(13.725,9.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcA/IAAh9IAcAAQAOAAAGAHQAHAHAAAOIAAAGQAAAVgPAEQARAEAAAWIAAALQAAAdgdAAgAgOAzIAOAAQAPAAAAgSIAAgLQAAgLgEgEQgFgEgHAAIgNAAgAgOgJIALAAQAIAAAEgDQAEgEAAgKIAAgHQAAgQgNAAIgOAAg");
	this.shape_5.setTransform(5.7,9.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_1___копия
	this.instance = new lib.Символ45();
	this.instance.parent = this;
	this.instance.setTransform(27.2,11,1,1,0,0,0,27.2,11);
	this.instance.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance.cache(-2,-2,59,26);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ12, new cjs.Rectangle(-3,-3,64,32), null);


(lib.Символ11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAUA/IgEgaIgfAAIgFAaIgNAAIAYh9IATAAIAYB9gAAOAZIgOhHIgOBHIAcAAg");
	this.shape.setTransform(60.725,9.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAaBIIAAgSIgzAAIAAASIgNAAIAAgeIAIAAQAFgGAAgNIAFheIAyAAIAABxIAJAAIAAAegAgLAXQgBAOgFAFIAgAAIAAhkIgWAAg");
	this.shape_1.setTransform(51.925,10.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZA/IAAgNQAIABAEgDQAEgDACgHIADgIIgdhcIAOAAIAMArIAIAfIAHgfIAMgrIAOAAIgbBhQgDAPgGAHQgGAGgNAAIgEAAg");
	this.shape_2.setTransform(43.225,9.1563);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgGA/IAAhwIgXAAIAAgNIA7AAIAAANIgXAAIAABwg");
	this.shape_3.setTransform(35.55,9.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgUA4QgIgIAAgPIAAhAQAAgPAIgIQAHgJANAAQAOAAAIAJQAGAIABAPIAAALIgOAAIAAgMQAAgSgPAAQgNAAAAASIAABCQAAASANAAQAPAAAAgSIAAgRIAOAAIAAAQQgBAPgGAIQgIAIgOAAQgNAAgHgIg");
	this.shape_4.setTransform(28.25,9.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgVA4QgHgIAAgPIAAhAQAAgPAHgIQAIgJANAAQAOAAAIAJQAHAIAAAPIAABAQAAAPgHAIQgIAIgOAAQgNAAgIgIgAgOggIAABCQAAASAOAAQAPAAAAgSIAAhCQAAgSgPAAQgOAAAAASg");
	this.shape_5.setTransform(20.7,9.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgbA/IAAh9IAbAAQAcAAAAAfIAAAPQAAAegcAAIgNAAIAAAxgAgNAAIANAAQAOAAAAgPIAAgRQAAgRgOAAIgNAAg");
	this.shape_6.setTransform(13.45,9.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAPA/IAAhwIgdAAIAABwIgPAAIAAh9IA7AAIAAB9g");
	this.shape_7.setTransform(5.725,9.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Слой_1___копия
	this.instance = new lib.Символ46();
	this.instance.parent = this;
	this.instance.setTransform(33.6,11,1,1,0,0,0,33.6,11);
	this.instance.filters = [new cjs.BlurFilter(2, 2, 3)];
	this.instance.cache(-2,-2,71,26);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ11, new cjs.Rectangle(-3,-3,77,32), null);


(lib.Символ10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_4
	this.instance = new lib.Символ16();
	this.instance.parent = this;
	this.instance.setTransform(200.45,81.05,2.1366,1,-29.9984,0,0,33.5,33.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Слой_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ay6FwIAArPQTSFoSjl4IAALfg");
	mask.setTransform(120.375,39);

	// Слой_1
	this.instance_1 = new lib._2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1,0,0.5,0.5);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Слой_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#013764").s().p("Ax8RMQgzAAAAgzMAAAggyQAAgyAzAAMAj5AAAQAzAAAAAyMAAAAgyQAAAzgzAAg");
	this.shape.setTransform(121,177.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ10, new cjs.Rectangle(1,2.3,277.7,284.8), null);


(lib.Символ9копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#780713","rgba(120,7,19,0)"],[0.145,1],0,0,0,0,0,4.4).s().p("AgeAeQgMgMAAgSQAAgRAMgNQANgMARAAQASAAAMAMQANANAAARQAAASgNAMQgMANgSAAQgRAAgNgNg");
	this.shape.setTransform(4.325,4.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Слой_17___копия
	this.instance = new lib.Символ8();
	this.instance.parent = this;
	this.instance.setTransform(4.5,3.65,0.9801,1.1302,-135.9999,0,0,1.8,20.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Слой_17
	this.instance_1 = new lib.Символ8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(4.3,3.85,0.9801,1.1303,136.0004,0,0,1.8,20.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ9копия, new cjs.Rectangle(-13.2,-14.4,35.3,36.3), null);


(lib.Символ9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#780713","rgba(120,7,19,0)"],[0.145,1],0,0,0,0,0,4.4).s().p("AgeAeQgMgMAAgSQAAgRAMgNQANgMARAAQASAAAMAMQANANAAARQAAASgNAMQgMANgSAAQgRAAgNgNg");
	this.shape.setTransform(4.325,4.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Слой_17___копия
	this.instance = new lib.Символ8();
	this.instance.parent = this;
	this.instance.setTransform(4.5,3.65,0.9801,1.1302,-135.9999,0,0,1.8,20.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Слой_17
	this.instance_1 = new lib.Символ8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(4.3,3.85,0.9801,1.1303,136.0004,0,0,1.8,20.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ9, new cjs.Rectangle(-13.2,-14.4,35.3,36.3), null);


// stage content:
(lib._240x400 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// rectangle
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("Ayv/PMAlfAAAMAAAA+fMglfAAAg");
	this.shape.setTransform(120,200);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(390));

	// white
	this.instance = new lib.Символ1();
	this.instance.parent = this;
	this.instance.setTransform(120,200,1,1,0,0,0,120,200);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0},14,cjs.Ease.quadInOut).wait(177).to({alpha:1},15,cjs.Ease.quadInOut).to({alpha:0},14,cjs.Ease.quadInOut).wait(74).to({alpha:1},15,cjs.Ease.quadInOut).to({alpha:0},10,cjs.Ease.quadInOut).wait(57).to({alpha:1},13,cjs.Ease.cubicInOut).wait(1));

	// disc__2
	this.instance_1 = new lib.Символ2копия();
	this.instance_1.parent = this;
	this.instance_1.setTransform(119.7,384.4,1,1,0,0,0,112.2,11);
	this.instance_1.alpha = 0.8008;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(206).to({_off:false},0).to({_off:true},103).wait(81));

	// disc
	this.instance_2 = new lib.Символ2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(119.7,384.4,1,1,0,0,0,112.2,11);
	this.instance_2.alpha = 0.5391;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},206).wait(184));

	// SANDOZ
	this.instance_3 = new lib.Символ39();
	this.instance_3.parent = this;
	this.instance_3.setTransform(120.5,189.5,1,1,0,0,0,100.5,18.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(309).to({_off:false},0).wait(81));

	// _2_otprost
	this.instance_4 = new lib.Символ18();
	this.instance_4.parent = this;
	this.instance_4.setTransform(120.7,468.35,1,1,0,0,0,89.7,10.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(35).to({_off:false},0).to({y:351.35,alpha:1},16,cjs.Ease.cubicOut).wait(48).to({y:302.35},23,cjs.Ease.cubicInOut).wait(63).to({y:275.35},20,cjs.Ease.cubicIn).wait(2).to({y:108.35},0).to({y:51.35},18,cjs.Ease.cubicOut).to({_off:true},83).wait(82));

	// _2_protivvirusov
	this.instance_5 = new lib.Символ17();
	this.instance_5.parent = this;
	this.instance_5.setTransform(120.85,451.15,1,1,0,0,0,101.8,12);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(33).to({_off:false},0).to({y:335.15,alpha:1},16,cjs.Ease.cubicOut).wait(48).to({y:286.15},23,cjs.Ease.cubicInOut).wait(63).to({y:259.15},20,cjs.Ease.cubicIn).wait(1).to({y:89.15},0).to({y:32.15},18,cjs.Ease.cubicOut).to({_off:true},86).wait(82));

	// txt_3
	this.instance_6 = new lib.Символ20();
	this.instance_6.parent = this;
	this.instance_6.setTransform(119.7,354.4,1,1,0,0,0,114,14.2);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(113).to({_off:false},0).to({alpha:1},20,cjs.Ease.quadOut).wait(55).to({regX:113.9,regY:14.8,x:119.6,y:354.85},0).wait(1).to({y:354.7},0).wait(1).to({y:354.55},0).wait(1).to({y:354.4},0).wait(1).to({y:354.15},0).wait(1).to({y:353.85},0).wait(1).to({y:353.55},0).wait(1).to({y:353.1},0).wait(1).to({y:352.6},0).wait(1).to({y:351.95},0).wait(1).to({y:351.1},0).wait(1).to({y:350.1},0).wait(1).to({y:348.9},0).wait(1).to({y:347.45},0).wait(1).to({y:345.7},0).wait(1).to({y:343.75},0).wait(1).to({y:341.55},0).wait(1).to({regX:114,regY:14.2,x:119.7,y:338.6},0).to({_off:true},1).wait(184));

	// _3_grad
	this.instance_7 = new lib.Символ21();
	this.instance_7.parent = this;
	this.instance_7.setTransform(120.4,357.5,1,1,0,0,0,119.7,44.6);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(97).to({_off:false},0).to({alpha:1},20,cjs.Ease.cubicInOut).wait(68).to({y:330.5},20,cjs.Ease.cubicIn).to({_off:true},1).wait(184));

	// bluegrad1
	this.instance_8 = new lib.Символ40();
	this.instance_8.parent = this;
	this.instance_8.setTransform(24,17,1,1,0,0,0,24,17);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(39).to({_off:true},78).wait(273));

	// bottom_wave
	this.instance_9 = new lib.Символ10();
	this.instance_9.parent = this;
	this.instance_9.setTransform(118.75,443.75,1,1,0,0,0,120,38.8);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(31).to({_off:false},0).to({y:327.75},16,cjs.Ease.cubicOut).wait(47).to({y:270.75},23,cjs.Ease.cubicInOut).wait(64).to({y:243.75},20,cjs.Ease.cubicIn).to({_off:true},5).wait(184));

	// white___копия
	this.instance_10 = new lib.Символ1копия();
	this.instance_10.parent = this;
	this.instance_10.setTransform(120,200,1,1,0,0,0,120,200);
	this.instance_10.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(101).to({alpha:1},15,cjs.Ease.quadInOut).to({alpha:0},14,cjs.Ease.quadInOut).to({_off:true},1).wait(259));

	// oslojnenia
	this.instance_11 = new lib.Символ14();
	this.instance_11.parent = this;
	this.instance_11.setTransform(308.6,133,1,1,0,0,0,42.7,11);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(1).to({_off:false},0).to({x:191.6,alpha:1},16,cjs.Ease.cubicOut).wait(82).to({y:99},16,cjs.Ease.cubicIn).to({_off:true},1).wait(274));

	// bacterii
	this.instance_12 = new lib.Символ13();
	this.instance_12.parent = this;
	this.instance_12.setTransform(318.65,42,1,1,0,0,0,31.6,11);
	this.instance_12.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({x:199.65,alpha:1},16,cjs.Ease.cubicOut).wait(83).to({y:8},16,cjs.Ease.cubicIn).to({_off:true},1).wait(274));

	// prostuda
	this.instance_13 = new lib.Символ11();
	this.instance_13.parent = this;
	this.instance_13.setTransform(-73.25,132.65,1,1,0,0,0,33.6,11);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(1).to({_off:false},0).to({x:43.75,alpha:1},16,cjs.Ease.cubicOut).wait(82).to({y:98.65},16,cjs.Ease.cubicIn).to({_off:true},1).wait(274));

	// virus
	this.instance_14 = new lib.Символ12();
	this.instance_14.parent = this;
	this.instance_14.setTransform(-79.45,41.8,1,1,0,0,0,27.2,11);
	this.instance_14.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({x:40.55,alpha:1},16,cjs.Ease.cubicOut).wait(83).to({y:7.8},16,cjs.Ease.cubicIn).to({_off:true},1).wait(274));

	// reg_ud
	this.instance_15 = new lib.Символ34();
	this.instance_15.parent = this;
	this.instance_15.setTransform(90,358.9,1,1,0,0,0,83.5,5.9);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(213).to({_off:false},0).to({alpha:1},21,cjs.Ease.cubicOut).to({_off:true},73).wait(83));

	// RU190
	this.instance_16 = new lib.Символ33();
	this.instance_16.parent = this;
	this.instance_16.setTransform(112.1,325,1,1,0,0,0,105.6,20.7);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(212).to({_off:false},0).to({alpha:1},21,cjs.Ease.cubicOut).to({_off:true},74).wait(83));

	// _3_raza
	this.instance_17 = new lib.Символ25();
	this.instance_17.parent = this;
	this.instance_17.setTransform(145.15,150.25,1,1,0,0,0,8.9,11);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(122).to({_off:false},0).to({y:117.25,alpha:1},17,cjs.Ease.cubicOut).wait(49).to({y:99.25},18,cjs.Ease.cubicIn).to({_off:true},1).wait(183));

	// _3_osloj
	this.instance_18 = new lib.Символ24();
	this.instance_18.parent = this;
	this.instance_18.setTransform(173.2,121,1,1,0,0,0,41.7,9);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(120).to({_off:false},0).to({y:88,alpha:1},17,cjs.Ease.cubicOut).wait(51).to({y:70},18,cjs.Ease.cubicIn).to({_off:true},1).wait(183));

	// _3_riska
	this.instance_19 = new lib.Символ23();
	this.instance_19.parent = this;
	this.instance_19.setTransform(172.95,98.75,1,1,0,0,0,42.2,19.5);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(118).to({_off:false},0).to({y:65.75,alpha:1},17,cjs.Ease.cubicOut).wait(53).to({y:47.75},18,cjs.Ease.cubicIn).to({_off:true},1).wait(183));

	// _3_snijenie
	this.instance_20 = new lib.Символ22();
	this.instance_20.parent = this;
	this.instance_20.setTransform(172.45,69.55,1,1,0,0,0,41.2,13.5);
	this.instance_20.alpha = 0;
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(116).to({_off:false},0).to({y:36.55,alpha:1},17,cjs.Ease.cubicOut).wait(55).to({y:18.55},18,cjs.Ease.cubicIn).to({_off:true},1).wait(183));

	// krestik___2
	this.instance_21 = new lib.Символ9копия();
	this.instance_21.parent = this;
	this.instance_21.setTransform(204.3,88.55,2.9999,2.9999,0,0,0,4.5,4.5);
	this.instance_21.alpha = 0;
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(38).to({_off:false},0).to({regX:4.4,regY:4.4,scaleX:1.04,scaleY:1.04,x:204.35,y:88.6,alpha:1},24,cjs.Ease.backInOut).wait(37).to({y:54.6},16,cjs.Ease.cubicIn).to({_off:true},1).wait(274));

	// krestik
	this.instance_22 = new lib.Символ9();
	this.instance_22.parent = this;
	this.instance_22.setTransform(41.7,87.95,2.9999,2.9999,0,0,0,4.5,4.4);
	this.instance_22.alpha = 0;
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(32).to({_off:false},0).to({regX:4.4,regY:4.3,scaleX:1.03,scaleY:1.03,x:41.8,y:88,alpha:1},24,cjs.Ease.backInOut).wait(43).to({y:54},16,cjs.Ease.cubicIn).to({_off:true},1).wait(274));

	// bact
	this.instance_23 = new lib.Символ44();
	this.instance_23.parent = this;
	this.instance_23.setTransform(15,10,1,1,0,0,0,15,10);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(99).to({y:-24},16,cjs.Ease.cubicIn).to({_off:true},1).wait(274));

	// virus
	this.instance_24 = new lib.Символ43();
	this.instance_24.parent = this;
	this.instance_24.setTransform(14,10.5,1,1,0,0,0,14,10.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(99).to({y:-23.5},16,cjs.Ease.cubicIn).to({_off:true},1).wait(274));

	// pachka_c4
	this.instance_25 = new lib.Символ28();
	this.instance_25.parent = this;
	this.instance_25.setTransform(-213.95,217.75,1,1,0,0,0,73,53.5);
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(209).to({_off:false},0).to({x:105.05},25,cjs.Ease.cubicOut).to({_off:true},76).wait(80));

	// pachka2_c4
	this.instance_26 = new lib.Символ35();
	this.instance_26.parent = this;
	this.instance_26.setTransform(479.5,147.75,1,1,0,0,0,71,53.8);
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(204).to({_off:false},0).to({x:135.5},25,cjs.Ease.cubicOut).to({_off:true},81).wait(80));

	// с4_grad
	this.instance_27 = new lib.Символ49();
	this.instance_27.parent = this;
	this.instance_27.setTransform(119,39.35,1,1,0,0,0,120.2,56.5);
	this.instance_27.alpha = 0;
	this.instance_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(206).to({_off:false},0).to({alpha:0.6211},14).to({_off:true},89).wait(81));

	// c4
	this.instance_28 = new lib.Символ50();
	this.instance_28.parent = this;
	this.instance_28.setTransform(120,275,1,1,0,0,0,120,200);
	this.instance_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(206).to({_off:false},0).to({y:200},14,cjs.Ease.cubicOut).to({_off:true},90).wait(80));

	// c3
	this.instance_29 = new lib.Символ32();
	this.instance_29.parent = this;
	this.instance_29.setTransform(119,202.8,1,1,0,0,0,119,169.8);
	this.instance_29._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(114).to({_off:false},0).to({y:169.8},14,cjs.Ease.cubicOut).wait(60).to({y:151.8},18,cjs.Ease.cubicIn).to({_off:true},3).wait(181));

	// pachka1
	this.instance_30 = new lib.Символ5();
	this.instance_30.parent = this;
	this.instance_30.setTransform(127,216,1,1,0,0,0,32,24);

	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(99).to({y:182},16,cjs.Ease.cubicIn).to({_off:true},2).wait(273));

	// light
	this.instance_31 = new lib.Символ19("synched",0);
	this.instance_31.parent = this;
	this.instance_31.setTransform(126.95,216,1.05,1.05,0,0,0,34.2,26.2);
	this.instance_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(38).to({_off:false},0).wait(61).to({startPosition:7},0).to({y:182,startPosition:23},16,cjs.Ease.cubicIn).to({_off:true},2).wait(273));

	// c1
	this.instance_32 = new lib.Символ3();
	this.instance_32.parent = this;
	this.instance_32.setTransform(120,200,1,1,0,0,0,120,200);

	this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(99).to({y:166},16,cjs.Ease.cubicIn).to({_off:true},2).wait(273));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCF7F8").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
	this.shape_1.setTransform(120,200);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#03D6E5").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
	this.shape_2.setTransform(120,200);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AyvfQMAAAg+fMAlfAAAMAAAA+fg");
	this.shape_3.setTransform(120,200);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},206).to({state:[{t:this.shape_3}]},103).wait(81));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-182.1,75,759.7,617);
// library properties:
lib.properties = {
	id: '254F9D6A10EB4B4FBABE1520376FDE28',
	width: 240,
	height: 400,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"240x400_atlas_P_.png", id:"240x400_atlas_P_"},
		{src:"240x400_atlas_NP_.jpg", id:"240x400_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['254F9D6A10EB4B4FBABE1520376FDE28'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;